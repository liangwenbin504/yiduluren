# -*- coding: utf-8 -*-
"""用反推月将重建评估数据 + 课体校验"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

# 读反推月将
with open('extracted_data/_guji_fetch/指南卷三_反推月将.json', encoding='utf-8') as f:
    rev = json.load(f)
rev_map = {(r['章节'], r['编号']): r['月将'] for r in rev}

# 读原评估数据（含三传等）
with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    data = json.load(f)

from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
ssc = SiKeSanChuanCalculator2()

updated = 0
no_yj = 0
for c in data['cases']:
    ch, num = c['name'][0], c['name'][1:]
    yj = rev_map.get((ch, num), '')
    if not yj:
        no_yj += 1
        continue
    # 用反推月将重算三传
    try:
        calc = ssc.calculate(c['ri_gan'], c['ri_zhi'], yj, c['shichen'])
        sc = calc.get('sanchuan') or {}
        c['sanchuan'] = [sc.get('初传',''), sc.get('中传',''), sc.get('末传','')]
        c['yue_jiang'] = yj
        c['keti_engine'] = sc.get('课体','')
        updated += 1
    except Exception as e:
        print(f"  重算失败 {c['id']}: {str(e)[:50]}")

print(f'反推月将替换 {updated} 案，无月将 {no_yj} 案')

# 课体校验（九宗门）
JZM = ['元首','重审','知一','比用','涉害','见机','察微','遥克','蒿矢','弹射','昴星','别责','八专','伏吟','反吟']
def to_jzm(lst):
    out = set()
    for k in lst:
        if k in ('蒿矢','弹射'): out.add('遥克')
        elif k in ('见机','察微'): out.add('涉害')
        elif k == '比用': out.add('知一')
        elif k in JZM: out.add(k)
    return out

with open('extracted_data/_guji_fetch/大六壬指南_卷三_案例.json', encoding='utf-8') as f:
    raw = json.load(f)
raw_map = {c['章节'] + c['编号']: c for c in raw}

match = 0; n = 0; mismatch = []
for c in data['cases']:
    raw_c = raw_map.get(c['name'], {})
    want = to_jzm(raw_c.get('课体', []))
    if not want or not c.get('keti_engine'):
        continue
    n += 1
    eng = c['keti_engine'].replace('课','').replace('格','')
    if any(w in eng for w in want):
        match += 1
    else:
        mismatch.append((c['id'], sorted(want), eng))

print(f'课体一致: {match}/{n} = {match/max(n,1)*100:.0f}%')
for cid, o, e in mismatch[:20]:
    print(f'  {cid}: 原文{o} vs 引擎[{e}]')

# 保存更新后的数据
with open('engine/ancient_truth_labels_zhinan_v3.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=1)
print('\n已更新 ancient_truth_labels_zhinan_v3.json')
