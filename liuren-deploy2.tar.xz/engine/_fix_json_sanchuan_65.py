# -*- coding: utf-8 -*-
"""65 案 JSON 三传错修正：用引擎重算值（=v3原文双验证）覆盖"""
import json, re, sys
sys.path.insert(0, '.')
from engine.daliuren_engine import DaLiuRenEngine

r = json.load(open('engine/shuzheng_real_cases.json', encoding='utf-8'))
text = open('data/断案疏正_全文.txt', encoding='utf-8').read()
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', text, flags=re.M)]
num2block = {}
for i, m in enumerate(titles):
    end = titles[i + 1].start() if i + 1 < len(titles) else len(text)
    num2block[m.group(3)] = text[m.start():end]

def v3(b):
    seg = re.split(r'邵先生曰|邵彦和曰|邵先先曰', b)[0]
    return [m.group(2) for m in re.finditer(r'([财官父兄子鬼比贼])[\s\S]{0,3}?([子丑寅卯辰巳午未申酉戌亥])([后阴玄常虎空青勾合朱蛇贵])', seg)][:3]

eng = DaLiuRenEngine()
GAN = set('甲乙丙丁戊己庚辛壬癸'); ZHI = set('子丑寅卯辰巳午未申酉戌亥')
fixed = 0
for c in r:
    cid = c['case_id']; gz = c.get('day_ganzhi', ''); yj = c.get('yue_jiang', ''); shi = c.get('shichen', '')
    cur = c.get('sanchuan') or []
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI and yj in ZHI and shi in ZHI):
        continue
    tp = eng.arrange_tiandi_pan(yj, shi); sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    es = eng.fa_san_chuan(sk, gz[0], tp)['三传']
    ys = v3(num2block.get(c.get('num'), ''))
    cs = ''.join(cur) if cur else ''
    # 仅修正：引擎=v3原文 且 引擎≠JSON 的案（JSON 提取错）
    if ''.join(es) == ''.join(ys) and ''.join(es) != cs and len(es) == 3:
        c['sanchuan'] = es
        fixed += 1

json.dump(r, open('engine/shuzheng_real_cases.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'已修正 {fixed} 案 JSON 三传（引擎=v3原文 双验证）')
