# -*- coding: utf-8 -*-
"""从 data/大六壬断案疏正.pdf 抽取真实断案，存为结构化 JSON。
输出: engine/shuzheng_real_cases.json
"""
import fitz
import re
import json
from pathlib import Path

PDF = "data/大六壬断案疏正.pdf"
OUT = "engine/shuzheng_real_cases.json"

doc = fitz.open(PDF)
print("页数:", doc.page_count)
pages = [p.get_text() for p in doc]
text = "\n".join(pages)
print("总字数:", len(text))

# ---------- 占类代码 -> 通用占类映射 ----------
ZHANLEI_MAP = {
    "前程仕进": "功名", "功名": "功名", "考试": "功名", "科举": "功名", "仕宦": "功名",
    "疾病": "疾病", "病": "疾病", "医": "疾病",
    "宅墓": "家宅", "家宅": "家宅", "宅": "家宅",
    "婚姻": "婚姻", "婚": "婚姻", "嫁娶": "婚姻",
    "财产": "求财", "财": "求财", "经营": "求财", "交易": "求财", "铺店": "求财",
    "胎产": "胎产", "孕": "胎产", "产": "胎产", "育": "胎产",
    "出行": "出行", "行旅": "出行", "行人": "出行",
    "官讼": "官讼", "词讼": "官讼", "狱": "官讼", "讼": "官讼",
    "走失": "走失", "失脱": "走失", "捕获": "走失", "逃亡": "走失",
    "蚕桑": "蚕桑", "农桑": "蚕桑", "田蚕": "蚕桑",
    "征战": "征战", "兵": "征战", "战": "征战", "敌": "征战",
    "寿元": "寿元", "寿命": "寿元", "老病": "寿元",
    "晴雨": "其他", "天时": "其他", "坟墓": "家宅", "怪异": "其他",
    "杂占": "其他", "射覆": "其他", "选官": "功名", "升迁": "功名",
    "补官": "功名", "武举": "功名", "文职": "功名", "阴宅": "家宅",
}

# ---------- 结局分类 ----------
JI = ["大吉", "吉", "利", "得中", "高中", "及第", "登科", "愈", "痊", "康复", "全愈",
      "成", "遂", "喜", "安", "无碍", "无害", "升", "迁", "进", "获利", "得官", "得财",
      "生", "全", "吉庆", "不免", "无凶", "平善", "称意", "兴隆", "发", "贵", "显"]
XIONG = ["死", "亡", "殁", "卒", "凶", "大凶", "极凶", "灾", "难", "败", "破", "坏",
         "病重", "危", "笃", "讼", "狱", "刑", "伤", "损", "失", "退", "贬", "黜", "忧",
         "哭", "哀", "废", "歇", "散", "离", "囚", "拘", "逮", "亡身", "丧", "夭", "厄",
         "耗", "盗", "劫", "兵", "战死", "缢", "溺", "自尽", "不利", "四分", "守寡", "寡",
         "困", "穷", "疾", "患", "破家", "坏家", "倾", "亏", "灾祸", "祸", "凶灾", "病危"]
PING = ["平平", "平常", "一般", "中等", "守", "无大喜", "无大忧", "可守", "平稳", "平善"]
STRONG_JI = ["大吉", "得中", "高中", "及第", "登科", "痊愈", "康复", "全愈", "升迁",
            "得官", "称意", "此课吉", "主吉", "必吉", "吉课", "吉兆"]
STRONG_XIONG = ["大凶", "极凶", "此课凶", "主凶", "必凶", "凶课", "死", "亡",
               "缢", "溺", "自尽", "战死", "兵败", "凶灾"]


# ---------- 中文数字转 int ----------
CN_NUM = {'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,
          '九':9,'十':10,'零':0,'〇':0,'廿':20,'卅':30}
def cn2int(s):
    if not s:
        return None
    if s.isdigit():
        return int(s)
    total, curr = 0, 0
    for ch in s:
        if ch in CN_NUM:
            if ch == '十':
                total += (curr if curr else 1) * 10; curr = 0
            elif ch == '百':
                total += (curr if curr else 1) * 100; curr = 0
            else:
                curr = CN_NUM[ch]
        else:
            break
    return total + curr


def classify_outcome(duanyu: str, pinglun: str = ""):
    """从邵先生曰(+评疏)判断结局。返回 (label, conf, evidence)。"""
    if not duanyu:
        return "未知", 0.0, "无断语"
    d = duanyu + " " + (pinglun or "")
    # 强判定优先（覆盖全文本，含评疏）
    for kw in STRONG_XIONG:
        if kw in d:
            return "凶", 0.95, f"强凶:{kw}"
    for kw in STRONG_JI:
        if kw in d:
            return "吉", 0.95, f"强吉:{kw}"
    ji = [k for k in JI if k in d]
    xiong = [k for k in XIONG if k in d]
    ping = [k for k in PING if k in d]
    last = d[-150:] if len(d) > 150 else d
    ji_last = sum(1 for k in ji if k in last)
    xiong_last = sum(1 for k in xiong if k in last)
    ji_score = len(ji) + ji_last
    xiong_score = len(xiong) + xiong_last
    if xiong_score > ji_score and xiong_score >= 1:
        return "凶", 0.85, f"凶词:{','.join(xiong[:4])}"
    if ji_score > xiong_score and ji_score >= 1:
        return "吉", 0.85, f"吉词:{','.join(ji[:4])}"
    if ping:
        return "平", 0.70, f"平词:{','.join(ping)}"
    if xiong_last:
        return "凶", 0.60, "末句含凶词"
    if ji_last:
        return "吉", 0.60, "末句含吉词"
    return "未知", 0.3, "无法判定"


def parse_sanchuan(block: str):
    """从排盘里抓三传地支。六壬三传行形如 '兄乙巳常' '子癸丑勾' '财庚寅虎'。"""
    # 找含 六亲前缀 的行
    trans = []
    for m in re.finditer(r'[兄比贼子财父官鬼鬼][\u4e00-\u9fff]?([\u4e00-\u9fff])([\u4e00-\u9fff]{1,2})', block):
        # m.group(1)=地支, group(2)=天将
        zhi = m.group(1)
        if zhi in "子丑寅卯辰巳午未申酉戌亥":
            trans.append(zhi)
    # 三传通常连续3个；取前3个去重过多的
    if len(trans) >= 3:
        return trans[:3]
    return trans


# ---------- 切分案例 ----------
# 以 § 开头作为新案例边界
raw_blocks = re.split(r'(?=§)', text)
print("§分块数:", len(raw_blocks))

cases = []
for b in raw_blocks:
    m = re.search(r'§([\u4e00-\u9fff]+?)(\d{1,3})·(\d{1,3})', b)
    if not m:
        continue
    zhanlei_code = m.group(1)
    sec = m.group(2)
    num = m.group(3)
    # 占类映射
    zhanlei = None
    for k, v in ZHANLEI_MAP.items():
        if k in zhanlei_code:
            zhanlei = v
            break
    if not zhanlei:
        zhanlei = "其他"
    # 年龄（中文数字）
    age_m = re.search(r'([0-9四五六七八九十三二一十百零〇廿卅]+)\s*岁', b)
    age = cn2int(age_m.group(1)) if age_m else None
    # 姓名/身份: §后第一行，到"岁"之前的中文
    name_m = re.search(r'§[\u4e00-\u9fff]+\d+·\d+\s*([\u4e00-\u9fff]{1,10}?)\s*[0-9四五六七八九十三二一十百零〇廿卅]+\s*岁', b)
    name = name_m.group(1) if name_m else ""
    # 日干支: X年Y月[干支]日
    day_m = re.search(r'([\u4e00-\u9fff]{2})日', b)
    day_ganzhi = day_m.group(1) if day_m else ""
    # 月将/时辰（1字）
    yue_m = re.search(r'([\u4e00-\u9fff])将', b)
    yue_jiang = yue_m.group(1) if yue_m else ""
    shi_m = re.search(r'([\u4e00-\u9fff])时', b)
    shichen = shi_m.group(1) if shi_m else ""
    # 邵先生曰
    sj = re.search(r'邵先生曰[:：](.*?)(?:【评疏】|§|$)', b, re.S)
    duanyu = re.sub(r'\s+', '', sj.group(1)) if sj else ""
    # 评疏（含明确 verdict）
    pl = re.search(r'【评疏】[:：]?(.*?)(?:§|$)', b, re.S)
    pinglun = re.sub(r'\s+', '', pl.group(1)) if pl else ""
    # 三传
    sanchuan = parse_sanchuan(b)
    # 结局
    label, conf, ev = classify_outcome(duanyu, pinglun)
    cases.append({
        "case_id": f"§{zhanlei_code}{sec}·{num}",
        "zhanlei_code": zhanlei_code,
        "zhanlei": zhanlei,
        "sec": sec, "num": num,
        "name": name, "age": age,
        "day_ganzhi": day_ganzhi,
        "yue_jiang": yue_jiang, "shichen": shichen,
        "sanchuan": sanchuan,
        "duanyu": duanyu[:400],
        "label": label, "label_conf": conf, "label_ev": ev,
    })

print("解析出原始块:", len(cases))
# ---------- 按 case_id 去重，保留断语最长者 ----------
best = {}
for c in cases:
    cid = c["case_id"]
    if cid not in best or len(c["duanyu"]) > len(best[cid]["duanyu"]):
        best[cid] = c
cases = list(best.values())
print("去重后真实案例:", len(cases))
# 占类分布
from collections import Counter
print("占类分布:", dict(Counter(c["zhanlei"] for c in cases)))
print("结局分布:", dict(Counter(c["label"] for c in cases)))

# 打印前几个验证
print("\n=== 抽样验证（前8例）===")
for c in cases[:8]:
    print(f"  {c['case_id']} | {c['zhanlei']} | {c['name']}{c['age']}岁 | 日{c['day_ganzhi']} {c['yue_jiang']}将{c['shichen']}时 | 三传{''.join(c['sanchuan'])} | {c['label']}({c['label_conf']})")
    print(f"    断语: {c['duanyu'][:80]}")

json.dump(cases, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("\n已存:", OUT)
