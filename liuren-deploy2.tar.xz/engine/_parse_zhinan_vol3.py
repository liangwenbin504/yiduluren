# -*- coding: utf-8 -*-
"""解析《大六壬指南》卷三会纂占验指南 → 结构化案例
每案：章节 / 占验编号 / 年 / 月 / 日干支 / 时辰 / 课体 / 空亡 / 断语
"""
import re, json

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_会纂占验指南_guoxuedashi.txt'
OUT = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'

with open(SRC, encoding='utf-8') as f:
    text = f.read()

lines = text.split('\n')
# 定位正文开始（卷三大六壬会纂占验指南 之后）
start = 0
for i, ln in enumerate(lines):
    if '卷三大六壬会纂占验指南' in ln and '会纂' in ln:
        start = i
        break
lines = lines[start:]
# 去掉尾部导航
end = len(lines)
for i, ln in enumerate(lines):
    if '返回' in ln and '检索' in ln and '首页' in ln:
        end = i
        break
lines = lines[:end]

cases = []
cur_chapter = ''
cur = None
for ln in lines:
    ln = ln.strip()
    if not ln:
        continue
    # 章节标题：总论章第一 / 天时章第二 ...
    m = re.match(r'^(总论|天时|阳宅|阴地|迁移|香火|婚姻|孕产|疾病|出行|行人|趋谒|选举|武举|仕宦|求财|买卖|占讼|隐遁|逃亡|贼盗|田蚕|六畜|应候|岁占|射覆|钦差|章奏|兵斗|三合)章第[一二三四五六七八九十]+$', ln)
    if m:
        cur_chapter = m.group(1)
        continue
    # 占验案例：占验一、XXXX
    m2 = re.match(r'^占验([一二三四五六七八九十]+)、(.*)$', ln)
    if m2:
        cur = {'章节': cur_chapter, '占验编号': '占验' + m2.group(1), '正文': ln}
        cases.append(cur)
        continue
    # 续行（断语等）追加到当前案例
    if cur is not None:
        cur['正文'] += '\n' + ln

# 提取结构化字段
def extract_meta(body):
    meta = {'年': '', '月': '', '日干支': '', '时辰': '', '课体': [], '空亡': ''}
    head = body.split('。')[0] if '。' in body else body
    # 年：X年 / X寅 / 干支+年
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])年', head)
    if m:
        meta['年'] = m.group(1)
    # 月：正月/二月/.../十二月 or X月
    m = re.search(r'([正二三四五六七八九十冬腊]月|十二月)', head)
    if m:
        meta['月'] = m.group(1)
    # 日干支：X日
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])日', head)
    if m:
        meta['日干支'] = m.group(1)
    # 时辰：X时（干支时）
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])时', head)
    if m:
        meta['时辰'] = m.group(1)
    # 空亡：X空 / X落空
    m = re.search(r'([^，。、\s]{2,4}空[，。、\s]?[^，。]*落空)', head)
    if m:
        meta['空亡'] = m.group(1)
    # 课体：逗号分隔的词组（出现在"占何"类短语后的课体列表）
    m = re.search(r'[，,]([^，。]{2,8}[、，][^，。]{2,8}[，。])', head)
    return meta

for c in cases:
    body = c['正文']
    meta = extract_meta(body)
    c.update(meta)
    # 判断断语（正文中"断曰/余曰/余答/愚按"之后）
    m = re.search(r'(断曰|余曰|予曰|余答|愚按)[：:，]?([\s\S]*)$', body)
    c['断语'] = m.group(2).strip() if m else ''

# 统计
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(cases, f, ensure_ascii=False, indent=1)

full = [c for c in cases if c['日干支'] and c['月']]
print(f'总案例: {len(cases)}')
print(f'有日干支+月: {len(full)}')
print(f'有日干支+月+时: {len([c for c in cases if c["日干支"] and c["月"] and c["时辰"]])}')
print(f'有断语: {len([c for c in cases if c["断语"]])}')
print()
# 按章节统计
from collections import Counter
cnt = Counter(c['章节'] for c in cases)
print('按章节案例数:')
for k, v in cnt.items():
    print(f'  {k}: {v}')
print()
print('样例（孕产章）:')
for c in cases:
    if c['章节'] == '孕产':
        print(f"  [{c['占验编号']}] {c['年']}年{c['月']} {c['日干支']} {c['时辰']} | {c['课体']} | {c['正文'][:60]}")
print(f'\n已保存 {OUT}')
