# -*- coding: utf-8 -*-
"""壬占汇选 v2 补字段：形近纠错 + 反向推月将，扩大可校验样本。"""
import json, re, sys
sys.path.insert(0, ".")
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2

d = json.load(open("extracted_data/壬占汇选_训练数据_v2.json", encoding="utf-8"))
GAN = "甲乙丙丁戊己庚辛壬癸"
ZHI = "子丑寅卯辰巳午未申酉戌亥"
ZHI_SET = set(ZHI)
calc = SiKeSanChuanCalculator2()

_SC_PAT = re.compile(
    r"[财官父兄子鬼][\s　]+[◎⊙]?([甲乙丙丁戊己庚辛壬癸])?[\s　]*[◎⊙]?"
    r"([子丑寅卯辰巳午未申酉戌亥])[\s　]+[贵蛇螣腾朱合勾陈龙青空虎常玄武阴后白六天]"
)

def get_sanchuan(case_text):
    pan = case_text.split("曰")[0] if "曰" in case_text else case_text
    zhis = [m.group(2) for m in _SC_PAT.finditer(pan)]
    return zhis[:3] if len(zhis) >= 3 else None

def get_yuejiang(case_text):
    """从 case_text 提月将，含形近纠错（己将→巳将、戊将→戌将）。"""
    m = re.search(r"[子丑寅卯辰巳午未申酉戌亥]将", case_text)
    if m:
        return m.group(0)[0]
    # 形近纠错：己/戊 不是地支，但常见错字
    for wrong, right in [("己", "巳"), ("戊", "戌")]:
        if wrong + "将" in case_text:
            return right
    return None

def get_shichen(case_text):
    m = re.search(r"([子丑寅卯辰巳午未申酉戌亥])时", case_text)
    if m:
        return m.group(1)
    return None

# 统计
n_before = 0      # 原来就能重算
n_fixed_yj = 0    # 形近纠错补月将
n_rev_yj = 0      # 反推月将
n_ambig = 0       # 反推多解
n_no_rev = 0      # 反推无解
n_still_missing = 0  # 仍缺字段（切分错误等）

rev_detail = []

for i, c in enumerate(d):
    gz = c.get("ganzhi", "") or ""
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI_SET):
        n_still_missing += 1
        continue
    rg, rz = gz[0], gz[1]
    ct = c.get("case_text", "") or ""

    # 现有字段
    yj_field = c.get("yuejiang", "") or ""
    sc_field = c.get("shichen", "") or ""
    yj_zhi = re.search(r"[子丑寅卯辰巳午未申酉戌亥]", yj_field)
    sc_zhi = re.search(r"[子丑寅卯辰巳午未申酉戌亥]", sc_field)
    yj_zhi = yj_zhi.group(0) if yj_zhi else None
    sc_zhi = sc_zhi.group(0) if sc_zhi else None

    # 缺月将 → 补
    if not yj_zhi:
        # 1) 形近纠错
        yj2 = get_yuejiang(ct)
        if yj2:
            yj_zhi = yj2
            n_fixed_yj += 1
        else:
            # 2) 反推月将（需有时辰 + 三传）
            sc2 = sc_zhi or get_shichen(ct)
            sc3 = get_sanchuan(ct)
            if sc2 and sc3:
                hits = []
                for cand in ZHI:
                    try:
                        r = calc.calculate(rg, rz, cand, sc2)
                    except Exception:
                        continue
                    san = r.get("sanchuan", {})
                    rec = [san.get("初传"), san.get("中传"), san.get("末传")]
                    if rec == sc3:
                        hits.append(cand)
                if len(hits) == 1:
                    yj_zhi = hits[0]
                    n_rev_yj += 1
                    rev_detail.append((i, gz, sc2, sc3, hits[0]))
                elif len(hits) > 1:
                    n_ambig += 1
                else:
                    n_no_rev += 1
            else:
                n_still_missing += 1

    # 缺时辰 → 补
    if not sc_zhi:
        sc2 = get_shichen(ct)
        if sc2:
            sc_zhi = sc2
        else:
            n_still_missing += 1

    if yj_zhi and sc_zhi:
        n_before += 1

print(f"=== 补字段结果 ===")
print(f"补后字段齐（可重算）: {n_before}")
print(f"  形近纠错补月将: {n_fixed_yj}")
print(f"  反推月将（唯一解）: {n_rev_yj}")
print(f"  反推多解: {n_ambig}")
print(f"  反推无解: {n_no_rev}")
print(f"  仍缺字段（切分错误等）: {n_still_missing}")
print()
print(f"=== 反推月将样本（前15条）===")
for i, gz, sc, sc3, yj in rev_detail[:15]:
    print(f"#{i} {gz}日 {sc}时 三传={sc3} → 反推月将={yj}")
