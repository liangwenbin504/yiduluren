# -*- coding: utf-8 -*-
"""四课结构化写进主 JSON：
- 上神、下神：引擎 arrange_si_ke 重算（九宗门已全量验证零错误，权威真值）
- 天将：占时昼夜贵神盘（古例用占时判昼夜：卯辰巳午未申=昼，酉戌亥子丑寅=夜）
"""
import json, sys
sys.path.insert(0, '.')
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_daynight import GUI_REN, TIAN_JIANG

ZHI = '子丑寅卯辰巳午未申酉戌亥'
GAN = set('甲乙丙丁戊己庚辛壬癸')

def get_gui_pan(ri_gan, shi_chen):
    """占时昼夜贵神盘"""
    yang_gui, yin_gui = GUI_REN.get(ri_gan, ('丑', '未'))
    day_time = shi_chen in '卯辰巳午未申'
    start = yang_gui if day_time else yin_gui
    gi = ZHI.index(start)
    ni = start in '巳午未申酉戌'
    pan = {}
    for i in range(12):
        di = ZHI[(gi + 12 - i) % 12] if ni else ZHI[(gi + i) % 12]
        pan[di] = TIAN_JIANG[i]
    return pan

eng = DaLiuRenEngine()
real = json.load(open('engine/shuzheng_real_cases.json', encoding='utf-8'))
done = 0
for c in real:
    gz = c.get('day_ganzhi', ''); yj = c.get('yue_jiang', ''); shi = c.get('shichen', '')
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI and yj in ZHI and shi in ZHI):
        continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    pan = get_gui_pan(gz[0], shi)
    sike = []
    for k in sk:
        sike.append({
            '课': k['name'],
            '上神': k['top'],
            '下神': k['bottom'],
            '天将': pan.get(k['top'], ''),
        })
    c['sike'] = sike
    done += 1

json.dump(real, open('engine/shuzheng_real_cases.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'四课已结构化写入 {done} 案')
# 验证
c = [x for x in real if x['case_id'] == '§宅墓02·036'][0]
print('§宅墓02·036 四课:', c.get('sike'))
c = [x for x in real if x['case_id'] == '§宅墓02·004'][0]
print('§宅墓02·004 四课:', c.get('sike'))
