"""求财48例逐例诊断脚本"""
import json, sys
sys.path.insert(0, '.')
from engine.ancient_backtest import build_result_from_ancient, predict_ancient_case
from engine.caishen_enhance import detect_caishen_patterns
import engine.judgment_fusion as jf

with open('engine/ancient_truth_labels.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

wealth_cases = [c for c in data['cases'] if c.get('category') == '求财' and c.get('label') != '未知']

print(f'=== 求财案例逐例诊断 ({len(wealth_cases)}例) ===\n')

errors = {'吉->平': [], '吉->凶': [], '凶->吉': [], '凶->平': [], '平->吉': [], '平->凶': []}
correct_list = []
incorrect_list = []

for case in wealth_cases:
    cid = case.get('id', '?')
    name = case.get('name', '?')
    truth = case.get('label', '?')
    sanchuan = case.get('sanchuan', [])

    result = build_result_from_ancient(case)
    pred = predict_ancient_case(case, 'M3')
    prediction = pred['prediction']
    correct = (pred['prediction'] == truth)

    sigs = jf.collect_signals(result)

    tl = result.get('sanchuan_tianjiang', [])
    sc = result.get('san_chuan', [])
    tm = result.get('tianjiang_map', {})
    sk = result.get('si_ke', [])
    lq = result.get('analysis', {}).get('liuqin', [])
    rg = result.get('basic_info', {}).get('ri_gan', '')
    caishen = detect_caishen_patterns(tl, tm, sc, sk, lq, rg)

    caishen_signals = caishen.get('signals', [])
    caishen_bull = caishen.get('overall_bullish', 0)
    caishen_bear = caishen.get('overall_bearish', 0)
    caishen_net = caishen_bull - caishen_bear

    bull_score = sum(s for g, s, u, c in sigs if s > 0 and g != 'caishen')
    bear_score = sum(abs(s) for g, s, u, c in sigs if s < 0 and g != 'caishen')

    status = '✓' if correct else '✗'
    arrow = ''
    if not correct:
        arrow = f'  [{truth}->{prediction}]'
        errors[f'{truth}->{prediction}'].append(cid)
        incorrect_list.append(cid)
    else:
        correct_list.append(cid)

    print(f'{status} [{cid}] {name} 真={truth} 判={prediction}{arrow}')
    print(f'   三传: {"->".join(sanchuan)}  天将: {"->".join(tl) if tl else "无"}')
    print(f'   up={pred["prob_up"]:.3f}  down={pred["prob_down"]:.3f}  flat={pred["prob_flat"]:.3f}  conf={pred["confidence"]:.3f}')
    print(f'   信号: 吉+{bull_score:.1f} / 凶-{bear_score:.1f}  |  caishen: 多{caishen_bull:.1f} 空{caishen_bear:.1f} 净{caishen_net:+.1f}')
    if caishen_signals:
        if isinstance(caishen_signals[0], dict):
            cs_str = ', '.join(f'{s["type"]}(s={s.get("score",0)})' for s in caishen_signals[:3])
        else:
            cs_str = ', '.join(str(s) for s in caishen_signals[:3])
        print(f'   类神: {cs_str}')
    print()

print('=' * 60)
print('错误归因汇总')
print('=' * 60)
for err_type, case_ids in sorted(errors.items()):
    if case_ids:
        print(f'  {err_type} ({len(case_ids)}例): {", ".join(case_ids)}')

missed_bull = len(errors.get('吉->平', [])) + len(errors.get('吉->凶', []))
false_bull = len(errors.get('凶->吉', [])) + len(errors.get('平->吉', []))
missed_bear = len(errors.get('凶->平', [])) + len(errors.get('凶->吉', []))
false_bear = len(errors.get('吉->凶', [])) + len(errors.get('平->凶', []))

print(f'\n  正确: {len(correct_list)}例')
print(f'  看涨漏判(真吉->平/凶): {missed_bull}例 -> {errors.get("吉->平",[])}')
print(f'  看涨误判(真凶/平->吉): {false_bull}例')
print(f'  看跌漏判(真凶->平/吉): {missed_bear}例 -> {errors.get("凶->平",[])}')
print(f'  看跌误判(真吉/平->凶): {false_bear}例')

# Save misclassified for deeper analysis
with open('engine/_wealth_misclassified.json', 'w', encoding='utf-8') as f:
    json.dump({
        'errors': {k: v for k, v in errors.items()},
        'correct': correct_list,
        'incorrect': incorrect_list,
    }, f, ensure_ascii=False, indent=2)
print(f'\n错误清单已保存: engine/_wealth_misclassified.json')
