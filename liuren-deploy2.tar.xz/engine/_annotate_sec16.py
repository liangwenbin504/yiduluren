# -*- coding: utf-8 -*-
"""长征第1期 · sec16 官讼(11) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§官讼16·202": {
        "leishen": ["贵人：昼贵在夜夜贵在昼(失位)", "雀：酉作雀", "太阴：末传太阴", "墓：太阴作丑为墓"],
        "liqi": ["昼贵在夜夜贵在昼谓之贵人失位→不宜讼必主断理不明", "贵人差迭→主以财结托及暗通贵人关节", "酉作雀徒然结托必主又换衙门", "行年寅又为今日父母主吏人及尊长为鬼、寅反加鬼乡", "官断不明末传太阴故", "太阴作丑为墓→以后彼必葬老阴人于内"],
        "leixiang": ["酉=雀(结托)、丑=太阴(墓老阴人)、寅=父母(吏人鬼)"],
        "yingqi": ["自戊申至辛亥六月姑死葬于内赎不得"],
    },
    "§官讼16·203": {
        "leishen": ["旬尾：卯(我见卯旬尾)", "旬首：午(彼见午旬首)", "元武：卯财又乘元武", "贵人：午作贵人作日鬼"],
        "liqi": ["干上旬尾支上旬首为一旬周遍格又名周而复始格", "日上我也支上彼也、我见卯旬尾是事了毕彼见午旬首其事又起", "末传丑与支上午六害卯财又乘元武到了翻论才输财又被人诓赚", "辛墓于丑丑墓于申→主在外州入狱而羁绊", "他是午火反生他州狱神我是卯木能克狱神翻至二次却能胜", "午作贵人作日鬼临支却是六害→彼自然失理", "卯乃闭口说不得又不敢问"],
        "leixiang": ["卯=旬尾(元武闭口)、午=旬首(贵人日鬼)、丑=墓(六害)"],
        "yingqi": ["入州县狱方得了绝", "被人啜银一百两"],
    },
    "§官讼16·204": {
        "leishen": ["天网：午发用为天网", "阳刃：午加申阳刃破碎", "青龙：加申为退鳞", "火局：行年自会起火局"],
        "liqi": ["顺祖课主原有讼根【原文课体·顺祖】", "金日得巳时又午发用为天网", "末寅只管午火遂来克身又是自取其灾", "行年自会起火局所以招致、用火自去烧身", "甲寅旬见寅乃第一位公人害你", "午加申乃西南方阳刃破碎加本命真针", "青龙加申为退鳞所以笞背", "行年见戌则为配军"],
        "leixiang": ["午=天网(火局阳刃)、寅=公人(生火)、申=西南(破碎)、青龙=退鳞"],
        "yingqi": ["配鄂州一千八百里(午又见午二九一十八)"],
    },
    "§官讼16·205": {
        "leishen": ["木局：生干上午火", "幼子：亥(宅见亥为幼子)", "太常：日上太常是服", "六合：亥水又作六合"],
        "liqi": ["木局生干上午火火来克日行年上又见寅日贵午虽是关切又是鬼", "寅木又生鬼→故有事", "贴幼子即止者因宅见亥为幼子亥水能制午火", "诸木又生于亥故住与不住皆由于亥→必贴幼小方得止", "日上太常是服午则妇人故因嫂而动", "三传生鬼动众之兆", "寅加午上贵人差迭宜告贵人", "亥能制午是以贴幼子"],
        "leixiang": ["亥=幼子(六合制午火)、午=鬼(妇人)、太常=服、木局=生鬼"],
        "yingqi": ["贴幼弟物诸人皆散"],
    },
    "§官讼16·206": {
        "leishen": ["进茹：进茹课", "阴人：阴人乘势争财", "少妇：少妇应之", "挫锋：此名挫锋"],
        "liqi": ["进茹课遂连绵起事【原文课体·连茹】", "却幸我行年自前截住终为我遏", "自酉上见戌亥子、年在卯加寅截住此名挫锋→众议俱解", "但前进则胜畏怕则被攻不止"],
        "leixiang": ["亥子丑=进茹(连绵)、卯=截住(挫锋)、阴人少妇=争财"],
        "yingqi": ["挽陈公人调停其事遂止"],
    },
    "§官讼16·207": {
        "leishen": ["破碎：酉(酉乃破碎)", "独足：独足课", "悬针杀：背后悬针杀"],
        "liqi": ["己巳生人见酉乃破碎、支干又皆败于酉酉合己象配字", "行年便作背后悬针杀", "独足不行也【原文课体·独足】", "本年行年加日辰上却成飞散之法、既飞散必再出外方", "酉亥丑传归西北乃江海必润州"],
        "leixiang": ["酉=破碎(悬针配字门)、独足=本州、西北=润州(江海)"],
        "yingqi": ["配本州牢城、再配润州"],
    },
    "§官讼16·208": {
        "leishen": ["龙：午作龙为用", "罡：末又罡加日本"],
        "liqi": ["午作龙为用午火刑胜德", "中巳火又助午伐德", "末又罡加日本→凶课", "主事未了又一事发必吃棒"],
        "leixiang": ["午=火(刑胜德龙)、巳=助午伐德、辰=罡(加日本)"],
        "yingqi": ["必吃棒"],
    },
    "§官讼16·209": {
        "leishen": ["勾：申作勾加身为鬼", "龙：末有龙", "木局：三传曲直"],
        "liqi": ["申作勾加身为鬼→所以枷锢", "却足日德合末有龙→故无事", "三传曲直→应先曲后直【原文课体·曲直】"],
        "leixiang": ["申=勾(鬼枷锢)、卯未=龙(德合)、木局=曲直"],
        "yingqi": ["丙申日被枷后即疏放"],
    },
    "§官讼16·210": {
        "leishen": ["天空：宅上有寡母(天空加宅)", "目：午(午为目被亥克)", "天后：天后为用"],
        "liqi": ["宅上有寡母乃天空加宅", "午为目被亥克→有一女损目", "天后为用→后遇恩赦免", "申金人墓→六年上俱恶死"],
        "leixiang": ["天空=寡母、午=目(亥克)、天后=恩赦、申=金(入墓)"],
        "yingqi": ["蒙恩赦免死编管、六年上俱恶死"],
    },
    "§官讼16·211": {
        "leishen": ["乱首：自取乱首", "勾陈：日加辰作勾", "罡：罡是鬼死奇日墓", "虎：末申又作虎入墓"],
        "liqi": ["自取乱首【原文课体·乱首】", "日加辰作勾上下夹克", "午作元为用日辰上下皆是自刑宅上勾陈俱是天罡", "罡是鬼又是死奇又是日墓", "末申又作虎入墓→其凶不可言恐死不完尸"],
        "leixiang": ["辰=天罡(鬼死奇日墓)、午=元武(自刑)、申=虎(入墓)"],
        "yingqi": ["果处决(死不完尸)"],
    },
    "§官讼16·212": {
        "leishen": ["虎：发用自刑乘虎临门户", "常：中戌作常", "天喜：末天喜乘龙作解神", "龙：解神"],
        "liqi": ["发用自刑乘虎临门户→本主徒罪", "中戌作常", "末天喜乘龙作解神→必有恩赦相救先凶而后吉"],
        "leixiang": ["酉=虎(自刑门户)、戌=常、未=天喜(龙解神)"],
        "yingqi": ["恩赦相救先凶后吉"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec16 202-212）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
