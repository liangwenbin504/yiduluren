# -*- coding: utf-8 -*-
"""把 longmarch_annotations.json 的基础字段同步到 shuzheng_real_cases.json 权威版。
shuzheng 经 _fix_sanchuan_40 + _fix_json_sanchuan_65 + _sike_struct_v2 处理后为最新权威三传/四课/年月。
longmarch 存的是更早的中间快照（79 案三传过时、缺 yue_jiang/shichen/sike 等字段）。
本脚本仅同步基础字段，保留 annotation/status/sec_name 标注结果。
"""
import json

real = json.load(open('engine/shuzheng_real_cases.json', encoding='utf-8'))
lm = json.load(open('data/longmarch_annotations.json', encoding='utf-8'))

real_by = {c['case_id']: c for c in real}

# 从 shuzheng 同步到 longmarch 的字段（基础数据）
SYNC_FIELDS = [
    'sec', 'num', 'name', 'day_ganzhi', 'sanchuan', 'zhanlei', 'zhanlei_code',
    'yue_jiang', 'shichen', 'sike', 'month', 'year', 'age',
    'ben_ming', 'ben_ming_zhi', 'label', 'label_conf', 'label_ev',
    'pdf_page', 'pingshu', 'duanyu', 'xing_nian_zhi',
]

synced_sanchuan = 0
synced_field = 0
missing = []
for c in lm['cases']:
    cid = c['case_id']
    rc = real_by.get(cid)
    if not rc:
        missing.append(cid)
        continue
    for f in SYNC_FIELDS:
        if f in rc:
            old = c.get(f)
            new = rc[f]
            if f == 'sanchuan' and old != new:
                synced_sanchuan += 1
            c[f] = new
            synced_field += 1

# 更新 meta
lm['meta']['source'] = 'engine/shuzheng_real_cases.json (2026-08-16 权威三传·四课·真太阳时天将·补农历月)'
lm['meta']['synced_at'] = '2026-08-16'

json.dump(lm, open('data/longmarch_annotations.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'同步完成：{len(lm["cases"])} 案，三传纠正 {synced_sanchuan} 案')
print(f'缺失案例（shuzheng 无对应）: {missing if missing else "无"}')
