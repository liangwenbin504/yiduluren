# -*- coding: utf-8 -*-
"""壬占汇选 153 案独立评估（M3，与断案老语料分开跑）"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

from engine.ancient_backtest import run_backtest

report = run_backtest(str(BASE / 'engine' / 'ancient_truth_labels_rzhy.json'), methods=['M3'])
s = report['summary']['M3']
print('===== 壬占汇选 153 案 M3 评估 =====')
print(json.dumps(s, ensure_ascii=False, indent=1))
print('\n分类别:')
for cat, st in sorted(report['summary'].get('M3_categories', {}).items()):
    print(f"  {cat}: {st.get('correct',0)}/{st.get('total',0)} = {st.get('accuracy',0)*100:.1f}%")
print('\n判错案例:')
for r in report['detailed_results']['M3']:
    if not r.get('correct'):
        print(f"  {r.get('case_id')} [{r.get('category')}] truth={r.get('truth')} pred={r.get('prediction')}")
