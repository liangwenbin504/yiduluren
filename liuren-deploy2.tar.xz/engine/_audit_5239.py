# -*- coding: utf-8 -*-
"""审计：5239 日是否真·独立起课（而非复用/假盘）"""
import os, sys, time, json
sys.path.insert(0, ".")
import regime_backtest as rb
from liuren_20d_engine import get_liuren_20d_signal

series = rb.parse_index()
print(f"交易日总数: {len(series)}  ({series[0][0]} ~ {series[-1][0]})")

# 1) 抽样 12 个日期（均匀跨全程），打印真实盘局，证明"日→盘"推导且各不相同
print("\n=== 抽样 12 日 真实起课 ===")
idxs = [0, 200, 800, 1500, 2500, 3200, 3900, 4500, 4800, 5100, 5200, 5238]
for i in idxs:
    d, (o, c) = series[i]
    r = get_liuren_20d_signal(d, "午")
    a = r.get("analysis", {})
    bi = r.get("basic_info", {}) or r.get("ri_gan_zhi", "")
    sc = r.get("san_chuan", []) or []
    sk = r.get("si_ke", []) or []
    sc_str = "->".join(str(x) for x in sc)
    sk_str = " | ".join(str(x) for x in sk[:4])
    print(f"  {d} 收{o:.2f}->收{c:.2f} 日干支={bi if isinstance(bi,str) else a.get('ri_gan_zhi','?')} "
          f"三传={sc_str}  四课[0..3]={sk_str}")

# 2) 全量 5239 日：统计不同"日干支·月将·三传"组合数，证明非单一固定盘
print("\n=== 全量 5239 日 盘局多样性 ===")
t0 = time.time()
combos = set()
ganzhi_set = set()
sc_counter = {}
for i, (d, (o, c)) in enumerate(series):
    r = get_liuren_20d_signal(d, "午")
    a = r.get("analysis", {}) or {}
    rgz = a.get("ri_gan_zhi") or (r.get("basic_info", {}) or {}).get("ri_gan_zhi", "?")
    yz = r.get("yue_jiang", "") or a.get("yue_jiang", "")
    sc = "->".join(str(x) for x in (r.get("san_chuan", []) or []))
    combos.add((rgz, yz, sc))
    ganzhi_set.add(rgz)
    sc_counter[sc] = sc_counter.get(sc, 0) + 1
el = time.time() - t0
top = sorted(sc_counter.items(), key=lambda kv: -kv[1])[:5]
print(f"  全量起课耗时: {el:.1f}s ({el/len(series)*1000:.2f} ms/日)")
print(f"  不同 (日干支,月将,三传) 组合: {len(combos)}")
print(f"  不同 日干支: {len(ganzhi_set)} (理论最大60)")
print(f"  出现最多的前5个三传（次数）: {top}")

# 3) 与报告里的 actual 一致性复核（证明用的是真实市场日，非虚构）
rep = json.load(open("engine/regime_backtest_stockval.json", encoding="utf-8"))
print(f"\n=== 交叉核对 ===")
print(f"  报告 n_valid={rep['n_valid']}  base_down={rep['base_down_rate']:.4f}  (实际跌占比)")
print(f"  => 朴素猜涨基线 = {1-rep['base_down_rate']:.4f} = {round((1-rep['base_down_rate'])*rep['n_valid'])} 涨日")
