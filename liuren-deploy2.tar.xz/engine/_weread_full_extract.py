# -*- coding: utf-8 -*-
"""微信读书《壬占汇选》全书提取 - 会员登录态
用法: python engine/_weread_full_extract.py [start] [end] [out_dir]
使用持久化 profile (_weread_profile) 复用登录会话
"""
import asyncio, os, sys, time

PROFILE = os.path.abspath('_weread_profile')
URL = 'https://weread.qq.com/web/reader/33932640813abaad7g018f8ckc81322c012c81e728d9d180'

async def main():
    start = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    end = int(sys.argv[2]) if len(sys.argv) > 2 else 600
    out_dir = sys.argv[3] if len(sys.argv) > 3 else '_weread_full'
    os.makedirs(out_dir, exist_ok=True)

    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE, channel='msedge', headless=True,
            viewport={'width': 1440, 'height': 1000})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto(URL, wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(5000)

        # 登录校验
        cookies = await ctx.cookies()
        if not any('wr_skey' in (c.get('name') or '') for c in cookies):
            print('ERROR: 未登录！请先跑 _weread_login.py')
            await ctx.close()
            return

        # canvas 区域
        box = await page.evaluate('''() => {
            const c = document.querySelector('canvas');
            if (!c) return null;
            const r = c.getBoundingClientRect();
            return {x:r.x, y:r.y, w:r.width, h:r.height};
        }''')
        if not box:
            print('ERROR: canvas未找到')
            await ctx.close()
            return
        clip = {'x': box['x'], 'y': box['y'], 'width': box['w'], 'height': box['h']}
        print(f'canvas: {clip}')

        # 跳到起始页（按 ArrowRight 跳过 start 页）
        if start > 0:
            print(f'跳转到起始页 {start}...')
            for _ in range(start):
                await page.keyboard.press('ArrowRight')
                await page.wait_for_timeout(400)
            await page.wait_for_timeout(2000)

        # 提取 end - start 页
        t0 = time.time()
        blank_streak = 0
        for i in range(start, end):
            path = os.path.join(out_dir, f'p{i:04d}.png')
            await page.screenshot(path=path, clip=clip)
            sz = os.path.getsize(path)
            elapsed = time.time() - t0
            avg = elapsed / (i - start + 1) if i > start else 1
            remaining = avg * (end - i - 1)

            # 检测连续空白（可能已到末尾）
            if sz < 10000:
                blank_streak += 1
                if blank_streak >= 5:
                    print(f'\n连续5页空白，已达书末。结束于 p{i}')
                    break
            else:
                blank_streak = 0

            if i % 20 == 0 or i == end-1:
                print(f'[{i+1}/{end}] p{i} ({sz}B) | {elapsed:.0f}s 已用, ~{remaining:.0f}s 剩余')

            await page.keyboard.press('ArrowRight')
            await page.wait_for_timeout(700)

        print(f'\n完成! 共提取 p{start} ~ p{i}, 用时 {time.time()-t0:.0f}s -> {out_dir}/')
        await ctx.close()

asyncio.run(main())