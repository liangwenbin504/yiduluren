# -*- coding: utf-8 -*-
"""长征第1期 · sec14 六畜走失(9) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§六畜走失14·179": {
        "leishen": ["白虎：戌加亥作白虎", "天目：戌(秋以戌为天目)", "伏尸：宅中有伏尸"],
        "liqi": ["戌加亥作白虎大猪入栏反小只如犬大兼且多病死伤", "牛临寅地自是畏乡岂能长久", "天目在宅宅中有伏尸所以不荣", "天目加支多主伏尸", "秋以戌为天目戌数五故主五年必现影响"],
        "leixiang": ["戌=天目(白虎猪)、寅=牛(畏乡)、伏尸=古冢骸骨"],
        "yingqi": ["五年之内伏尸必伤人", "甲寅三月宅中屡现火光怪异并作"],
    },
    "§六畜走失14·180": {
        "leishen": ["马：午(午为马)", "虎：乘虎加亥为用"],
        "liqi": ["午为马乘虎加亥为用", "自刑加自刑上", "午被亥克→马被虎伤死"],
        "leixiang": ["午=马(虎)、亥=克午"],
        "yingqi": ["五日后马被虎食"],
    },
    "§六畜走失14·181": {
        "leishen": ["马：午(午为马)", "道路：申(道路之上)"],
        "liqi": ["午为马加申道路之上正行也", "被人骑去"],
        "leixiang": ["午=马、申=道路"],
        "yingqi": ["马不见被人骑去"],
    },
    "§六畜走失14·182": {
        "leishen": ["马：午(马属午)", "龙：作龙为用", "门：卯(卯为门)"],
        "liqi": ["马属午作龙为用类神在传", "破门者午破卯卯为门", "墙垣者四土周围"],
        "leixiang": ["午=马(龙)、卯=门(破门)、四土=墙垣"],
        "yingqi": ["己卯日于东方寺院破门入墙内寻见"],
    },
    "§六畜走失14·183": {
        "leishen": ["羊：未(未羊也)", "犬：戌(戌为犬)", "蛇：子作蛇", "虎：寅加未虎啖食"],
        "liqi": ["子作蛇临日为用主非横事", "中未加子作天空未羊也加子为六害羊非水物不宜临子", "戌刑未戌为犬犬伤羊", "子水也此羊被犬赶入水中", "天空无气为器物又为污秽", "寅加未虎又啖食之兽所以伤羊"],
        "leixiang": ["未=羊、戌=犬(刑未)、子=水(蛇)、寅=虎(啖食)"],
        "yingqi": ["当日捉获、羊被犬赶入水宰了藏厕中"],
    },
    "§六畜走失14·184": {
        "leishen": ["羊：未(未为羊)", "太阳：上作太阳月将", "眷属：未(未为眷属)"],
        "liqi": ["伏吟课【原文课体·伏吟】", "未为羊上作太阳月将丁未日又未发用→故在西南", "未为眷属→亲眷家", "伏吟在本位不旺未乃月将五月当相气→故不失"],
        "leixiang": ["未=羊(太阳眷属)、伏吟=本位"],
        "yingqi": ["申时在西南方妻姊家寻见"],
    },
    "§六畜走失14·185": {
        "leishen": ["羊：未(未加卯作龙为用)", "龙：作龙", "木局：曲直"],
        "liqi": ["春占曲直课【原文课体·曲直】", "未加卯作龙为用其羊不失", "初传是类神作龙入传加日辰→故不失"],
        "leixiang": ["未=羊(龙)、卯=东方(园)、木局=曲直"],
        "yingqi": ["东方园内羊群中寻见"],
    },
    "§六畜走失14·186": {
        "leishen": ["狗：戌(戌为类神)", "虎：寅反作虎", "排：卯(卯为排)"],
        "liqi": ["戌为类神加日虽主自归", "戌与寅虽作三合又作六合而寅反作虎在末传克戌→寻不得定被杀了", "寅作虎克戌寅木也→应木排上人", "卯为排夹克戌土"],
        "leixiang": ["戌=狗、寅=虎(木排)、卯=排"],
        "yingqi": ["被木排上人杀了"],
    },
    "§六畜走失14·187": {
        "leishen": ["鸡：酉(酉为鸡)", "犬：戌(戌为用奴偷)", "虎：酉为刃作虎", "阳刃：酉(酉为刃)"],
        "liqi": ["戌为用奴偷也", "酉为刃作虎申亦是虎加酉酉与戌邻→邻近人家", "酉为鸡虽类神入传加日主自归奈何加戌阳刃杀上作虎→如何得活"],
        "leixiang": ["酉=鸡(刃虎)、戌=犬(奴偷)、申=虎"],
        "yingqi": ["被犬冲入邻家奴捉去杀而食之"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec14 179-187）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
