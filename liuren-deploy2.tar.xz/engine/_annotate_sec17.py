# -*- coding: utf-8 -*-
"""长征第1期 · sec17 杂占(6) 标注（全书收尾）"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§杂占17·213": {
        "leishen": ["官鬼：酉加乙作蛇(自缠身)", "蛇：蛇是被监勒", "天空：初寅作天空(官吏)", "太阴：午作太阴(内鬼)"],
        "liqi": ["酉加乙作蛇官鬼自缠身", "乙见酉为官所制蛇是被监勒", "初寅作天空为官吏→若不认必入狱", "中传是认了却无虑", "末子作勾陈是晚而复做", "行年与宅上午作太阴→有人与你阴人是亲眷打关节反探口气报他为内鬼"],
        "leixiang": ["酉=官鬼(蛇)、寅=天空(官吏)、午=太阴(内鬼)、子=勾陈"],
        "yingqi": ["认了方释、自后既脱九年又做一次"],
    },
    "§杂占17·214": {
        "leishen": ["母：子(乙以子为母)", "女：午(午为女)", "父：亥(亥为父)", "翁：申(申为翁)", "墓：丑(丑为墓)"],
        "liqi": ["课名重审末本绝神不合亥子又来生日绝中又起【原文课体·重审】", "乙以子为母午为女亥为父申为翁", "丑为墓申加之是为翁墓", "本命庚戌庚金墓丑是自亦墓此", "申为僧丑为贤上见贵是大和尚"],
        "leixiang": ["子=母、午=女、亥=父、申=翁(僧)、丑=墓(贤贵)"],
        "yingqi": ["四年生一儿为大和尚于广教寺"],
    },
    "§杂占17·215": {
        "leishen": ["阳刃：午(阳刃乘后加支)", "天后：午作天后(妇人)", "炎上：春得炎上局", "鬼：初传是鬼临妇人上"],
        "liqi": ["春得炎上局却喜旺相【原文课体·炎上】", "只是不合阳刃乘后加支→主住持九月与朱姓人交通遂受刑而出", "初传是鬼临妇人上虽三传化火生干然火旺不久便暗", "寅木独为戊鬼身上丑作空正是传法之空门", "丑作天空是荐贤空门之象丑为僧", "炎上局自是有头无尾如火之炎暂时便止", "午作天后是妇人、戊日阳刃在午故主刑"],
        "leixiang": ["午=阳刃(天后妇人朱姓)、寅=鬼、丑=天空(僧空门)、炎上=有头无尾"],
        "yingqi": ["五月受贴六月至观、九月与朱姓人交通受刑而出"],
    },
    "§杂占17·216": {
        "leishen": ["元武：子(子作元武)", "阳刃：丑(丑为阳刃大吉僧寺)", "虎：末虎克日", "连茹：连茹体"],
        "liqi": ["子作元武加日相合即作初传加丑为阳刃大吉又是僧寺", "中传亥加子作常亥即元武类作常加子又是势害", "末虎克日→此课凶", "连茹体也【原文课体·连茹】", "皆因连茹在不明末虎作鬼", "库中者丑为库"],
        "leixiang": ["子=元武(盗)、丑=阳刃(库僧寺)、亥=元武类(势害)、戌=虎(克日)"],
        "yingqi": ["第七日贼入库偷三人物、行者寻踪捉获打死汪氏、解官狱死"],
    },
    "§杂占17·217": {
        "leishen": ["酒：酉(酉为酒加子)", "天空：酉加子作天空"],
        "liqi": ["酉为酒加子酉破子乃破器", "子水败于酉酉金死于子乘空为虚诈又传入空亡→是以无酒"],
        "leixiang": ["酉=酒(破器)、子=水(败)、天空=虚诈空亡"],
        "yingqi": ["酒必败器必破必无酒"],
    },
    "§杂占17·218": {
        "leishen": ["禄：酉(酉于辛为上元真禄)", "龙：酉作龙为用", "天吏：寅(寅乃地下真官又是天吏)"],
        "liqi": ["酉作龙为用酉于辛为上元真禄", "寅乃地下真官又是天吏", "中末又俱自刑", "四上克下名无禄【引擎:课格·无禄】", "天动于上为纯阳主动、若久困在下者遇之而发居家者出"],
        "leixiang": ["酉=禄(龙)、寅=天吏(真官)、自刑"],
        "yingqi": ["将来朝廷必大用威权震上、庚寅再入朝大用"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec17 213-218）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
total = len(r["cases"])
print(f"全项目：{alldone}/{total} 案已标注")
