# -*- coding: utf-8 -*-
"""从《大六壬断案疏正》PDF 文字层精确提取三传 + 断语 + 评疏
三传行级匹配：完整行「六亲+遁干?+地支+天将」，或拆分「六亲」单字行 + 下一行「地支+天将」。
"""
import fitz, re, json

doc = fitz.open('data/大六壬断案疏正.pdf')
ZHI = '子丑寅卯辰巳午未申酉戌亥'
TJ = '后阴玄常虎空青勾合朱蛇贵'
LQ = '财官父兄子鬼比贼'
GAN = '甲乙丙丁戊己庚辛壬癸'

full = '\n'.join(doc[i].get_text() for i in range(len(doc)))
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', full, flags=re.M)]
print('案例标题数:', len(titles))

def extract_sanchuan(seg):
    """行级提取三传（3 地支）"""
    lines = seg.split('\n')
    result = []
    for i, ln in enumerate(lines):
        s = ln.strip()
        if not s:
            continue
        # 完整三传行：六亲+遁干?+地支+天将
        m = re.fullmatch(r'[' + LQ + r'](?:[' + GAN + r'])?([' + ZHI + r'])[' + TJ + r']', s)
        if m:
            result.append(m.group(1))
            continue
        # 拆分：六亲单字行，下一行是「地支+天将」
        if re.fullmatch(r'[' + LQ + r']', s):
            if i + 1 < len(lines):
                s2 = lines[i + 1].strip()
                m2 = re.fullmatch(r'([' + ZHI + r'])[' + TJ + r']', s2)
                if m2:
                    result.append(m2.group(1))
    return result[:3]

cases = []
for i, m in enumerate(titles):
    start = m.start()
    end = titles[i + 1].start() if i + 1 < len(titles) else len(full)
    block = full[start:end]
    case_id = f'§{m.group(1)}{m.group(2)}·{m.group(3)}'
    head = block[:300]
    gz = ''
    m2 = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])日', head)
    if m2:
        gz = m2.group(1)
    mj = re.search(r'([子丑寅卯辰巳午未申酉戌亥])将', head)
    yj = mj.group(1) if mj else ''
    ms = re.search(r'([子丑寅卯辰巳午未申酉戌亥])时', head)
    shi = ms.group(1) if ms else ''
    seg = re.split(r'邵先生曰|邵彦和曰|邵先先曰', block)[0]
    sanchuan = extract_sanchuan(seg)
    m3 = re.search(r'邵先生曰[:：]?(.*?)(?:【评疏】|§|$)', block, re.S)
    duanyu = re.sub(r'\s+', '', m3.group(1)) if m3 else ''
    m4 = re.search(r'【评疏】[:：]?(.*?)(?:§|$)', block, re.S)
    pingshu = re.sub(r'\s+', '', m4.group(1)) if m4 else ''
    cases.append({'case_id': case_id, 'day_ganzhi': gz, 'yue_jiang': yj, 'shichen': shi,
                  'sanchuan': sanchuan, 'duanyu': duanyu, 'pingshu': pingshu})

json.dump(cases, open('data/_pdf_textlayer_cases.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
short = [c for c in cases if len(c['sanchuan']) < 3]
print(f'提取 {len(cases)} 案，三传不足3: {len(short)} 案')
for c in short[:20]:
    print(f"  不足: {c['case_id']} 三传{''.join(c['sanchuan'])}")
