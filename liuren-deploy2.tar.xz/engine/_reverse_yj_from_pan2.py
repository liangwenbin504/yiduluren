# -*- coding: utf-8 -*-
"""从天地盘反推月将 v2（行首正则提取盘面）"""
import json, re

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'
with open(SRC, encoding='utf-8') as f:
    cases = json.load(f)

TJ = '贵蛇朱六勾青龙空虎常玄阴后'
ZHI = '子丑寅卯辰巳午未申酉戌亥'
PAN_PAT = re.compile(f'^([{TJ}])([{ZHI}]{{2,4}})([{TJ}])')

# 地盘布局（4行）
DI_PAN_LAYOUT = [['巳','午','未','申'], ['辰','酉'], ['卯','戌'], ['寅','丑','子','亥']]

def extract_pan_rows(body):
    """提取盘面4行：行首匹配 天将+2~4地支+天将"""
    rows = []
    for ln in body.split('\n'):
        ln = ln.strip()
        if not ln:
            continue
        m = PAN_PAT.match(ln)
        if m:
            rows.append(list(m.group(2)))
            if len(rows) == 4:
                break
    return rows

def reverse_yj(rows, shichen):
    if len(rows) < 4:
        return '', f'盘面行不足({len(rows)})'
    di_to_tian = {}
    for row_zhi, di_row in zip(rows, DI_PAN_LAYOUT):
        for i, t in enumerate(row_zhi):
            if i < len(di_row):
                di_to_tian[di_row[i]] = t
    if shichen not in di_to_tian:
        return '', f'时辰{shichen}不在盘面'
    return di_to_tian[shichen], ''

# 已知月将验证
KNOWN = [('选举','四','巳','子'), ('仕宦','三十四','未','寅'), ('仕宦','三十六','申','亥')]
print('=== 已知月将验证 ===')
for ch, num, shi, expect in KNOWN:
    for c in cases:
        if c['章节'] == ch and c['编号'] == num:
            rows = extract_pan_rows(c['正文'])
            yj, err = reverse_yj(rows, shi)
            ok = '✓' if yj == expect else '✗'
            print(f'  {ch}/{num} {c["日干支"]} {shi}时 反推={yj}将 期望={expect}将 {ok} {err}')
            break

# 全量
print('\n=== 全量反推 78案 ===')
results = []
for c in cases:
    if not (c['日干支'] and c['月'] and c['时辰'] and c.get('label') in ('吉','凶')):
        continue
    shi = c['时辰'][-1]
    rows = extract_pan_rows(c['正文'])
    yj, err = reverse_yj(rows, shi)
    results.append({'章节':c['章节'],'编号':c['编号'],'日干支':c['日干支'],'月':c['月'],
                    '时辰':c['时辰'],'月将':yj,'err':err})
ok = [r for r in results if r['月将']]
print(f'总{len(results)} | 反推成功 {len(ok)} | 失败 {len(results)-len(ok)}')
for r in results:
    if not r['月将']:
        print(f"  失败: {r['章节']}/{r['编号']} {r['日干支']} {r['月']} {r['时辰']} {r['err']}")
with open('extracted_data/_guji_fetch/指南卷三_反推月将.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=1)
print('已保存 指南卷三_反推月将.json')
