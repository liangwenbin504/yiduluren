# -*- coding: utf-8 -*-
"""亡盗14案：全量信号诊断 + 预测，检验「寻得=吉」规则可行性。"""
import json, sys
sys.path.insert(0, ".")
from engine.ancient_backtest import build_result_from_ancient
import engine.judgment_fusion as jf

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")
def ok(x): return isinstance(x, str) and x in VALID

hits = [c for c in REAL if '亡盗' in str(c.get('case_id',''))]
hits.sort(key=lambda c: int(str(c.get('case_id','')).split('·')[-1]))

rows = []
for c in hits:
    sc = c.get('sanchuan') or []
    clean = {'id':c['case_id'],'name':c.get('name',''),'category':c.get('zhanlei','其他'),
             'rizhu':c['day_ganzhi'],'yue_jiang':c['yue_jiang'] if ok(c.get('yue_jiang')) else '',
             'shichen':c['shichen'] if ok(c.get('shichen')) else '','sanchuan':sc,'keti':[],
             'label':c.get('label'),'label_confidence':c.get('label_conf',0),
             'month':c.get('month'),'ben_ming_zhi':c.get('ben_ming_zhi'),'year':c.get('year') or '',
             'leishen':c.get('leishen','')}
    result = build_result_from_ancient(clean)
    sigs = jf.collect_signals(result)
    fused = jf.fuse(result)
    trend = fused.get('trend')
    total = sum(sc2 for _, sc2, _, _ in sigs)
    a = result.get('analysis') or {}
    rows.append((c['case_id'], c.get('label'), trend, total,
                 {g: sc2 for g, sc2, _, _ in sigs},
                 a.get('_zhanlei'), a.get('ba_sha')))

print(f'{"case":<14}{"truth":<4}{"pred":<4}{"Σ":>7}  信号分解')
for cid, lab, trend, total, sigmap, zl, bsha in rows:
    pred = '吉' if trend=='看涨' else ('凶' if trend=='看跌' else '平')
    flag = '  <<<' if pred != lab else ''
    parts = ' '.join(f'{g}:{v:+.1f}' for g,v in sorted(sigmap.items(), key=lambda x:-abs(x[1])))
    print(f'{cid:<14}{lab:<4}{pred:<4}{total:>+7.2f}  {parts}{flag}')

# 关键问题：寻得11案 vs 真凶3案，有无干净分离特征？
print()
print('=== 分类检验 ===')
def truth_outcome(cid):
    # 原文结局：寻得=吉, 未寻得=凶
    return '吉' if cid.split('·')[-1] not in ('189','196','201') else '凶'
for cid, lab, trend, total, sigmap, zl, bsha in rows:
    true_o = truth_outcome(cid)
    print(f'{cid} 原文结局={true_o} 现标={lab} 引擎pred={trend} Σ={total:+.2f}')
