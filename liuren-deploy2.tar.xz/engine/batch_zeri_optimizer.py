#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量择日优化器 (Batch Zeri Optimizer)
======================================
在 3/5/10 年时间范围内，为每山选出最优日课。

三阶段漏斗策略：
  Phase 1 (斗首快筛): 预计算全量四柱 → 斗首评分 → 每山保留 TOP-N
  Phase 2 (到山到向):  对候选计算天地盘 → 到山到向加分 → 每山保留 TOP-M
  Phase 3 (完整六壬):  对候选计算三传 → 拱格/活禄马 → 最终排名输出

时间复杂度估算（10年=3652天）：
  Phase 1: 3652天 × 12时辰 × 24山 = 1,051,776 次 O(1) 检查 → ~3秒
  Phase 2: 500候选/山 × 24山 = 12,000 次天地盘 → ~2秒
  Phase 3: 50候选/山 × 24山 = 1,200 次三传 → ~10秒
  总计: ~15秒（10年范围）
"""

import json, os, time, sys
from datetime import datetime, timedelta, date
from typing import Dict, List, Tuple, Optional
from collections import defaultdict
from dataclasses import dataclass, field, asdict

# 添加项目根目录
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from engine.sizhu_engine import get_sizhu, get_day_ganzhi, get_hour_ganzhi
from engine.yidu_liuren_yaojue import (
    SHAN_JIA_MAP, XIANG_SHOU, ZHI_LIST, LU, get_yima, JIGONG,
    get_doushou_class, get_yuanchen_gans,
    check_sizhu_tou_yuanchen, check_liuxiang_liuti,
    check_sanyuan_sanwu_yilian, check_jixiong_position,
    check_all_gong_patterns, check_huoma_huolu,
    check_chaotian_ge, check_guiyuan_ge, check_luowen_ge,
    check_longde_ke, check_lu_daoshan_daoxiang,
    check_ma_daoshan_daoxiang, check_guiren_daoshan_daoxiang,
    check_buyuan_methods, SHAN_DOUSHO, analyze_yidu_full, score_doushou_liuxiang,
)
from engine.daliuren_luma_guiren import DaLiuRenLuMaGuiRen, arrange_tiandi_pan
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
from engine.gui_ren_engine import GuiRenCalculator
from data.斗首择日规则 import DIZHI, GUIREN

# 12时辰
SHICHEN_LIST = list(DIZHI)

# 所有24山
ALL_MOUNTAINS = list(SHAN_JIA_MAP.keys())


@dataclass
class Candidate:
    """日课候选"""
    date_str: str           # '2026-07-15'
    shichen: str            # '巳'
    mountain: str           # '壬'
    nian_gan: str = ''
    nian_zhi: str = ''
    yue_gan: str = ''
    yue_zhi: str = ''
    ri_gan: str = ''
    ri_zhi: str = ''
    shi_gan: str = ''
    shi_zhi: str = ''
    
    # Phase 1 评分
    score_phase1: float = 0
    doushou_details: dict = field(default_factory=dict)
    
    # Phase 2 评分
    score_phase2: float = 0
    daoshan_details: dict = field(default_factory=dict)
    tiandi_pan: dict = None
    
    # Phase 3 评分
    score_phase3: float = 0
    gong_patterns: list = field(default_factory=list)
    huoma_details: dict = field(default_factory=dict)
    advanced_patterns: dict = field(default_factory=dict)
    buyuan_details: dict = field(default_factory=dict)
    # 统一口径拆解项（来自 analyze_yidu_full，三项之和 = total_score，供前端展示）
    yidu_liuxiang: float = 0   # 六想/斗首基础分
    yidu_daoshan: float = 0    # 到山到向分
    yidu_liuren: float = 0     # 六壬课格分（拱格+活禄马+高级格+补元）
    yidu_result: dict = field(default_factory=dict)
    total_score: float = 0
    grade: str = ''
    
    # 三传信息
    sanchuan: dict = None
    
    def to_dict(self) -> dict:
        """精简输出（去除冗余）"""
        return {
            'date': self.date_str,
            'shichen': self.shichen,
            'mountain': self.mountain,
            'sizhu': f'{self.nian_gan}{self.nian_zhi} {self.yue_gan}{self.yue_zhi} {self.ri_gan}{self.ri_zhi} {self.shi_gan}{self.shi_zhi}',
            'total_score': round(self.total_score, 1),
            'grade': self.grade,
            'phase1_score': round(self.score_phase1, 1),
            'phase2_score': round(self.score_phase2, 1),
            'phase3_score': round(self.score_phase3, 1),
            'doushou_classes': self.doushou_details.get('classes', {}),
            'yuanchen': self.doushou_details.get('yuanchen_ok', False),
            'sanyuan_grade': self.doushou_details.get('sanyuan_grade', ''),
            'gong_count': len([p for p in self.gong_patterns if p.get('matched')]),
            'gong_names': [p['name'] for p in self.gong_patterns if p.get('matched')],
            'huoma_count': self.huoma_details.get('count', 0),
            'daoshan_count': self.daoshan_details.get('total_count', 0),
        }


class BatchZeriOptimizer:
    """
    批量择日优化器
    三阶段漏斗筛选 + 最终排名
    """
    
    def __init__(self, start_date: date, end_date: date,
                 mountains: List[str] = None,
                 phase1_top: int = 500,
                 phase2_top: int = 50,
                 phase3_top: int = 20,
                 verbose: bool = True):
        """
        参数:
            start_date: 起始日期
            end_date: 结束日期
            mountains: 要分析的24山列表（默认全部）
            phase1_top: Phase1 每山保留候选数
            phase2_top: Phase2 每山保留候选数
            phase3_top: Phase3 每山最终输出数
            verbose: 是否输出进度
        """
        self.start_date = start_date
        self.end_date = end_date
        self.mountains = mountains or ALL_MOUNTAINS
        self.phase1_top = phase1_top
        self.phase2_top = phase2_top
        self.phase3_top = phase3_top
        self.verbose = verbose
        
        # 预计算缓存
        self._sizhu_cache: Dict[str, dict] = {}  # key: "YYYY-MM-DD"
        self._luma_engine = DaLiuRenLuMaGuiRen()
        self._tiandi_pan_cache: Dict[str, dict] = {}  # key: "月将_时辰"
        
        # 统计
        self.stats = {
            'days': 0, 'phase1_checked': 0, 'phase2_checked': 0, 'phase3_checked': 0,
            'phase1_candidates': 0, 'phase2_candidates': 0, 'phase3_candidates': 0,
        }
    
    def _log(self, msg: str):
        if self.verbose:
            print(msg)
    
    # ═══════════════════════════════════════════════
    # 预计算：全日期范围四柱
    # ═══════════════════════════════════════════════
    
    def precompute_sizhu(self):
        """预计算整个日期范围内所有四柱（年/月/日）"""
        self._log(f'\n[预计算] 计算 {self.start_date} ~ {self.end_date} 四柱...')
        t0 = time.time()
        
        current = self.start_date
        while current <= self.end_date:
            key = current.strftime('%Y-%m-%d')
            sizhu = get_sizhu(current.year, current.month, current.day, '子')
            self._sizhu_cache[key] = {
                'nian_gan': sizhu['年柱'][0],
                'nian_zhi': sizhu['年柱'][1],
                'yue_gan': sizhu['月柱'][0],
                'yue_zhi': sizhu['月柱'][1],
                'ri_gan': sizhu['日柱'][0],
                'ri_zhi': sizhu['日柱'][1],
            }
            current += timedelta(days=1)
        
        elapsed = time.time() - t0
        self.stats['days'] = len(self._sizhu_cache)
        self._log(f'[预计算] 完成 {self.stats["days"]} 天，耗时 {elapsed:.1f}s')
    
    # ═══════════════════════════════════════════════
    # Phase 1: 斗首快筛
    # ═══════════════════════════════════════════════
    
    def _score_phase1(self, nian_gan: str, nian_zhi: str,
                       yue_gan: str, yue_zhi: str,
                       ri_gan: str, ri_zhi: str,
                       shi_gan: str, shi_zhi: str,
                       mountain: str) -> Tuple[float, dict]:
        """
        Phase 1 快筛：与单课权威评分 analyze_yidu_full 的 A 段（斗首六想）同口径。
        仅用 O(1) 斗首规则，不做六壬；最终排名以 Phase 3 的 analyze_yidu_full 分为准。
        （去掉原自研「元辰±」「贪破在六相」扣分，避免误杀权威高分课）
        """
        year_pillar = nian_gan + nian_zhi
        month_pillar = yue_gan + yue_zhi
        day_pillar = ri_gan + ri_zhi
        hour_pillar = shi_gan + shi_zhi

        # 六想评分（与权威分析一致的基础分）
        liuxiang = score_doushou_liuxiang(year_pillar, month_pillar, day_pillar, hour_pillar, mountain)
        score = liuxiang['score']

        # 斗首类别 + 三元三武一廉
        classes = {
            '年': get_doushou_class(mountain, year_pillar),
            '月': get_doushou_class(mountain, month_pillar),
            '日': get_doushou_class(mountain, day_pillar),
            '时': get_doushou_class(mountain, hour_pillar),
        }
        sanyuan = check_sanyuan_sanwu_yilian(
            classes['年'], classes['月'], classes['日'], classes['时']
        )
        if sanyuan.get('is_first_jike'):
            score += 15
        elif sanyuan.get('grade'):
            score += 8

        # 凶吉内外
        jixiong = check_jixiong_position(classes)
        score += jixiong['score']

        # 元辰仅作合格性记录（不参与快筛分，与权威评分口径一致）
        yuanchen_ok = check_sizhu_tou_yuanchen(
            year_pillar, month_pillar, day_pillar, hour_pillar, mountain
        ).get('has_yuanchen', False)

        details = {
            'classes': classes,
            'sanyuan_grade': sanyuan.get('grade', ''),
            'liuxiang_score': liuxiang['score'],
            'yuanchen_ok': yuanchen_ok,
        }
        return max(20, min(100, score)), details
    
    def run_phase1(self) -> Dict[str, List[Candidate]]:
        """
        Phase 1: 遍历所有日期×时辰×山，斗首评分后保留每山TOP-N
        """
        self._log(f'\n[Phase 1] 斗首快筛: {len(self._sizhu_cache)}天 × 12时辰 × {len(self.mountains)}山')
        self._log(f'[Phase 1] 预计检查 {len(self._sizhu_cache) * 12 * len(self.mountains):,} 次')
        t0 = time.time()
        
        # 每山保留TOP candidate
        mountain_candidates: Dict[str, List[Candidate]] = {
            m: [] for m in self.mountains
        }
        
        checked = 0
        for date_key, sizhu in self._sizhu_cache.items():
            nian_gan = sizhu['nian_gan']
            nian_zhi = sizhu['nian_zhi']
            yue_gan = sizhu['yue_gan']
            yue_zhi = sizhu['yue_zhi']
            ri_gan = sizhu['ri_gan']
            ri_zhi = sizhu['ri_zhi']
            
            # 日干日支不变，但时柱随时辰变
            for shichen in SHICHEN_LIST:
                shi_gan, shi_zhi = get_hour_ganzhi(ri_gan, shichen)
                
                for mountain in self.mountains:
                    checked += 1
                    score, details = self._score_phase1(
                        nian_gan, nian_zhi, yue_gan, yue_zhi,
                        ri_gan, ri_zhi, shi_gan, shi_zhi, mountain
                    )
                    
                    # 阈值过滤：至少 35 分才考虑
                    if score < 35:
                        continue
                    
                    cand = Candidate(
                        date_str=date_key,
                        shichen=shichen,
                        mountain=mountain,
                        nian_gan=nian_gan, nian_zhi=nian_zhi,
                        yue_gan=yue_gan, yue_zhi=yue_zhi,
                        ri_gan=ri_gan, ri_zhi=ri_zhi,
                        shi_gan=shi_gan, shi_zhi=shi_zhi,
                        score_phase1=score,
                        doushou_details=details,
                    )
                    
                    # 插入排序保持TOP-N
                    heap = mountain_candidates[mountain]
                    heap.append(cand)
                    heap.sort(key=lambda c: c.score_phase1, reverse=True)
                    if len(heap) > self.phase1_top:
                        heap.pop()
        
        self.stats['phase1_checked'] = checked
        elapsed = time.time() - t0
        
        total_candidates = sum(len(v) for v in mountain_candidates.values())
        self.stats['phase1_candidates'] = total_candidates
        
        self._log(f'[Phase 1] 完成: 检查{checked:,}次, 保留{total_candidates:,}候选, 耗时{elapsed:.1f}s')
        for m in sorted(mountain_candidates.keys())[:5]:
            c = mountain_candidates[m]
            if c:
                top_score = c[0].score_phase1
                self._log(f'  {m}山: {len(c)}候选, 最高分 {top_score}')
        
        return mountain_candidates
    
    # ═══════════════════════════════════════════════
    # Phase 2: 天地盘 + 到山到向
    # ═══════════════════════════════════════════════
    
    def _score_phase2(self, cand: Candidate) -> Tuple[float, dict]:
        """
        Phase 2 评分：天地盘 + 到山到向
        满分 20 分
        """
        score = 0
        details = {}
        
        # 计算月将（按《大六壬通解》节气中气，2026-08-15 憨爷指正：原按地支月错误）
        _yd = cand.date_str.split('-')
        yuejiang = self._luma_engine.get_yuejiang_by_date(int(_yd[0]), int(_yd[1]), int(_yd[2]))
        tiandi_pan = arrange_tiandi_pan(yuejiang, cand.shichen)
        cand.tiandi_pan = tiandi_pan
        
        shan_jia = SHAN_JIA_MAP.get(cand.mountain, '')
        xiang_shou = XIANG_SHOU.get(cand.mountain, shan_jia)
        
        # 到山到向
        lu_zhi = LU.get(cand.ri_gan, '')
        ma_zhi = get_yima(cand.ri_zhi)
        guiren_zhi = list(GUIREN.get(cand.ri_gan, []))
        
        lu_dsdx = check_lu_daoshan_daoxiang(lu_zhi, shan_jia, xiang_shou)
        ma_dsdx = check_ma_daoshan_daoxiang(ma_zhi, shan_jia, xiang_shou)
        guiren_dsdx = check_guiren_daoshan_daoxiang(guiren_zhi, shan_jia, xiang_shou)
        
        dsdx_count = sum([lu_dsdx['is_daoshan_daoxiang'],
                          ma_dsdx['is_daoshan_daoxiang'],
                          guiren_dsdx['is_daoshan_daoxiang']])
        
        details = {
            'lu': lu_dsdx, 'ma': ma_dsdx, 'guiren': guiren_dsdx,
            'total_count': dsdx_count,
        }
        
        # 到山到向得分: 每项+5, 全中+5 bonus
        score += dsdx_count * 5
        if dsdx_count >= 2:
            score += 5  # bonus
        
        # 朝天格/归垣格 (Phase 2能判断)
        chaotian = check_chaotian_ge(tiandi_pan, cand.ri_gan, guiren_zhi)
        guiyuan = check_guiyuan_ge(tiandi_pan, cand.ri_zhi, guiren_zhi)
        if chaotian['matched']:
            score += 5
            details['chaotian'] = True
        if guiyuan['matched']:
            score += 3
            details['guiyuan'] = True
        
        return min(20, score), details
    
    def run_phase2(self, mountain_candidates: Dict[str, List[Candidate]]) -> Dict[str, List[Candidate]]:
        """
        Phase 2: 对Phase1候选计算天地盘+到山到向，每山保留TOP
        """
        self._log(f'\n[Phase 2] 到山到向分析: {sum(len(v) for v in mountain_candidates.values()):,}候选')
        t0 = time.time()
        
        checked = 0
        for mountain, candidates in mountain_candidates.items():
            for cand in candidates:
                checked += 1
                score, details = self._score_phase2(cand)
                cand.score_phase2 = score
                cand.daoshan_details = details
                # 累计分数
                cand.total_score = cand.score_phase1 + cand.score_phase2
            
            # 按总分开排序，保留TOP
            candidates.sort(key=lambda c: c.total_score, reverse=True)
            if len(candidates) > self.phase2_top:
                del candidates[self.phase2_top:]
        
        self.stats['phase2_checked'] = checked
        elapsed = time.time() - t0
        total_candidates = sum(len(v) for v in mountain_candidates.values())
        self.stats['phase2_candidates'] = total_candidates
        
        self._log(f'[Phase 2] 完成: 检查{checked:,}候选, 保留{total_candidates:,}, 耗时{elapsed:.1f}s')
        
        return mountain_candidates
    
    # ═══════════════════════════════════════════════
    # Phase 3: 完整六壬 (三传 + 拱格 + 活禄马)
    # ═══════════════════════════════════════════════
    
    def _score_phase3(self, cand: Candidate) -> Tuple[float, dict]:
        """
        Phase 3 评分：完整六壬分析（与单课 /api/zeri/analyze 同口径）
        —— 改用 sike_sanchuan_engine 起课（修双引擎），直接调用权威函数
           analyze_yidu_full 取最终评分（与单课详情完全一致，统一口径）。
        返回: (total_score, yidu_result_dict)
        """
        try:
            calc = SiKeSanChuanCalculator2()
            _yd = cand.date_str.split('-')
            yuejiang = self._luma_engine.get_yuejiang_by_date(int(_yd[0]), int(_yd[1]), int(_yd[2]))
            tdp = calc.get_tiandi_pan(yuejiang, cand.shichen)
            cand.tiandi_pan = tdp

            # 四课三传（统一引擎）
            sike = calc.qi_sike(cand.ri_gan, cand.ri_zhi, tdp)
            sc = calc.fa_sanchuan(sike, cand.ri_gan, cand.ri_zhi, tdp)
            chuan_list = sc.get('三传', [])
            sanchuan = {
                '初传': chuan_list[0] if len(chuan_list) > 0 else '',
                '中传': chuan_list[1] if len(chuan_list) > 1 else '',
                '末传': chuan_list[2] if len(chuan_list) > 2 else '',
                '课体': sc.get('课体', ''),
            }
            cand.sanchuan = sanchuan

            # 天将映射（用于龙德课等，与单课同口径）
            _tj_map = GuiRenCalculator().arrange_gui_ren_pan(
                cand.ri_gan, {'天地对应': tdp}, cand.shichen)
            tianjiang_map = _tj_map.get('天将映射', {})

            # 权威评分（与单课 /api/zeri/analyze 完全一致的引擎 + 公式 + 评级线）
            yidu = analyze_yidu_full(
                shan=cand.mountain,
                year_pillar=cand.nian_gan + cand.nian_zhi,
                month_pillar=cand.yue_gan + cand.yue_zhi,
                day_pillar=cand.ri_gan + cand.ri_zhi,
                hour_pillar=cand.shi_gan + cand.shi_zhi,
                ri_gan=cand.ri_gan,
                ri_zhi=cand.ri_zhi,
                sanchuan=sanchuan,
                tiandi_pan=tdp,
                tianjiang_map=tianjiang_map,
                yue_jiang=yuejiang,
                nian_zhi=cand.nian_zhi,
            )

            # 挂接结果
            cand.gong_patterns = yidu.get('gong_patterns', [])
            cand.daoshan_details = yidu.get('daoshan_daoxiang', {})
            cand.huoma_details = yidu.get('huoma_huolu', {})
            cand.buyuan_details = yidu.get('buyuan', {})
            cand.advanced_patterns = yidu.get('advanced_patterns', {})
            cand.yidu_result = yidu

            # 拆解三项（供前端"斗首+到向+六壬"展示，三项之和 = total）
            cand.yidu_liuxiang = float(yidu.get('doushou', {}).get('liuxiang_score', {}).get('score', 0))
            cand.yidu_daoshan = float(cand.daoshan_details.get('total_count', 0) * 5)
            cand.yidu_liuren = float(yidu['total_score'] - cand.yidu_liuxiang - cand.yidu_daoshan)

            return yidu['total_score'], yidu
        except Exception as e:
            cand.gong_patterns = []
            cand.daoshan_details = {}
            cand.huoma_details = {}
            cand.yidu_liuxiang = cand.yidu_daoshan = cand.yidu_liuren = 0
            cand.yidu_result = {'error': str(e)}
            return 0.0, {'error': str(e)}
    
    def run_phase3(self, mountain_candidates: Dict[str, List[Candidate]]) -> Dict[str, List[Candidate]]:
        """
        Phase 3: 对Phase2候选计算完整六壬，最终排名
        """
        total = sum(len(v) for v in mountain_candidates.values())
        self._log(f'\n[Phase 3] 完整六壬分析: {total:,}候选（三传计算较慢）')
        t0 = time.time()
        
        checked = 0
        for mountain, candidates in mountain_candidates.items():
            for cand in candidates:
                checked += 1
                try:
                    yidu_total, yidu = self._score_phase3(cand)
                except Exception as e:
                    yidu_total, yidu = 0.0, {'error': str(e)}

                # 统一口径：最终分 = 权威 analyze_yidu_full 分（与单课一致）
                cand.total_score = yidu_total
                cand.grade = yidu.get('grade', '不宜')
                # 前端"斗首/到向/六壬"三项展示（来自 yidu 拆解，三项之和 = total）
                cand.score_phase1 = cand.yidu_liuxiang
                cand.score_phase2 = cand.yidu_daoshan
                cand.score_phase3 = cand.yidu_liuren
            
            # 按总分排序，保留TOP
            candidates.sort(key=lambda c: c.total_score, reverse=True)
            if len(candidates) > self.phase3_top:
                del candidates[self.phase3_top:]
        
        self.stats['phase3_checked'] = checked
        elapsed = time.time() - t0
        total_candidates = sum(len(v) for v in mountain_candidates.values())
        self.stats['phase3_candidates'] = total_candidates
        
        self._log(f'[Phase 3] 完成: 检查{checked:,}候选, 保留{total_candidates:,}, 耗时{elapsed:.1f}s')
        
        return mountain_candidates
    
    # ═══════════════════════════════════════════════
    # 主流程 + 结果导出
    # ═══════════════════════════════════════════════
    
    def optimize(self) -> Dict[str, List[Candidate]]:
        """
        完整三阶段优化流程
        返回: {mountain: [Candidate, ...]}
        """
        t_start = time.time()
        self._log('=' * 60)
        self._log(f'批量择日优化: {self.start_date} ~ {self.end_date}')
        self._log(f'范围: {(self.end_date - self.start_date).days + 1} 天')
        self._log(f'目标: {len(self.mountains)} 山')
        self._log('=' * 60)
        
        # Phase 1
        self.precompute_sizhu()
        results = self.run_phase1()
        
        # Phase 2
        results = self.run_phase2(results)
        
        # Phase 3
        results = self.run_phase3(results)
        
        elapsed = time.time() - t_start
        self._log(f'\n{"=" * 60}')
        self._log(f'优化完成！总耗时 {elapsed:.1f}s ({elapsed/60:.1f}分钟)')
        self._log(f'Phase1: {self.stats["phase1_checked"]:,}次检查 → {self.stats["phase1_candidates"]}候选')
        self._log(f'Phase2: {self.stats["phase2_checked"]:,}次分析 → {self.stats["phase2_candidates"]}候选')
        self._log(f'Phase3: {self.stats["phase3_checked"]:,}次深度分析 → {self.stats["phase3_candidates"]}最终')
        
        # 打印每山TOP-3摘要
        self._log(f'\n每山最优课摘要:')
        self._log(f'{">" * 80}')
        for mountain in sorted(results.keys()):
            cands = results[mountain]
            if not cands:
                self._log(f'  {mountain}山: 无合格候选')
                continue
            xiang = SHAN_JIA_MAP.get(mountain, '')
            self._log(f'\n🏔 {mountain}山(坐{mountain}向{xiang}):')
            for i, c in enumerate(cands[:3]):
                self._log(f'  #{i+1} {c.date_str} {c.shichen}时 | '
                         f'{c.nian_gan}{c.nian_zhi}.{c.yue_gan}{c.yue_zhi}.{c.ri_gan}{c.ri_zhi}.{c.shi_gan}{c.shi_zhi}')
                gong_count = len([p for p in c.gong_patterns if p.get('matched', False)])
                huo_count = c.huoma_details.get('count', 0) if hasattr(c.huoma_details, 'get') else 0
                dsdx_count = c.daoshan_details.get('total_count', 0) if hasattr(c.daoshan_details, 'get') else 0
                self._log(f'       总分{c.total_score:.1f} [{c.grade}] | '
                         f'斗首{c.score_phase1:.0f}+到向{c.score_phase2:.0f}+六壬{c.score_phase3:.0f} | '
                         f'拱{gong_count}活{huo_count}到{dsdx_count}')
        
        return results
    
    def export_results(self, results: Dict[str, List[Candidate]],
                       output_path: str = None) -> str:
        """导出结果为JSON文件"""
        if output_path is None:
            d1 = self.start_date.strftime('%Y%m%d')
            d2 = self.end_date.strftime('%Y%m%d')
            output_path = os.path.join(PROJECT_ROOT, 'data', f'zeri_optimize_{d1}_{d2}.json')
        
        output = {
            'meta': {
                'start_date': self.start_date.isoformat(),
                'end_date': self.end_date.isoformat(),
                'days': self.stats['days'],
                'mountains': len(self.mountains),
                'elapsed_stats': self.stats,
            },
            'results': {}
        }
        
        for mountain, candidates in results.items():
            output['results'][mountain] = [c.to_dict() for c in candidates]
        
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        
        self._log(f'\n结果已导出: {output_path}')
        return output_path


# ═══════════════════════════════════════════════
# 便捷函数
# ═══════════════════════════════════════════════

def optimize_for_years(years: int = 3,
                        start_year: int = None,
                        mountains: List[str] = None,
                        phase1_top: int = 500,
                        phase2_top: int = 50,
                        phase3_top: int = 20,
                        output_path: str = None) -> str:
    """
    便捷函数：优化N年择日

    参数:
        years: 年数 (3/5/10)
        start_year: 起始年份（默认从今天开始）
        mountains: 山列表（默认全部24山）
        phase1/2/3_top: 各阶段保留数
        output_path: 输出文件路径

    返回: 输出JSON路径
    """
    from datetime import date
    
    if start_year is None:
        start = date.today()
    else:
        start = date(start_year, 1, 1)
    
    end = date(start.year + years - 1, 12, 31)
    
    optimizer = BatchZeriOptimizer(
        start_date=start,
        end_date=end,
        mountains=mountains,
        phase1_top=phase1_top,
        phase2_top=phase2_top,
        phase3_top=phase3_top,
        verbose=True,
    )
    
    results = optimizer.optimize()
    return optimizer.export_results(results, output_path)


# ═══════════════════════════════════════════════
# 命令行入口
# ═══════════════════════════════════════════════

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='批量择日优化器')
    parser.add_argument('--years', type=int, default=3, help='年数 (默认3)')
    parser.add_argument('--start', type=str, default=None, help='起始日期 YYYY-MM-DD')
    parser.add_argument('--mountains', type=str, default=None, help='山列表，逗号分隔 (默认全部)')
    parser.add_argument('--p1', type=int, default=500, help='Phase1每山保留数')
    parser.add_argument('--p2', type=int, default=50, help='Phase2每山保留数')
    parser.add_argument('--p3', type=int, default=20, help='Phase3每山输出数')
    parser.add_argument('--output', type=str, default=None, help='输出文件路径')
    
    args = parser.parse_args()
    
    mountains = None
    if args.mountains:
        mountains = [m.strip() for m in args.mountains.split(',')]
    
    if args.start:
        start_date = date.fromisoformat(args.start)
        end_date = date(start_date.year + args.years - 1, 12, 31)
        optimizer = BatchZeriOptimizer(
            start_date=start_date, end_date=end_date,
            mountains=mountains,
            phase1_top=args.p1, phase2_top=args.p2, phase3_top=args.p3,
        )
        results = optimizer.optimize()
        optimizer.export_results(results, args.output)
    else:
        output = optimize_for_years(
            years=args.years,
            mountains=mountains,
            phase1_top=args.p1, phase2_top=args.p2, phase3_top=args.p3,
            output_path=args.output,
        )
        print(f'\nDone → {output}')
