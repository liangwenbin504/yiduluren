# -*- coding: utf-8 -*-
"""微信读书《壬占汇选》卷之一 批量OCR
输入: _weread_vol1/pNNN.png (由 _weread_extract.py 产出)
输出: _weread_vol1/ocr_all.txt (合并全文) + _weread_vol1/ocr_NNN.txt (每页)
用法: python engine/_weread_ocr.py [start] [end]
"""
import os, sys, base64, json, urllib.request, time

OUT = '_weread_vol1'
KEY = 'ecb9f085a64f43c094a4f7df26b0d453.3LUSyeZjV7PP8P5y'
API = 'https://open.bigmodel.cn/api/paas/v4/chat/completions'
MODEL = 'glm-4v-flash'

PROMPT = '''这是大六壬古籍《壬占汇选》的一页（现代排印版，canvas渲染截图）。
请逐字OCR，保留原段落结构和左右分栏排版。不要遗漏任何字，无法确定的用■代替。
直接输出纯文本，不要加任何解释或标题前缀。'''

def ocr_image(path):
    """单图OCR，返回文本"""
    with open(path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode()
    payload = {
        'model': MODEL,
        'messages': [{'role': 'user', 'content': [
            {'type': 'text', 'text': PROMPT},
            {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{b64}'}}
        ]}]
    }
    req = urllib.request.Request(API, data=json.dumps(payload).encode(),
        headers={'Authorization': f'Bearer {KEY}', 'Content-Type': 'application/json'})
    resp = json.loads(urllib.request.urlopen(req, timeout=120).read().decode())
    return resp['choices'][0]['message']['content']

def main():
    # 找所有截图
    imgs = sorted([f for f in os.listdir(OUT) if f.startswith('p') and f.endswith('.png')])
    start = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    end = int(sys.argv[2]) if len(sys.argv) > 2 else len(imgs)
    imgs = imgs[start:end]

    print(f'共 {len(imgs)} 页待OCR (p{start}~p{start+len(imgs)-1})')
    all_text = []
    t0 = time.time()

    for idx, img_name in enumerate(imgs):
        path = os.path.join(OUT, img_name)
        try:
            text = ocr_image(path)
        except Exception as e:
            text = f'[OCR错误: {e}]'
            print(f'  {img_name}: {str(e)[:60]}')

        all_text.append(f'\n===== 第{idx+start}页 ({img_name}) =====\n{text}')

        # 每页也存单独文件
        ocr_path = path.replace('.png', '.txt')
        open(ocr_path, 'w', encoding='utf-8').write(text)

        elapsed = time.time() - t0
        avg = elapsed / (idx + 1)
        remaining = avg * (len(imgs) - idx - 1)
        preview = text[:80].replace('\n', ' ')
        print(f'[{idx+1}/{len(imgs)}] {img_name} | {preview}... | 累计{elapsed:.0f}s 剩余~{remaining:.0f}s')

        # 避免限流
        time.sleep(0.3)

    # 合并全文
    full_path = os.path.join(OUT, 'ocr_all.txt')
    open(full_path, 'w', encoding='utf-8').write('\n'.join(all_text))
    print(f'\n完成! 全文已保存: {full_path}')
    print(f'总耗时: {time.time()-t0:.0f}s')

if __name__ == '__main__':
    main()
