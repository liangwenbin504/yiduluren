# -*- coding: utf-8 -*-
"""批量探测 v2：搜索'六壬'宽词，遍历结果卡片拿bookId，逐本试reader
"""
import asyncio, os, re, json

PROFILE = os.path.abspath('_weread_profile2')

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE, channel='msedge', headless=True,
            viewport={'width': 1440, 'height': 1000})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        # 1. 搜索六壬，滚动加载全部结果
        await page.goto('https://weread.qq.com/web/search/books?keyword=六壬',
            wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(5000)
        for _ in range(15):
            await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
            await page.wait_for_timeout(800)

        # 2. 遍历结果卡片：点进详情拿bookId（用 _blank 打开避免丢列表）
        items = await page.locator('li.wr_bookList_item').count()
        print(f'搜索结果卡片: {items}')
        booklist = []
        for i in range(min(items, 40)):
            try:
                await page.locator('li.wr_bookList_item').nth(i).click()
                await page.wait_for_timeout(3000)
                cur = page.url
                m = re.search(r'bookDetail/([0-9a-zA-Z]+)', cur)
                title = await page.evaluate('() => document.querySelector(\"h1, .wr_book_title, .book_title\")?.innerText || document.title')
                if m:
                    booklist.append((title.strip()[:40], m.group(1)))
                    print(f'  [{i}] {title.strip()[:40]} -> {m.group(1)}')
                # 返回搜索结果
                await page.go_back()
                await page.wait_for_timeout(2000)
            except Exception as e:
                print(f'  [{i}] 异常: {str(e)[:50]}')
                continue

        # 3. 批量试 reader
        print()
        print('=== 逐本试读 ===')
        results = []
        for title, bid in booklist:
            try:
                await page.goto(f'https://weread.qq.com/web/reader/{bid}',
                    wait_until='domcontentloaded', timeout=20000)
                await page.wait_for_timeout(4000)
                text = await page.evaluate('() => document.body.innerText')
                has_canvas = await page.evaluate('() => !!document.querySelector("canvas")')
                if has_canvas:
                    status = '可读(canvas)'
                elif '下架' in text and '不再支持' in text:
                    status = '已下架'
                elif '404' in text or 'Not Found' in text:
                    status = '404'
                elif '购买' in text or '阅饼' in text:
                    status = '需购买'
                elif '试读' in text and '登录' in text:
                    status = '需登录/试读'
                else:
                    status = '其他'
            except Exception as e:
                status = f'异常:{str(e)[:25]}'
            results.append((title, bid, status))
            print(f'  {title:25} {status}')

        await ctx.close()

        # 汇总
        print()
        print('=== 汇总 ===')
        ok = [r for r in results if '可读' in r[2]]
        gone = [r for r in results if '下架' in r[2] or '404' in r[2]]
        pay = [r for r in results if '购买' in r[2]]
        print(f'可读 {len(ok)} 本:')
        for t, b, s in ok:
            print(f'  ✓ {t} ({b})')
        print(f'下架/404 {len(gone)} 本:')
        for t, b, s in gone:
            print(f'  ✗ {t}')
        print(f'需购买 {len(pay)} 本:')
        for t, b, s in pay:
            print(f'  $ {t}')

        # 落盘
        with open('_weread_books_probe.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=1)
        print('\n已落盘 _weread_books_probe.json')

asyncio.run(main())