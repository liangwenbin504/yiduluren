# -*- coding: utf-8 -*-
"""生成两份交付文档(桌面)：
1. CorpusB诚实重标与引擎诚实基线审计报告.docx  — 数据危机+三层对比+结论
2. CorpusB待人工复核清单.docx                  — 178 例待人工逐项研究
"""
import json
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

BASE = "C:/Users/Administrator/Desktop"
HB = json.load(open("engine/honest_baseline.json", encoding="utf-8"))
Q = json.load(open("engine/corpusB_review_queue.json", encoding="utf-8"))

doc = Document()
style = doc.styles["Normal"]
style.font.name = "宋体"
style.font.size = Pt(10.5)


def h(txt, lvl=1):
    doc.add_heading(txt, level=lvl)


def p(txt, bold=False, color=None, size=None):
    par = doc.add_paragraph()
    r = par.add_run(txt)
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor(*color)
    if size:
        r.font.size = Pt(size)
    return par


def bullet(txt):
    doc.add_paragraph(txt, style="List Bullet")


# ===================== 文档1：审计报告 =====================
h("Corpus B 诚实重标与引擎诚实基线审计报告", 0)
p("生成日期：2026-07-31 ｜ 数据：data/大六壬断案疏正.pdf（真实源）+ 抽取219真实案 + 对齐224合成例",
  color=(0x66, 0x66, 0x66), size=9)

h("执行摘要", 1)
p("本次审计对“古例回测”评估集做了端到端诚实重建，结论如下：", bold=True)
bullet("数据完整性危机：Corpus B 共 224 例，其中 174 例（78%）的断语为机器模板合成，"
       "其“吉”标签由模板关键词循环得出（机器写吉→机器读吉）；同时 174 例的三传为常数"
       "“巳寅亥”（合成时未做真实抽取），引擎长期在损坏输入上运行。")
bullet(f"诚实基线（古例域已关闭股票域“求财类神”看涨注入器；引擎输入与标签均来自真实疏正案，n={HB['all_real_M3_n']}）："
       f"M3 准确率仅 {HB['all_real_M3']*100:.1f}%，远低于“永远猜凶”的朴素基准 "
       f"{HB['naive_always_xiong']*100:.1f}%。引擎对古例基本无预测能力。")
bullet("根因定位：引擎“吉”乐观偏置 100% 来自「求财类神」模块（股票域设计，专找朱雀/六合/青龙等看涨信号）。"
       "诊断显示它在 164 例真实案上贡献 +471 涨质量、override 触发率 76%；关闭后 凶→吉 误判由 105 例骤降至 36 例。")
bullet(f"原报告 M3≈62%、求财≈93.8% 完全是“损坏输入 + 循环吉标签 + 求财类神看涨偏置”三者互证造成的假象，"
       f"关闭该偏置后 Corpus B 数字即跌至 {HB['v1_full_corpusB_M3']*100:.1f}%，印证其虚高。")
bullet("已交付：46 例高置信重标（已写入 ancient_truth_labels_v2.json）+ 178 例待人工复核清单（本包附 docx）。")

h("一、数据完整性危机", 1)
h("1.1 标签循环论证", 2)
p("合成 Corpus B（data/daliuren_shuzheng_cases.json）中 174/224 例的 sanchuan_interpretation 为"
  "逐字重复的模板：“初传…主吉庆；中传…主顺利；末传…主成功”。标签抽取器读到“吉庆/顺利/成功”即判为“吉”，"
  "形成“机器写吉→机器读吉”的循环论证。旧标签分布：吉 207 / 未知 15 / 凶 1 / 平 1。")
h("1.2 引擎输入损坏", 2)
p("174/224 例三传为常数“巳寅亥”（占 174 次，远超任何真实三传频次），说明合成阶段未做真实三传抽取。"
  "在 46 例高置信对齐中，仅 3 例合成三传与真实疏正案三传一致，43 例不符——即引擎长期在虚假三传上运行。")

h("二、抽取·对齐·重标管线", 1)
bullet("从 data/大六壬断案疏正.pdf（414页）抽取 219 条真实案，结局分布："
       f"凶 {HB['real_label_dist'].get('凶')} / 吉 {HB['real_label_dist'].get('吉')} /"
       f" 未知 {HB['real_label_dist'].get('未知',0)} / 平 {HB['real_label_dist'].get('平')}。"
       "真实案 79% 为凶，证明古例多为邵彦和警示/纠错之占。")
bullet("对齐 224 合成例 → 219 真实案：46 例可靠（强键对齐）/ 176 例需复核 / 2 例歧义 / 0 例无候选。")
bullet("可靠标准（任一即可，避免(占类,年龄)撞车配错）：① 合成全干支 == 真实全干支（铁证）；"
       "② 非损坏三传与真实三传重叠 ≥ 2；③ 年龄 + 姓名共 ≥ 2 字。")
bullet("应用 46 可靠重标至 ancient_truth_labels_v2.json：31 例 吉→凶、7 例 未知→凶；"
       "标签分布由 吉303/凶250 → 吉272/凶288。")

h("三、三层准确率对比（古例域已关闭求财类神看涨偏置）", 1)
p("关闭股票域“求财类神”看涨注入器后，原被其撑高的数字现出原形；唯一可信的是真实案基线：", bold=True)
tbl = doc.add_table(rows=1, cols=4)
tbl.style = "Light Grid Accent 1"
hdr = tbl.rows[0].cells
for i, t in enumerate(["评估集", "M3准确率", "可信度", "说明"]):
    hdr[i].text = t
for row in [
    ("全 Corpus B（损坏输入+循环标签）", f"{HB['v1_full_corpusB_M3']*100:.1f}%", "不可信", "原62%系求财类神撑高"),
    ("仅修标签（输入仍损坏）", f"{HB['v2_label_fixed_M3']*100:.1f}%", "不可信", "仍喂损坏三传"),
    (f"真实输入+真实标签（{HB['all_real_M3_n']}例真实案）", f"{HB['all_real_M3']*100:.1f}%", "可信", "唯一干净基线"),
    ("朴素基准（永远猜凶）", f"{HB['naive_always_xiong']*100:.1f}%", "—", "不需引擎即得"),
]:
    cells = tbl.add_row().cells
    for i, t in enumerate(row):
        cells[i].text = str(t)

h("四、引擎真实表现（164 例有效数字，求财类神已关闭）", 1)
p(f"在真实输入+真实标签上，四方法准确率：M1 {HB['all_real_M1']*100:.1f}% / "
  f"M2 {HB['all_real_M2']*100:.1f}% / M3 {HB['all_real_M3']*100:.1f}% / M4 {HB['all_real_M4']*100:.1f}%。")
cm = HB["all_real_confusion_M3"]
p(f"M3 混淆矩阵：凶→吉 {cm.get('凶->吉',0)}、凶→凶 {cm.get('凶->凶',0)}、凶→平 {cm.get('凶->平',0)}；"
  f"吉→吉 {cm.get('吉->吉',0)}、吉→凶 {cm.get('吉->凶',0)}。", )
p("关闭求财类神后，系统性“吉”乐观偏置已消除（凶→吉 由 105 例降至 "
  f"{cm.get('凶->吉',0)} 例）；但引擎转而大量预测“平”——对 142 例真实“凶”案 predict 平 "
  f"{cm.get('凶->平',0)} 例、predict 吉 {cm.get('凶->吉',0)} 例。说明引擎对古例方向性信号缺失："
  "古例回测未构造真实“课体/毕法赋/神煞/特殊课格”特征（stub 为平），约 4/10 信号组失效，"
  "剩余天将/六亲/旺衰信号相互冲突归为“平”。引擎表现（26.2%）仍远低于朴素基准（83.6%），"
  "即当前特征集对古例结局基本无区分力。", bold=True, color=(0xAA, 0x00, 0x00))
# 各类别表
p("各类别 M3 准确率（n≥3）：", bold=True)
t2 = doc.add_table(rows=1, cols=3)
t2.style = "Light Grid Accent 1"
hh = t2.rows[0].cells
for i, t in enumerate(["占类", "样本数", "M3准确率"]):
    hh[i].text = t
for cat, d in sorted(HB["all_real_by_cat_M3"].items(), key=lambda kv: -kv[1]["n"]):
    c = t2.add_row().cells
    c[0].text = cat
    c[1].text = str(d["n"])
    c[2].text = f"{d['acc']*100:.1f}%"

h("五、待人工复核队列（178 例）", 1)
p("176 例需复核 + 2 例歧义已导出为 engine/corpusB_review_queue.json，并附独立 docx"
  "《CorpusB待人工复核清单》。这些例对齐仅依赖(占类,年龄)或日干同，存在配错真实案风险，"
  "故保留原标签、交由人工逐项裁定。建议流程：逐例核对“匹配真实案”及其邵彦和断语，"
  "确认后将该真实案结局写入标签。")

h("六、建议与下一步", 1)
bullet("承认古例回测（v2→v6 全系列）建立在损坏评估集上，原 63.4%/求财93.8% 等数字作废。")
bullet("“吉”乐观偏置根因已定位并修复：求财类神模块（股票域看涨注入器）对古例域误用，"
       "已在 ancient_backtest 域关闭（judgment_fusion.DISABLE_CAISHEN，默认 False 不影响股票路径，可逆）。")
bullet("但引擎对古例仍无方向性信号（predict 平为主，26.2% ≪ 朴素基准 83.6%）。真正瓶颈是"
       "古例回测未构造真实“课体/毕法赋/神煞/特殊课格”特征（stub 为平，4/10 信号组失效）。"
       "若要追真实技能，需为古例补全这些特征工程（较大构建），而非改权重。")
bullet("若要在干净数据上重估：以 219 真实案为权威评估集（已具备真实日辰/月将/时辰/三传/结局），"
       "可常态化重跑 _honest_skill_all.py（已默认关闭求财类神）。")
bullet("178 例复核清单供人工消歧；确认后可并入 ancient_truth_labels_v2.json 形成 v3。")

doc.save(f"{BASE}/CorpusB诚实重标与引擎诚实基线审计报告.docx")
print("✅ 审计报告已写出")

# ===================== 文档2：复核清单 =====================
doc2 = Document()
st2 = doc2.styles["Normal"]
st2.font.name = "宋体"
st2.font.size = Pt(9)
h2 = doc2.add_heading("Corpus B 待人工复核清单（178 例）", 0)
p("说明：以下 176 例“需复核”+ 2 例“歧义”对齐仅依赖(占类,年龄)或日干同，存在配错真实案风险，"
  "故保留原标签、附“建议标签”供人工逐项裁定。确认后将真实案结局写入 ancient_truth_labels_v2.json 形成 v3。",
  size=9, color=(0x66, 0x66, 0x66))
qt = doc2.add_table(rows=1, cols=9)
qt.style = "Light Grid Accent 1"
heads = ["#", "ID", "占类", "年龄", "当前标签", "当前置信", "建议标签", "建议置信", "匹配真实案(依据)"]
for i, t in enumerate(heads):
    qt.rows[0].cells[i].text = t
for idx, it in enumerate(Q["queue"], 1):
    c = qt.add_row().cells
    c[0].text = str(idx)
    c[1].text = it.get("id", "")
    c[2].text = it.get("category", "")
    c[3].text = str(it.get("age", ""))
    c[4].text = it.get("current_label", "")
    c[5].text = f"{it.get('current_conf',0):.2f}"
    c[6].text = it.get("suggested_label", "")
    c[7].text = f"{it.get('suggested_conf',0):.2f}"
    c[8].text = f"{it.get('real_case_id','')} {it.get('real_name','')} | {','.join(it.get('match_reasons',[]))}"
# 缩小表格字体
for row in qt.rows:
    for cell in row.cells:
        for par in cell.paragraphs:
            for run in par.runs:
                run.font.size = Pt(8)

doc2.save(f"{BASE}/CorpusB待人工复核清单.docx")
print(f"✅ 复核清单已写出（{Q['count']} 例）")
