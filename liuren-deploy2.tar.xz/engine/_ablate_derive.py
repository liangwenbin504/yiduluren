# -*- coding: utf-8 -*-
"""消融：直接对比 derive_jiuzongmen 的 旧(有bug) vs 新(已修) vs 关闭 对古例 M3 的影响。
不修改任何生产文件，仅 monkeypatch 内存中的函数后跑同样的诚实循环。
"""
import json
import sys
from collections import Counter
sys.path.insert(0, ".")
import engine.liuren_keti_bifa as bifa
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")


def ok_yj(x):
    return isinstance(x, str) and x in VALID


# ---- OLD buggy derive（忠实复刻：ups 取 k[0]，八专用五行相同）----
def old_derive(ri_gan, ri_zhi, si_ke):
    out = []
    rg_wx = bifa.GAN_WX.get(ri_gan, '')
    rz_wx = bifa.ZHI_WX.get(ri_zhi, '')
    if ri_gan and ri_zhi and bifa.GAN_WX.get(ri_gan) == bifa.ZHI_WX.get(ri_zhi):
        out.append('八专')
    ups = []
    for k in si_ke:
        if isinstance(k, (list, tuple)) and len(k) >= 2:
            ups.append(k[0])  # BUG
    day_zei, zhi_zei = [], []
    for up in ups:
        uw = bifa.ZHI_WX.get(up, '')
        if uw and rg_wx and bifa._ke(uw, rg_wx):
            day_zei.append(up)
        if uw and rz_wx and bifa._ke(uw, rz_wx):
            zhi_zei.append(up)
    if day_zei:
        out.append('元首')
    elif zhi_zei:
        out.append('重审')
    else:
        has_yaok = False
        if rg_wx:
            for up in ups:
                uw = bifa.ZHI_WX.get(up, '')
                if uw and (bifa._ke(uw, rg_wx) or bifa._ke(rg_wx, uw)):
                    has_yaok = True
                    break
        if has_yaok:
            out.append('遥克')
        elif ri_gan and bifa.GAN_WX.get(ri_gan):
            yg = bifa.GAN_YY.get(ri_gan)
            matched = [u for u in ups if bifa.ZHI_YY.get(u) == yg]
            if matched:
                out.append('知一')
            else:
                out.append('昴星')
        else:
            out.append('昴星')
    return out


def run(label, derive_fn=None, derive_enabled=True):
    if derive_fn is not None:
        bifa.derive_jiuzongmen = derive_fn
    bifa.set_derive_enabled(derive_enabled)
    n = correct = skip = 0
    cm = Counter()
    for c in REAL:
        sc = c.get("sanchuan") or []
        if not isinstance(sc, list):
            sc = list(sc)
        rizhu = c.get("day_ganzhi", "")
        if len(sc) < 3 or not rizhu or len(rizhu) < 2:
            skip += 1
            continue
        truth = c.get("label", "")
        if truth not in ("吉", "凶", "平"):
            skip += 1
            continue
        clean = {
            "id": c["case_id"], "name": c.get("name", ""),
            "category": c.get("zhanlei", "其他"), "rizhu": rizhu,
            "yue_jiang": c["yue_jiang"] if ok_yj(c.get("yue_jiang")) else "",
            "shichen": c["shichen"] if ok_yj(c.get("shichen")) else "",
            "sanchuan": sc, "keti": [], "label": truth,
            "label_confidence": c.get("label_conf", 0),
        }
        try:
            pred = predict_ancient_case(clean, "M3")
            p = pred.get("prediction", "")
            n += 1
            if p == truth:
                correct += 1
            cm[f"{truth}->{p}"] += 1
        except Exception:
            skip += 1
    acc = correct / n if n else 0
    print(f"[{label}] M3={acc*100:.1f}%  ({correct}/{n}, skip={skip})  混淆={dict(cm)}")


if __name__ == "__main__":
    # 注意：bifa.derive_jiuzongmen 默认已是新(修复)版
    run("NEW(已修 derive)", derive_enabled=True)
    run("OLD(buggy derive)", derive_fn=old_derive, derive_enabled=True)
    run("DERIVE-OFF(完全关闭九宗门推导)", derive_enabled=False)
