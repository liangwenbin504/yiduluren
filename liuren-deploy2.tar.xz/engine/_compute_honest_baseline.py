# -*- coding: utf-8 -*-
"""计算并保存诚实基线三层对比，供文档生成读取。"""
import json
import sys
from collections import Counter
sys.path.insert(0, ".")
from engine.ancient_backtest import run_backtest, predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")


def ok_zhi(x):
    return isinstance(x, str) and x in VALID


# v1 / v2 回测
v1 = run_backtest("engine/ancient_truth_labels.json")["summary"]["M3"]["accuracy"]
v2 = run_backtest("engine/ancient_truth_labels_v2.json")["summary"]["M3"]["accuracy"]

# 全集真实案诚实测试
methods = ["M1", "M2", "M3", "M4"]
stats = {m: {"n": 0, "correct": 0, "skip": 0, "cm": Counter(), "by_cat": {}} for m in methods}
for c in REAL:
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rizhu = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rizhu or len(rizhu) < 2:
        for m in methods:
            stats[m]["skip"] += 1
        continue
    truth = c.get("label", "")
    if truth not in ("吉", "凶", "平"):
        for m in methods:
            stats[m]["skip"] += 1
        continue
    clean = {
        "id": c["case_id"], "name": c.get("name", ""), "category": c.get("zhanlei", "其他"),
        "rizhu": rizhu,
        "yue_jiang": c["yue_jiang"] if ok_zhi(c.get("yue_jiang")) else "",
        "shichen": c["shichen"] if ok_zhi(c.get("shichen")) else "",
        "sanchuan": sc, "keti": [], "label": truth, "label_confidence": c.get("label_conf", 0),
    }
    for m in methods:
        try:
            p = predict_ancient_case(clean, m).get("prediction", "")
            ok = (p == truth)
            stats[m]["n"] += 1
            if ok:
                stats[m]["correct"] += 1
            stats[m]["cm"][f"{truth}->{p}"] += 1
            d = stats[m]["by_cat"].setdefault(clean["category"], {"n": 0, "c": 0})
            d["n"] += 1
            if ok:
                d["c"] += 1
        except Exception:
            stats[m]["skip"] += 1

dist = Counter(c.get("label") for c in REAL if c.get("label") in ("吉", "凶", "平"))
base_rate = dist.get("凶", 0) / sum(dist.values())

out = {
    "v1_full_corpusB_M3": round(v1, 4),
    "v2_label_fixed_M3": round(v2, 4),
    "all_real_M3": round(stats["M3"]["correct"] / stats["M3"]["n"], 4),
    "all_real_M3_n": stats["M3"]["n"],
    "all_real_M1": round(stats["M1"]["correct"] / stats["M1"]["n"], 4),
    "all_real_M2": round(stats["M2"]["correct"] / stats["M2"]["n"], 4),
    "all_real_M4": round(stats["M4"]["correct"] / stats["M4"]["n"], 4),
    "all_real_confusion_M3": dict(stats["M3"]["cm"]),
    "all_real_by_cat_M3": {k: {"n": v["n"], "acc": round(v["c"] / v["n"], 4)}
                            for k, v in stats["M3"]["by_cat"].items() if v["n"] >= 3},
    "naive_always_xiong": round(base_rate, 4),
    "real_label_dist": dict(dist),
}
json.dump(out, open("engine/honest_baseline.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False, indent=2))
