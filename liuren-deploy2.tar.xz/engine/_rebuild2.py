# -*- coding: utf-8 -*-
"""补3案月将 + 重建评估数据 + 跑评估"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

# 1. 更新反推月将：补3案
with open('extracted_data/_guji_fetch/指南卷三_反推月将.json', encoding='utf-8') as f:
    rev = json.load(f)
for r in rev:
    if (r['章节'], r['编号']) == ('孕产','一'): r['月将'] = '卯'; r['err'] = '反吟课手动'
    if (r['章节'], r['编号']) == ('选举','六'): r['月将'] = '亥'; r['err'] = '三传从革手动'
    if (r['章节'], r['编号']) == ('选举','七'): r['月将'] = '戌'; r['err'] = '三传从革手动'
with open('extracted_data/_guji_fetch/指南卷三_反推月将.json', 'w', encoding='utf-8') as f:
    json.dump(rev, f, ensure_ascii=False, indent=1)
rev_map = {(r['章节'] + r['编号']): r['月将'] for r in rev}
print(f'反推月将: 78案全有（失败 {len([r for r in rev if not r["月将"]])}）')

# 2. 重建评估数据
with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    data = json.load(f)
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
ssc = SiKeSanChuanCalculator2()
updated = 0
for c in data['cases']:
    yj = rev_map.get(c['name'], '')
    if not yj:
        continue
    calc = ssc.calculate(c['ri_gan'], c['ri_zhi'], yj, c['shichen'])
    sc = calc.get('sanchuan') or {}
    c['sanchuan'] = [sc.get('初传',''), sc.get('中传',''), sc.get('末传','')]
    c['yue_jiang'] = yj
    c['keti_engine'] = sc.get('课体','')
    updated += 1
with open('engine/ancient_truth_labels_zhinan_v3.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=1)
print(f'重建完成 {updated} 案')

# 3. 课体一致率
with open('extracted_data/_guji_fetch/大六壬指南_卷三_案例.json', encoding='utf-8') as f:
    raw = json.load(f)
raw_map = {c['章节'] + c['编号']: c for c in raw}
JZM = ['元首','重审','知一','比用','涉害','见机','察微','遥克','蒿矢','弹射','昴星','别责','八专','伏吟','反吟']
def to_jzm(lst):
    out = set()
    for k in lst:
        if k in ('蒿矢','弹射'): out.add('遥克')
        elif k in ('见机','察微'): out.add('涉害')
        elif k == '比用': out.add('知一')
        elif k in JZM: out.add(k)
    return out
match = 0; n = 0
for c in data['cases']:
    raw_c = raw_map.get(c['name'], {})
    want = to_jzm(raw_c.get('课体', []))
    if not want or not c.get('keti_engine'):
        continue
    n += 1
    eng = c['keti_engine'].replace('课','').replace('格','')
    if any(w in eng for w in want):
        match += 1
print(f'课体一致: {match}/{n} = {match/max(n,1)*100:.0f}%')
