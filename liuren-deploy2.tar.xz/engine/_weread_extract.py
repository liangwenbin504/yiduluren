# -*- coding: utf-8 -*-
"""微信读书《壬占汇选》卷之一提取流水线
用法: python engine/_weread_extract.py [max_pages]
输出: _weread_vol1/pNNN.png + _weread_vol1/ocr_NNN.txt
注意：仅用于校验项目已有v2数据质量（个人合法副本对照），不对外分发。
"""
import asyncio, os, sys, json, time

URL = 'https://weread.qq.com/web/reader/33932640813abaad7g018f8ckc81322c012c81e728d9d180'
OUT = '_weread_vol1'
os.makedirs(OUT, exist_ok=True)

MAX_PAGES = int(sys.argv[1]) if len(sys.argv) > 1 else 150

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel='msedge', headless=True)
        ctx = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            viewport={'width': 1440, 'height': 1000})
        page = await ctx.new_page()
        await page.goto(URL, wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(6000)
        print(f'已打开: {page.url}')

        # 获取canvas裁切区
        box = await page.evaluate('''() => {
            const c = document.querySelector('canvas');
            if (!c) return null;
            const r = c.getBoundingClientRect();
            return {x:r.x, y:r.y, w:r.width, h:r.height};
        }''')
        if not box:
            print('ERROR: 未找到canvas')
            return
        print(f'Canvas区域: {box}')
        clip = {'x': box['x'], 'y': box['y'], 'width': box['w'], 'height': box['h']}

        # 提取页面
        start_time = time.time()
        for i in range(MAX_PAGES):
            path = os.path.join(OUT, f'p{i:03d}.png')
            try:
                await page.screenshot(path=path, clip=clip)
                sz = os.path.getsize(path)
                elapsed = time.time() - start_time
                print(f'[{i+1}/{MAX_PAGES}] {path} ({sz}B, {elapsed:.1f}s)')
            except Exception as e:
                print(f'  截图失败: {e}')
                break

            # 翻页
            try:
                await page.keyboard.press('ArrowRight')
                await page.wait_for_timeout(1200)
            except Exception:
                print('  翻页结束(无响应)')
                break

        total = i + 1
        print(f'\n完成! 共提取 {total} 页 -> {OUT}/')
        await browser.close()

asyncio.run(main())
