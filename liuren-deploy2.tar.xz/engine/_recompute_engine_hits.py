# -*- coding: utf-8 -*-
"""重算所有已标注案例的 engine_hits，确保基于最新权威三传/四课。
遍历 status 以"已标注"开头的案例，用当前 longmarch 字段（已同步权威版）重新跑引擎，
刷新 annotation.engine_hits，保留 annotation 的文字规则（leishen/liqi/leixiang/yingqi）。
"""
import json, sys, os
sys.path.insert(0, '.')
# P1：相对路径基于项目根（子进程 cwd 可能与调用方不同）
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.feature_extractor import extract_features
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

eng = SiKeSanChuanCalculator2()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    if not c.get("status", "").startswith("已标注"):
        continue
    cid = c["case_id"]
    gz = c.get("day_ganzhi", "")
    yj = c.get("yue_jiang", "")
    shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺干支/月将/时辰")
        continue
    # P1：起课统一到权威 V2 引擎（旧 DaLiuRenEngine 的 {'天地对应':...} 格式
    # 会让毕法/特殊课格检测取不到天地盘，engine_hits 大面积失真）
    tdp = eng.get_tiandi_pan(yj, shi)
    sike_tuples = eng.qi_sike(gz[0], gz[1], tdp)
    sike = [[t[0], t[1], t[2]] for t in sike_tuples]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tdp}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tdp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    ann = c.get("annotation") or {}
    ann["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["annotation"] = ann
    n += 1

_OUT = os.path.join(os.path.dirname(os.getcwd()), '_memory', 'longmarch_annotations.v2.json') if os.path.basename(os.getcwd()) == 'engine' else os.path.join(os.getcwd(), '_memory', 'longmarch_annotations.v2.json')
json.dump(r, open(_OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已重算 {n} 案 engine_hits -> {_OUT}")
