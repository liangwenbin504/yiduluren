# -*- coding: utf-8 -*-
"""微信读书扫码登录（一次性）
- 用临时持久化 profile 启动 headed Edge（用户能看到窗口）
- 打开 weread.qq.com，弹出登录二维码
- 轮询 wr_skey cookie 检测登录成功
- 成功后 profile 保存登录态，供后续 headless 读取全书复用
"""
import asyncio, os, sys

PROFILE = os.path.abspath('_weread_profile3')
os.makedirs(PROFILE, exist_ok=True)

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE,
            channel='msedge',
            headless=False,          # 必须非headless，用户才能扫码
            viewport={'width': 1440, 'height': 1000},
            args=['--window-position=100,50'])
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto('https://weread.qq.com/', wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(4000)
        print('当前URL:', page.url)

        # 检查是否已登录（有 wr_skey 即登录态）
        def has_login():
            return any('wr_skey' in (c.get('name') or '') for c in cookies_now())

        def cookies_now():
            # 用同步方式无法直接取，改为轮询时再取
            return ctx_cookies_holder[0]

        ctx_cookies_holder = [None]
        async def grab_cookies():
            ctx_cookies_holder[0] = await ctx.cookies()

        await grab_cookies()
        if has_login():
            print('ALREADY_LOGGED_IN')
            await page.screenshot(path='_weread_login.png')
            await ctx.close()
            return

        # 未登录：点「登录」按钮弹出二维码
        try:
            login_btn = page.get_by_text('登录', exact=True)
            if await login_btn.count() > 0:
                await login_btn.first.click(timeout=8000)
                print('已点击登录按钮')
        except Exception as e:
            print(f'点击登录按钮失败(可能已在登录页): {str(e)[:60]}')
        await page.wait_for_timeout(3000)

        # 截图（用户可直接看窗口，这张图备查）
        await page.screenshot(path='_weread_login_qr.png')
        print('二维码窗口已就绪，等待用户扫码...')

        # 轮询登录状态（最多 10 分钟）
        for i in range(120):
            await page.wait_for_timeout(5000)
            try:
                await grab_cookies()
            except Exception:
                continue
            if has_login():
                print(f'LOGIN_SUCCESS 耗时~{i*5}s')
                await page.screenshot(path='_weread_logged_in.png')
                # 打开目标书验证会员可读
                try:
                    await page.goto('https://weread.qq.com/web/reader/33932640813abaad7g018f8ckc81322c012c81e728d9d180', wait_until='domcontentloaded', timeout=40000)
                    await page.wait_for_timeout(4000)
                    await page.screenshot(path='_weread_verify.png')
                    print('已打开目标书页面')
                except Exception as e:
                    print(f'打开书失败: {str(e)[:60]}')
                await ctx.close()
                return
            if i % 12 == 11:
                print(f'等待扫码中... {i*5}s')

        print('TIMEOUT 10分钟未登录')
        await ctx.close()

asyncio.run(main())
