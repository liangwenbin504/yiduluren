# -*- coding: utf-8 -*-
"""「其他」剩余判错案：完整信号诊断（直接调 collect_signals + fuse）。"""
import json, sys
sys.path.insert(0, ".")
from engine.ancient_backtest import build_result_from_ancient
import engine.judgment_fusion as jf

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")
def ok(x): return isinstance(x, str) and x in VALID

TARGETS = ('114','120','194','200','214','218')
for c in REAL:
    n = str(c['case_id']).split('·')[-1]
    if n not in TARGETS: continue
    sc = c.get('sanchuan') or []
    clean = {'id':c['case_id'],'name':c.get('name',''),'category':c.get('zhanlei','其他'),
             'rizhu':c['day_ganzhi'],'yue_jiang':c['yue_jiang'] if ok(c.get('yue_jiang')) else '',
             'shichen':c['shichen'] if ok(c.get('shichen')) else '','sanchuan':sc,'keti':[],
             'label':c.get('label'),'label_confidence':c.get('label_conf',0),
             'month':c.get('month'),'ben_ming_zhi':c.get('ben_ming_zhi'),'year':c.get('year') or '',
             'leishen':c.get('leishen','')}
    result = build_result_from_ancient(clean)
    sigs = jf.collect_signals(result)
    fused = jf.fuse(result)
    trend = fused.get('trend')
    print('='*18, c['case_id'], '| truth=', c.get('label'), '| pred=', '吉' if trend=='看涨' else ('凶' if trend=='看跌' else '平'))
    total = 0.0
    for g, sc2, up, cf in sigs:
        total += sc2
        print(f'    [{g:>14}] {sc2:+6.2f}  up={str(up):5} conf={cf:.2f}')
    print(f'    {"":>14} Σ={total:+.2f}')
    print(f'    keti={result.get("keti")} 三传={"".join(result.get("san_chuan") or [])} 天将={result.get("sanchuan_tianjiang")}')
    a = result.get('analysis') or {}
    kd = a.get('keti_duanyu') or {}
    print(f'    level={kd.get("level")} 六亲={[(x.get("六亲"),x.get("支")) if isinstance(x,dict) else x for x in (a.get("liuqin") or [])]}')
    print(f'    旺衰={[(x.get("支"),x.get("旺衰")) if isinstance(x,dict) else x for x in (a.get("wangshuai") or [])]}')
    print(f'    _zhanlei={a.get("_zhanlei")} ba_sha={a.get("ba_sha")} _ssv={json.dumps(a.get("_shen_sha_valence") or {}, ensure_ascii=False)[:300]}')
    print()
