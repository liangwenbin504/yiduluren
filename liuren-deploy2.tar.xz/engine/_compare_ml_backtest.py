# -*- coding: utf-8 -*-
"""ML 重标定结果 · 对照手工权重 + 朴素基线 55.3% + 分折叠/系数解读。"""
import os, sys, json
sys.path.insert(0, ".")
import engine.ml_valence as mv

res = json.load(open("engine/regime_backtest_ml.json", encoding="utf-8"))
NAIVE = 0.5532

print("=== 总体 OOS（expanding-window walk-forward, 测试年 2011-2024, holdout 2025-2026）===")
print(f"{'variant':24s} {'model':4s} {'n':>5s} {'acc':>7s} {'CI95':>16s} {'p_vs50':>7s} {'p_vs53':>7s} {'brier':>6s} {'auc':>5s}")
for tag, v in res.items():
    label = {"ml_sameday_intraday":"当日·日内","ml_nextday_intraday":"次日·日内",
             "ml_nextday_nextret":"次日·收益"}.get(tag, tag)
    for mk in ("lr", "hgb"):
        m = v[mk]
        print(f"{label:24s} {mk:4s} {m['n_oos']:5d} {m['acc']:7.2%} "
              f"[{m['ci95'][0]:.2%},{m['ci95'][1]:.2%}] {m['p_vs50']:7.3f} {m['p_vs_naive']:7.3f} "
              f"{m['brier']:6.3f} {m['auc']:5.3f}")

print("\n=== LR 重标定后的 valence 权重（全量 2005-2024 训练，标准化系数；负=数据把传统吉凶反转）===")
for tag, v in res.items():
    print(f"-- {tag} --")
    coefs = v["lr"]["coefs"]
    for c, w in sorted(coefs.items(), key=lambda kv: -abs(kv[1] or 0)):
        print(f"    {c:16s} {w:+.3f}")

print("\n=== 分折叠 OOS 准确率 vs 段朴素（LR）===")
for tag, v in res.items():
    print(f"-- {tag} --")
    for f in v["lr"]["folds"]:
        flag = "赢" if f["acc"] > f["naive"] else "输"
        print(f"    {f['test_year']} n={f['n']:4d} acc={f['acc']:6.2%} 段朴素={f['naive']:6.2%} {flag} "
              f"brier={f['brier']:.3f} auc={f['auc']:.3f}")
