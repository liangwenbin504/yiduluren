# -*- coding: utf-8 -*-
"""壬占汇选 v2 排盘自洽校验：日干支+月将+时辰 → 重算三传，比对原文三传。"""
import json, re, sys
sys.path.insert(0, ".")
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2

d = json.load(open("extracted_data/壬占汇选_训练数据_v2.json", encoding="utf-8"))
GAN = "甲乙丙丁戊己庚辛壬癸"
ZHI = "子丑寅卯辰巳午未申酉戌亥"
ZHI_SET = set(ZHI)
calc = SiKeSanChuanCalculator2()

# 三传行的六亲词（壬占汇选排盘，三传每行以六亲词开头）
LIUQIN = "财官父兄子鬼"
# 天将名（用于辅助排除，但核心靠六亲词开头）

# 三传完整模式：六亲 + 空格 + [空亡标记?] + 可选遁干 + [空亡标记?] 地支 + 空格 + 天将简称
# 关键：六亲/地支与天将之间强制空格分隔——三传行有空格，四课「地支地支」与「地支天将」紧邻无空格，
# 可避免六亲词「子」与地支「子」同字导致的误匹配。
# 天将简称全集：贵蛇螣腾朱合勾陈龙青空虎常玄武阴后白六天（白=白虎、六=六合、青=青龙、陈=勾陈）。
_SC_PAT = re.compile(
    r"[财官父兄子鬼][\s　]+[◎⊙]?([甲乙丙丁戊己庚辛壬癸])?[\s　]*[◎⊙]?"
    r"([子丑寅卯辰巳午未申酉戌亥])[\s　]+[贵蛇螣腾朱合勾陈龙青空虎常玄武阴后白六天]"
)

def extract_sanchuan(case_text):
    """从 case_text 排盘区提取三传地支（完整模式：六亲+遁干+地支+天将）。"""
    if not case_text:
        return None
    # 截取到第一个「曰」之前（排盘区），避免断语干扰
    pan = case_text.split("曰")[0] if "曰" in case_text else case_text
    zhis = [m.group(2) for m in _SC_PAT.finditer(pan)]
    if len(zhis) >= 3:
        return zhis[:3]
    return None

def extract_yuejiang(case_text):
    """从 case_text 提取月将地支（「X日Y将」）。"""
    if not case_text:
        return None
    m = re.search(r"[子丑寅卯辰巳午未申酉戌亥]日[\s　]*([子丑寅卯辰巳午未申酉戌亥])将", case_text)
    if m:
        return m.group(1)
    return None

def extract_shichen(case_text):
    """从 case_text 提取时辰地支（「Y将Z时」）。"""
    if not case_text:
        return None
    m = re.search(r"([子丑寅卯辰巳午未申酉戌亥])将[\s　]*([子丑寅卯辰巳午未申酉戌亥])时", case_text)
    if m:
        return m.group(2)
    return None

n_ok = 0        # 三项字段齐（可重算）
n_match = 0     # 三传完全一致
n_mismatch = 0  # 三传不一致（潜在错误）
n_no_sc = 0     # 无法提取原文三传
n_no_field = 0  # 字段缺失无法重算
mismatches = []

for i, c in enumerate(d):
    gz = c.get("ganzhi", "") or ""
    ct = c.get("case_text", "") or ""
    # ganzhi
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI_SET):
        n_no_field += 1
        continue
    rg, rz = gz[0], gz[1]
    # yuejiang
    yj = c.get("yuejiang", "") or ""
    ym = re.search(r"[子丑寅卯辰巳午未申酉戌亥]", yj)
    yj_zhi = ym.group(0) if ym else extract_yuejiang(ct)
    if not yj_zhi:
        n_no_field += 1
        continue
    # shichen
    sc = c.get("shichen", "") or ""
    sm = re.search(r"[子丑寅卯辰巳午未申酉戌亥]", sc)
    sc_zhi = sm.group(0) if sm else extract_shichen(ct)
    if not sc_zhi:
        n_no_field += 1
        continue

    n_ok += 1
    # 重算三传
    try:
        res = calc.calculate(rg, rz, yj_zhi, sc_zhi)
    except Exception:
        n_no_field += 1
        continue
    san = res.get("sanchuan", {})
    recomputed = [san.get("初传"), san.get("中传"), san.get("末传")]
    if not all(recomputed):
        n_no_field += 1
        continue

    # 提取原文三传
    orig = extract_sanchuan(ct)
    if not orig:
        n_no_sc += 1
        continue

    if orig == recomputed:
        n_match += 1
    else:
        n_mismatch += 1
        mismatches.append((i, gz, yj_zhi, sc_zhi, orig, recomputed))

print(f"总条目: {len(d)}")
print(f"字段缺失/无法重算: {n_no_field}")
print(f"可重算(三项齐): {n_ok}")
print(f"  原文三传无法提取: {n_no_sc}")
print(f"  三传完全一致: {n_match}")
print(f"  三传不一致(潜在错误): {n_mismatch}")
print()
print("=== 不一致样本（前30条）===")
for i, gz, yj, sc, orig, recom in mismatches[:30]:
    print(f"#{i} {gz}日 {yj}将 {sc}时 | 原文={orig} 重算={recom}")
