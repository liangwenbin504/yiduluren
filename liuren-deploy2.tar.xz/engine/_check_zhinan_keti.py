# -*- coding: utf-8 -*-
"""校验月将换算：原文课体 vs 引擎重算课体"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    data = json.load(f)
with open('extracted_data/_guji_fetch/大六壬指南_卷三_案例.json', encoding='utf-8') as f:
    raw = json.load(f)
raw_map = {(c['章节'], c['编号']): c for c in raw}

from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
ssc = SiKeSanChuanCalculator2()

# 课体归一化（去掉"课"字和无关词）
def norm_keti(lst):
    out = set()
    for k in lst:
        k = k.replace('课','')
        out.add(k)
    return out

match = 0
partial = 0
mismatch = []
for c in data['cases']:
    ch, num = c['name'][0], c['name'][1:]  # 章节+编号
    raw_c = raw_map.get((ch, num), {})
    orig_keti = norm_keti(raw_c.get('课体', []))
    # 引擎重算课体
    try:
        calc = ssc.calculate(c['ri_gan'], c['ri_zhi'], c['yue_jiang'], c['shichen'])
        eng_keti = norm_keti([calc['sanchuan'].get('课体','').replace('课','')])
    except Exception:
        eng_keti = set()
    if not orig_keti:
        continue
    if orig_keti & eng_keti:
        match += 1
        if not orig_keti <= eng_keti:
            partial += 1
    else:
        mismatch.append((c['id'], raw_c.get('课体'), calc['sanchuan'].get('课体','')))

total = len(data['cases'])
print(f'总案例 {total} | 课体一致(含部分) {match} ({match/total*100:.0f}%) | 完全一致 {match-partial}')
print(f'不一致 {len(mismatch)}:')
for cid, o, e in mismatch[:20]:
    print(f'  {cid}: 原文{o} vs 引擎{e}')
