# -*- coding: utf-8 -*-
"""26条三传不一致案例 - OCR原文仲裁
对比: v2原文三传 vs 重算三传 vs OCR(苏尔斯2025版)排盘三传
判定: v2对 / 引擎错 / OCR版不同 / 无法定位
"""
import json, re, sys
sys.path.insert(0, '.')
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2

ocr = open('_weread_full/ocr_all.txt', encoding='utf-8').read()
v2 = json.load(open('extracted_data/壬占汇选_训练数据_v2.json', encoding='utf-8'))
calc = SiKeSanChuanCalculator2()
ZHI = '子丑寅卯辰巳午未申酉戌亥'

# 从mismatch清单解析
mm = open('extracted_data/_rzhy_sanchuan_mismatch.txt', encoding='utf-8').read()
cases = []
for line in mm.split('\n'):
    m = re.match(r'#(\d+) (\S{2})日 (\S)将 (\S)时', line)
    if m:
        idx = int(m.group(1)); gz = m.group(2); yj = m.group(3); sc = m.group(4)
        om = re.search(r'原文=\[(.*?)\]', line)
        rm = re.search(r'重算=\[(.*?)\]', line)
        cases.append({
            'idx': idx, 'gz': gz, 'yj': yj, 'sc': sc,
            'orig': om.group(1).split(', ') if om else None,
            'recalc': rm.group(1).split(', ') if rm else None,
        })

def extract_ocr_sanchuan(seg):
    """从OCR排盘段提取三传地支（宽松模式：六亲/比父财官兄子鬼 后跟地支）"""
    # 三传行特征: 六亲词+可选遁干+地支，后面可能跟天将
    pat = re.compile(r'[财官父兄子鬼比][\s　]*([甲乙丙丁戊己庚辛壬癸])?[\s　]*([子丑寅卯辰巳午未申酉戌亥])[\s　]*[贵蛇螣腾朱合勾陈龙青空虎常玄阴后六白]?')
    zhis = []
    for m in pat.finditer(seg):
        z = m.group(2)
        if z not in zhis:
            zhis.append(z)
        if len(zhis) >= 3:
            break
    return zhis[:3]

print('='*100)
print(f'{"#":>4} {"案例":<8} {"v2原文三传":<12} {"重算三传":<12} {"OCR版三传":<12} 判定')
print('='*100)
verdicts = {'v2对': 0, '引擎错': 0, 'OCR版不同': 0, '无法定位': 0}
details = []
for c in cases:
    gz, yj, sc = c['gz'], c['yj'], c['sc']
    # OCR中定位
    pat = re.compile(re.escape(gz)+r'日[^将]{0,10}'+re.escape(yj)+r'将[^时]{0,10}'+re.escape(sc)+r'时')
    m = pat.search(ocr)
    if not m:
        verdict = '无法定位'
        ocr_sc = None
    else:
        seg = ocr[m.start():m.start()+400]
        ocr_sc = extract_ocr_sanchuan(seg)

    # 判定
    if ocr_sc is None:
        verdict = '无法定位'
    elif ocr_sc == c['orig']:
        verdict = 'v2对(OCR版同)'
    elif ocr_sc == c['recalc']:
        verdict = '重算对(v2文字错)'
    else:
        verdict = f'三者都不同(OCR={ocr_sc})'

    verdicts[verdict.split('(')[0]] = verdicts.get(verdict.split('(')[0], 0) + 1
    details.append((c, ocr_sc, verdict))
    print(f'#{c["idx"]:<4} {gz}{yj}{sc:<7} {str(c["orig"]):<12} {str(c["recalc"]):<12} {str(ocr_sc):<12} {verdict}')

print()
print('=== 统计 ===')
for k, v in verdicts.items():
    print(f'  {k}: {v}')

# 落盘详细结果
lines = ['26条三传不一致 OCR仲裁结果', '='*80,
         f'{"#":>4} {"案例":<8} {"v2原文":<12} {"重算":<12} {"OCR版":<12} 判定']
for c, ocr_sc, v in details:
    lines.append(f'#{c["idx"]:<4} {c["gz"]}{c["yj"]}{c["sc"]:<7} {str(c["orig"]):<12} {str(c["recalc"]):<12} {str(ocr_sc):<12} {v}')
open('extracted_data/_rzhy_mismatch_arbitration.txt', 'w', encoding='utf-8').write('\n'.join(lines))
print('\n已落盘: extracted_data/_rzhy_mismatch_arbitration.txt')
