# -*- coding: utf-8 -*-
"""给桌面《古例诚实评估与特征工程报告.docx》追加「股票域诚实回测」章节"""
import os
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

DESK = "C:/Users/Administrator/Desktop/仪度六壬_古例诚实评估与特征工程报告.docx"
doc = Document(DESK)

def H(txt, lvl=1):
    doc.add_heading(txt, level=lvl)

def P(txt, bold=False, color=None):
    p = doc.add_paragraph()
    r = p.add_run(txt)
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor(*color)
    return p

def table(headers, rows):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Light Grid Accent 1"
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        c.text = ""
        run = c.paragraphs[0].add_run(h)
        run.bold = True
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = str(v)
    return t

# ---------------- 第九章 ----------------
H("第九章 股票域自有特征库 · 诚实回测结论", 1)

P("按用户指令④——「用古例已验证的特征工程为参考，构建股票域自有的六壬涨/跌 valence 特征库」——"
  "本系统已实现并诚实检验。本章给出结论，并对照方法论红线说明为何古例的高准确率不能外推到股票。")

P("9.1 我们做了什么", bold=True)
P("复用古例已验证的确定性原语（extract_shen_sha_valence / extract_qiucai_valence），"
  "把「传统吉凶」映射为「股票涨/跌」，以 zhanlei='求财' 把股票当作财运域处理（股票本就是财）。"
  "新库 engine/stock_liuren_features.py 通过 analysis['_is_stock'] 门控注入融合层 collect_signals，"
  "与古例路径严格隔离（古例以 zhanlei== 门控、股票路径不置该键 → 零影响）。")

P("9.2 诚实评估设置", bold=True)
P("样本：上证指数 2005-01-04 ~ 2026-07-30，5239 个交易日（腾讯源真实日线）。"
  "独立市场标签：actual = 涨 if 收盘>开盘 else 跌（100% 独立于六壬输出，比古例标签更干净）。"
  "朴素基线：永远猜涨 = 1 − base_down_rate = 1 − 0.4468 = 55.32%。"
  "为隔离 caishen_enhance（在古例域已证有害的看涨注入器），A'/B' 两个变体均关闭 caishen；"
  "用 force=True 重算全部 5239 日以防旧缓存污染；固定 PYTHONHASHSEED=0 保证可复现。")
P("  · A' clean    : caishen OFF, stock_valence OFF（无财域注入的原始管线）")
P("  · B' stockval : caishen OFF, stock_valence ON（接入古例验证过的股票 valence）")

P("9.3 结果：A/B 对比 vs 朴素基线（55.32%）", bold=True)
table(
    ["变体/方法", "覆盖率", "决断准确率", "95%CI", "vs 50% p", "看跌偏置", "vs 55.3% 基线"],
    [
        ["A' clean / M1", "84.9%", "45.88%", "[44.4,47.3]", "0.000", "74.7%", "显著更低"],
        ["A' clean / M2", "98.1%", "51.22%", "[49.9,52.6]", "0.081", "42.8%", "显著更低"],
        ["A' clean / M3", "98.7%", "50.78%", "[49.4,52.1]", "0.260", "44.2%", "显著更低"],
        ["A' clean / M4", "59.5%", "46.01%", "[44.3,47.8]", "0.000", "82.4%", "显著更低"],
        ["B' stockval / M1", "84.9%", "45.88%", "[44.4,47.3]", "0.000", "74.7%", "显著更低"],
        ["B' stockval / M2", "99.2%", "47.25%", "[45.9,48.6]", "0.000", "77.0%", "显著更低"],
        ["B' stockval / M3", "99.4%", "46.38%", "[45.0,47.7]", "0.000", "79.4%", "显著更低"],
        ["B' stockval / M4", "59.5%", "46.01%", "[44.3,47.8]", "0.000", "82.4%", "显著更低"],
    ],
)
P("核心数字：朴素基线 55.32%（2898/5239 日为涨）。A' 的融合层 M3 已近硬币（50.78%，p=0.26）"
  "且看跌偏置仅 44.2%（近中性）；而 B' 打开股票 valence 后，M3 暴跌至 46.38%（p=0.000，显著劣于 50%），"
  "看跌偏置飙升至 79.4%。M1、M4 在两个变体中不变（valence 只经融合层注入，佐证其作用点）。"
  "A'/B' 全部方法均显著低于 55.3% 朴素基线（p<1e-3）——系统对「涨」存在结构性低报。", bold=True)

P("9.4 覆盖率（全 5239 日理论触发）", bold=True)
table(
    ["分量", "触发天数", "覆盖率"],
    [
        ["stock_ba_sha（八杀 valence）", "4709", "89.9%"],
        ["stock_shen_sha（神煞 valence）", "5239", "100.0%"],
        ["stock_qiucai（求财 valence）", "1638", "31.3%"],
    ],
)
P("神煞在每只盘都触发（100%），八杀 89.9%，求财仅 31.3%（财爻/青龙罕现三传）。"
  "正是这种「几乎每日都触发」的负向-only 神煞/八杀，把 B' 压成近恒定的「跌」预测。")

P("9.5 根因：域失配（坐实方法论红线）", bold=True)
P("古例 valence 是「负向-only」设计——神煞净负、八杀净负，映射 凶→跌。但两域分布相反："
  "古例 79% 为凶，而股票 55% 为涨；且神煞 100% 交易日触发 → 注入近恒定的「跌」压力。"
  "这恰好证明此前的方法论红线：古例 90.9% 验证的是「特征工程忠实还原传统六壬判断逻辑」（特征保真度），"
  "并非「六壬能预知未来」。把占卜域的标签/valence 直接移植到市场域，必然重蹈 Corpus B 假高准确率的覆辙。")

P("9.6 诚实 verdict 与下一步", bold=True)
P("诚实结论：股票域的六壬结构不存在方向 alpha；古例验证过的 valence 直接移植不仅无益、反而有害"
  "（M3 −4.4pp、看跌偏置 +35pp）。在股票域，引擎最多是一个「偏置中和器 / 叙事层」"
  "——clean 管线 M3≈50% 的近中性，靠的是关闭 caishen 后的原始融合，而非 stock valence。", bold=True)
P("若仍要坚持做股票方向预测，正确做法不是移植占卜标签，而是：在 5239 日股票标签上，"
  "用逻辑回归（或现有 calibration 设施）重新标定 valence 的符号与权重，让数据自己说话。"
  "否则应接受「无 alpha」这一科学结论，不再把六壬结构当作股票择时信号。")

P("交付物：engine/stock_liuren_features.py（库本体）、engine/regime_backtest_clean.json、"
  "engine/regime_backtest_stockval.json、engine/_run_stock_backtest.py（修正：run_engine 后须显式调 rb.main() 落报告）、"
  "engine/_compare_stock_backtest.py（A/B + 基线 + 覆盖率）。", color=(120,120,120))

doc.save(DESK)
print("已追加第九章并保存 ->", DESK)
