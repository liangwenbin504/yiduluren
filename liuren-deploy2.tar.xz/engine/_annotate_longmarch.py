# -*- coding: utf-8 -*-
"""长征第1期：宅墓 037-043 标注（批量，宅墓章收尾）"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§宅墓02·037": {
        "leishen": ["占宅基：干庚为人、支戌为宅", "子类神：子", "孙类神：寅(吏人)"],
        "liqi": ["宅来加申(戌为山岗)→后逼山", "宅上子作天后→前逼水", "水横过寅为直去", "东南风路螣蛇挠→吏人失陷财物"],
        "leixiang": ["女多男少", "子为吏人、孙为军卒仆从", "财退人散、水坏宅"],
        "yingqi": ["次年建造、不过十年连产四女"],
    },
    "§宅墓02·038": {
        "leishen": ["占宅：干癸为人、支酉为宅"],
        "liqi": ["四正相加非死即败", "午加酉作后发用→午火至酉无光", "子作龙加卯为无礼刑", "酉为酒色淫败"],
        "leixiang": ["男女淫奔、宅中淫乱不明(公淫媳)"],
        "yingqi": [],
    },
    "§宅墓02·039": {
        "leishen": ["占宅：干己为人、支巳为宅", "妇人类神：巳(双女为口)"],
        "liqi": ["申作勾加巳、巳为双女为口、申为骨牙勾主损折", "巳为炉灶乘旺相→新修"],
        "leixiang": ["妇人损一牙齿", "新修厨灶(新砖结砌)"],
        "yingqi": [],
    },
    "§宅墓02·040": {
        "leishen": ["占宅地风水：干壬为人、支寅为宅", "子孙类神"],
        "liqi": ["艮山行龙坎山落穴非正龙", "左边无山两重白虎第三重为案", "子午作元合→子孙邪淫", "壬日酉作天空→酒败"],
        "leixiang": ["子孙贪淫好酒、为酒家佣", "妇人不正淫奔", "墓内棺中有泥白蚁食尸", "为道童"],
        "yingqi": ["六年患酒病(酉6数)", "更三年终(六十七岁)"],
    },
    "§宅墓02·041": {
        "leishen": ["占葬地：干癸为人、支卯为宅", "子孙类神：卯(贵人)"],
        "liqi": ["辰为坟地作空亡发用→空穴", "戌墓加酉天空→虚坟", "巳加辰作贵(巳主双)→双峰文笔星", "申酉为水母→水合星辰"],
        "leixiang": ["前后左右有空穴、山侧阴人坟", "卯龙入首作乙山辛向", "文笔双峰→出双贵人"],
        "yingqi": ["庚戌年九月葬妻、以后子孙中举及第"],
    },
    "§宅墓02·042": {
        "leishen": ["占宅：干戊为人、支申为宅", "太阴少妇类神"],
        "liqi": ["日上空亡克日作勾陈→旧事牵己", "宅上午螣蛇带羊刃→家人争屋", "初传丑作天空在卯→泥土塞门户"],
        "leixiang": ["家人争屋四散分飞", "妇人脾腹疼白带", "太阴少妇管家"],
        "yingqi": ["来年难过", "乙卯年拆毁四散分居"],
    },
    "§宅墓02·043": {
        "leishen": ["占宅：干甲为人、支寅为宅", "妻财类神：末传戌"],
        "liqi": ["本命自来墓身→天网自裹", "发用空亡、中传临空(子息上见子息)→克子退子", "末见妻财→再娶"],
        "leixiang": ["克子退子、登仕路无寸进", "宅有井(未)克人"],
        "yingqi": ["十二年而死(未8数两个八年，后用一半)", "次年迁居免凶"],
    },
}

eng = SiKeSanChuanCalculator2(); gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))
real = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
real_by_id = {c["case_id"]: c for c in real}

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    rc = real_by_id.get(cid)
    if not rc:
        continue
    gz = rc.get("day_ganzhi", ""); yj = rc.get("yue_jiang", ""); shi = rc.get("shichen", "")
    # P1：起课统一到权威 V2 引擎
    tdp = eng.get_tiandi_pan(yj, shi)
    sike_tuples = eng.qi_sike(gz[0], gz[1], tdp)
    sike = [[t[0], t[1], t[2]] for t in sike_tuples]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tdp}, shi)
    sd = find_solar(rc.get("year"), rc.get("month"), gz) if rc.get("year") and rc.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, rc.get("sanchuan") or [], sike,
                         tj["天将映射"], tdp, rc.get("zhanlei", "其他"), sec=rc.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (rc.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（宅墓037-043）")
# 统计宅墓章标注进度
done = sum(1 for c in r["cases"] if c.get("sec") == "02" and c.get("status", "").startswith("已标注"))
total = sum(1 for c in r["cases"] if c.get("sec") == "02")
print(f"宅墓章：{done}/{total} 案已标注")
