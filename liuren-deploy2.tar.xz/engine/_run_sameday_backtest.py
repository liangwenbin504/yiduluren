# -*- coding: utf-8 -*-
"""当日预测(同天) 诚实回测驱动 —— 与次日(lead-1) 对照
================================================
当日设计：第 D 天的盘局预测第 D 天的涨跌（pred_offset=0）。
两个变体（均 caishen OFF、stock_valence OFF）：
  S1  sameday_full      : 六亲(十神) ON   —— 当日日干六亲预测基线
  S2  sameday_liuqinoff : 六亲(十神) OFF  —— 六亲信号组单独消融

纪律同前：force=True 重算；重定向 rb.REPORT；备份/还原生产 RAW_CACHE。
"""
import os, sys, json, time, shutil
sys.path.insert(0, ".")
import regime_backtest as rb
import engine.judgment_fusion as jf

RAW = rb.RAW_CACHE
RAW_BAK = RAW + ".prod.bak"
if os.path.exists(RAW) and not os.path.exists(RAW_BAK):
    shutil.copy(RAW, RAW_BAK)
    print("已备份原始 RAW_CACHE ->", RAW_BAK)

series = rb.parse_index()
print("total days:", len(series))


def run_variant(tag, disable_liuqin):
    rb.REPORT = os.path.join(rb.HERE, f"regime_backtest_{tag}.json")
    jf.DISABLE_CAISHEN = True
    os.environ["DISABLE_STOCK_VALENCE"] = "1"
    if disable_liuqin:
        os.environ["DISABLE_LIUQIN"] = "1"
    else:
        os.environ.pop("DISABLE_LIUQIN", None)
    t0 = time.time()
    rb.run_engine(series, force=True, pred_offset=0)   # 当日：D 盘 -> D 标签
    rb.main(pred_offset=0)
    print(f"[{tag}] done in {time.time()-t0:.0f}s -> {rb.REPORT}")


try:
    run_variant("sameday_full", disable_liuqin=False)      # S1
    run_variant("sameday_liuqinoff", disable_liuqin=True)  # S2
finally:
    if os.path.exists(RAW_BAK):
        shutil.copy(RAW_BAK, RAW)
        print("已还原原始 RAW_CACHE")

print("ALL DONE")
