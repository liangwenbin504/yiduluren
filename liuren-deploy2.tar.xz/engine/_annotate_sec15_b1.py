# -*- coding: utf-8 -*-
"""长征第1期 · sec15 亡盗 batch1 (188-195) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§亡盗15·188": {
        "leishen": ["婢：酉(酉又为婢)", "酒器：酉加亥为酒器", "太常：乘太常为丧服"],
        "liqi": ["干来加支即发用退归西北", "水日见亥亥内有壬壬加水→汪姓", "酉加亥为酒器酉又为婢作破碎乘太常为丧服", "亥四丑八去此三十二里"],
        "leixiang": ["亥=汪姓(壬水)、酉=婢(酒器破碎太常)、丑=空猪圈"],
        "yingqi": ["去此三十二里、崩败东厕内可擒之"],
    },
    "§亡盗15·189": {
        "leishen": ["子：支上之子", "未：干上之未(旬空)", "家贼：本家眷属"],
        "liqi": ["三传不行单只在支干上", "子未相害虽喜未能制子无奈未乃旬空不能克制徒作干上空亡", "未空不能生辛金而辛金反能生支上子水为之脱气→捉贼不得", "初传自宅发用末传又归宅上→贼不出门", "日传归日辰传归辰皆不是外人", "占人行年又在卯上→家贼无疑"],
        "leixiang": ["子=贼(支上)、未=旬空(干上)、家贼=眷属"],
        "yingqi": ["大兄二兄之子偷回房中三日后携出使用"],
    },
    "§亡盗15·190": {
        "leishen": ["婢：午(午为阴妇人)", "天后：末申作后(女鬼)", "楼阁：戌(戌为楼阁)", "元武：武乘戌"],
        "liqi": ["辰加寅作六合甲寅日纳音属水水墓辰", "日辰上见魁罡必主动近者远去", "甲寅水墓辰辰为初传午为阴妇人在辰上日阻关所以不进", "末申作后是女鬼加午道路上被鬼阻不行", "天后主厌翳藏匿", "勾在卯武乘戌戌为楼阁→藏高处阁上", "主败者内战"],
        "leixiang": ["辰=魁罡(水墓)、午=阴妇人(婢)、戌=楼阁(元武)、天后=藏匿"],
        "yingqi": ["次日于寺西南人家阁上擒之"],
    },
    "§亡盗15·191": {
        "leishen": ["婢：酉辰为婢", "虎：巳作虎临门户"],
        "liqi": ["日辰三传俱在阴位阴主伏匿", "巳作虎临门户上其人出门去便止", "己日为尊酉辰为婢今加日上是婢来就尊日辰相加所以不走", "酉六故不出六里必见"],
        "leixiang": ["酉=婢、巳=虎(门户)、阴位=伏匿"],
        "yingqi": ["东方六里内寻见失路不能归"],
    },
    "§亡盗15·192": {
        "leishen": ["婢：酉(酉为婢)", "独足：独足课"],
        "liqi": ["独足课【原文课体·独足】", "酉为婢加未不离身宅", "兼独足体一足焉能动"],
        "leixiang": ["酉=婢、独足=不能动"],
        "yingqi": ["不须寻当日归"],
    },
    "§亡盗15·193": {
        "leishen": ["类神：酉(酉金类神)", "天后：寅作后", "墓：中未墓作天空", "元武：辰作元武"],
        "liqi": ["寅作后加酉为隐蔽", "酉金类神也合加支上日上有丑墓", "寅作用中又末作墓覆其上凡见墓则为藏物", "有类神主其物不失", "中未墓作天空主污秽、辰作元武传人勾陈勾陈在酉而败元武→寻之必得"],
        "leixiang": ["酉=类神、寅=后(隐蔽)、未=墓(天空污秽)、元武=藏"],
        "yingqi": ["厕坑之侧寻见"],
    },
    "§亡盗15·194": {
        "leishen": ["类神：申(末申系类神)", "元武：辰作元武", "天空：辰上见天空"],
        "liqi": ["寅加亥为用末申系类神", "辰作元武加丑金墓辰上见天空→主污秽处藏匿", "寻之必见"],
        "leixiang": ["申=类神、辰=元武(金墓天空污秽)"],
        "yingqi": ["申牌后于厕坑左右寻得"],
    },
    "§亡盗15·195": {
        "leishen": ["类神：酉(酉为类神)", "蛇：得蛇亦巳火", "炉灶：巳(巳为炉灶)"],
        "liqi": ["金环以酉为类神初传即加巳上乃长生之地不落空亡又是三合金局→此物自己遗失见在必得", "巳为炉灶酉加之得蛇亦巳火→当失炉灶灰中", "火至冬而死故云灰中"],
        "leixiang": ["酉=类神(金环)、巳=炉灶(蛇火)、金局=不失"],
        "yingqi": ["炉下寻见"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec15 188-195）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
