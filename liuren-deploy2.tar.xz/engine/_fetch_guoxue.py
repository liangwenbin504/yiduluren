# -*- coding: utf-8 -*-
"""从古籍数字化源抓取大六壬指南/六壬大全/六壬粹言全文，保存到 extracted_data/"""
import urllib.request, re, os, time

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36'}
OUT = 'extracted_data/_guji_fetch'
os.makedirs(OUT, exist_ok=True)

def fetch(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')

def save(name, text):
    path = os.path.join(OUT, name)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    print(f'  ✓ {name}: {len(text)} 字')

def html_to_text(html):
    # 去 script/style
    html = re.sub(r'<script[\s\S]*?</script>', '', html, flags=re.I)
    html = re.sub(r'<style[\s\S]*?</style>', '', html, flags=re.I)
    # 换行标签
    html = re.sub(r'<(br|/p|/div|/li|/h\d)[^>]*>', '\n', html, flags=re.I)
    # 去所有标签
    text = re.sub(r'<[^>]+>', '', html)
    # 去空白
    text = re.sub(r'[ \t]+', '', text)
    text = re.sub(r'\n{2,}', '\n', text)
    return text.strip()

# 1. 国学大师网 - 大六壬指南卷三（会纂占验指南）
print('=== 1. guoxuedashi 大六壬指南卷三 ===')
try:
    html = fetch('https://m.guoxuedashi.com/a/4160w/53918m.html')
    txt = html_to_text(html)
    save('大六壬指南_卷三_会纂占验指南_guoxuedashi.txt', txt)
    # 找"下一章"链接
    links = re.findall(r'href="([^"]*)"[^>]*>([^<]*下一页[^<]*)', html)
    for u, t in links[:5]:
        print(f'  下一页链接: {u} ({t.strip()})')
except Exception as e:
    print(f'  ERR: {str(e)[:100]}')
