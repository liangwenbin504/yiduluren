# -*- coding: utf-8 -*-
"""长征第1期 · sec11 出行访谒(8) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§出行访谒11·149": {
        "leishen": ["驿马：巳(三层驿马)", "绝神：巳(巳乃癸之绝神)", "太常：未鬼作太常", "太阴：发用太阴"],
        "liqi": ["初以巳发用中传复回末传又见巳→半路归家", "宅上见巳初末皆巳巳乃癸之绝神虽为绝神却是三层驿马又以旬丁→主动", "中即传宅阴→半路归", "日上未鬼作太常→主亲戚眷属之服、日主外故主外服", "发用太阴→主阴人丧、所乘之巳为妻是妻之姐", "巳火亥水去了又来互换相冲不得不动既动彼此俱绝所以止"],
        "leixiang": ["巳=绝神(驿马旬丁妻)、未=太常(鬼服)、亥=冲"],
        "yingqi": ["半路归家", "亲姐死不得袁州去"],
    },
    "§出行访谒11·150": {
        "leishen": ["神后：子(北方黑色)", "天罡：辰(日上天罡)", "螣蛇：火神为用"],
        "liqi": ["子发用虽与日辰三合奈辰课不足→主事务未毕", "庚金子水发用庚落空亡不能生子子反畏日上天罡→主不出见", "罡加孟为在内→言在家", "庚为水之源而生神后神后加辰神后北方黑色交合辰土→生计是造墨", "润下卦有螣蛇火神为用→近水火之傍【原文课体·润下】"],
        "leixiang": ["子=神后(北方黑色)、辰=天罡(土)、螣蛇=火神"],
        "yingqi": ["访之不见因造墨未毕"],
    },
    "§出行访谒11·151": {
        "leishen": ["天后：不正之神", "六合：不正之神", "火局：炎上"],
        "liqi": ["寅午戌相习而为狂党天后六合不正之神又为失友→主下梢埋怨不足", "甲日火局十二分盗气支又来耗我→大有所费【原文课体·炎上】", "午来蚀甲天后六合皆不正之神→主酒色蛊惑", "四课不足虽厚本亦主消折"],
        "leixiang": ["寅午戌=狂党(炎上)、天后六合=不正(酒色)、午=蚀甲"],
        "yingqi": ["所得送娼家被官知觉", "仅与盘缠而归"],
    },
    "§出行访谒11·152": {
        "leishen": ["贵人：贵为日之三合", "酒食：未(未为酒食)", "六合：酉来合乙得六合"],
        "liqi": ["发用空传又贵为日之三合→主一贵人来", "未为酒食原为此贵设", "酉来合乙得六合→主寺门相见", "酉为酒克日→虽有酒不宴我", "贵人乘子加未空亡上"],
        "leixiang": ["未=酒食、酉=酒(克日)、子=贵人(空亡)"],
        "yingqi": ["寺门相见、不豫宴"],
    },
    "§出行访谒11·153": {
        "leishen": ["妻：申(丙以申为妻)", "勾陈：未作勾陈在本家", "驿马：寅马加亥"],
        "liqi": ["申生于巳亥生于申寅生于亥巳生于寅→相生连环", "宅上勾陈入庙→恋家卒难脱解", "丙以申为妻巳与申合又作六合更未作勾陈在本家→恋家", "至辛亥年巳亥相冲而寅申又冲十月亥月三个亥冲巳又寅马加亥→得冲而动", "能行动于东北者乃寅马合亥难脱得冲则行"],
        "leixiang": ["申=妻(六合)、巳=与申合、寅=驿马(东北)、未=勾陈(本家)"],
        "yingqi": ["辛亥年十月方得身动、往东北近二百里", "转西北、年六十九(癸丑终)"],
    },
    "§出行访谒11·154": {
        "leishen": ["驿马：日上驿马交驰", "天门：行年亥加巳天门地足"],
        "liqi": ["日上驿马交驰寅申各七数→七年之测", "行年亥加巳天门地足→主动必远"],
        "leixiang": ["寅申=驿马(七数)、亥=天门(地足)"],
        "yingqi": ["三千里之动、七年八年方归"],
    },
    "§出行访谒11·155": {
        "leishen": ["孤辰寡宿：真正孤辰寡宿课", "六害空亡：亥加申为用"],
        "liqi": ["亥加申为用乃六害空亡→是真正孤辰寡宿课【原文课体·孤辰寡宿】"],
        "leixiang": ["亥=孤辰(六害空亡)、申=寡宿"],
        "yingqi": ["孤恤一身单独一人"],
    },
    "§行人音信11·156": {
        "leishen": ["绝神：亥(亥作贵人加丁)", "财：宅上财作文书", "驿马：午(午加寅脚下生气)", "文书：破碎"],
        "liqi": ["亥作贵人加丁是绝神、亥又来克我→本主行人来", "宅上财作文书乘破碎→文书次第未备尚有更改", "行年在辰辰上见申亥水又生在申绝神带生→目下未归", "午加寅是行人脚下生气踪迹不定又过东北干事", "亥为绝神临日克日→主必归", "行年上见申又来生→故不归", "初传自宅上发用出来又归今日支神在东北上作末传宅神反出在彼→二不归", "日上亥水病于东北巳乃水绝反去彼绝其人在彼→三不归"],
        "leixiang": ["亥=绝神(贵人克日)、午=驿马(生气)、申=生(行年)、巳=水绝"],
        "yingqi": ["三月子日至(三月初九戊子至)"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec11 149-156）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
