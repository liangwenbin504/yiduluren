# -*- coding: utf-8 -*-
"""2x2 对照：当日(sameday) vs 次日(nextday) × 六亲ON vs 六亲OFF
并给出「当日日干六亲预测」(S1) 的各类别(年份/牛熊)准确率。"""
import os, sys, json, math
sys.path.insert(0, ".")
import regime_backtest as rb

VARIANTS = {
    "S1 当日六亲ON":  "nextday_full" if False else "sameday_full",
    "S2 当日六亲OFF": "sameday_liuqinoff",
    "N1 次日六亲ON":  "nextday_full",
    "N2 次日六亲OFF": "nextday_liuqinoff",
}
reps = {t: json.load(open(f"engine/regime_backtest_{t}.json", encoding="utf-8"))
        for t in set(VARIANTS.values())}

def binom_p(k, n, p0):
    if n == 0: return 1.0
    se = math.sqrt(n * p0 * (1 - p0))
    if se == 0: return 1.0
    z = (k - n * p0) / se
    return math.erfc(abs(z) / math.sqrt(2))

print("=== 2x2 总体 M3 vs 朴素基线 ===")
print(f"{'variant':16s} {'n':>5s} {'naive':>6s} {'M3_acc':>7s} {'CI95':>16s} {'p_vs50':>7s} {'excess':>8s} {'downbias':>8s}")
for lbl, tag in VARIANTS.items():
    r = reps[tag]
    naive = 1 - r["base_down_rate"]
    m = r["overall"]["M3"]
    excess = m["accuracy"] - naive
    print(f"{lbl:16s} {r['n_valid']:5d} {naive:6.2%} {m['accuracy']:7.2%} "
          f"[{m['ci95'][0]:.2%},{m['ci95'][1]:.2%}] {m['p_value']:7.3f} {excess:+8.2%} {m['down_bias']:8.1%}")

print("\n=== 六亲消融效应 (ON -> OFF) ===")
for design, on, off in [("当日", "sameday_full", "sameday_liuqinoff"),
                        ("次日", "nextday_full", "nextday_liuqinoff")]:
    a = reps[on]["overall"]["M3"]; b = reps[off]["overall"]["M3"]
    print(f"  {design}: M3 {a['accuracy']:.2%} -> {b['accuracy']:.2%}  "
          f"(Δ{(b['accuracy']-a['accuracy'])*100:+.2f}pp)  看跌偏置 {a['down_bias']:.1%}->{b['down_bias']:.1%}")

print("\n=== 当日日干六亲预测 (S1) 各类别准确率 ===")
r = reps["sameday_full"]
print("-- 按年份 --")
print(f"  {'year':6s} {'n':>5s} {'实际跌':>7s} {'M3_acc':>8s} {'p_vs50':>7s} {'downbias':>8s}")
for y, rr in r["by_year"].items():
    m3 = rr["M3"]
    print(f"  {y:6s} {rr['n']:5d} {rr['actual_down_rate']:7.1%} {m3['accuracy']:8.2%} {m3['p_value']:7.3f} {m3['down_bias']:8.1%}")
print("-- 按牛熊周期 --")
print(f"  {'cycle':18s} {'n':>5s} {'实际跌':>7s} {'M3_acc':>8s} {'p_vs50':>7s} {'downbias':>8s}")
for name, rr in r["by_cycle"].items():
    m3 = rr["M3"]
    # 该段朴素猜涨基线 = 1 - actual_down_rate
    naive_seg = 1 - rr["actual_down_rate"]
    flag = "  <基线" if m3["accuracy"] < naive_seg else "  >基线"
    print(f"  {name:18s} {rr['n']:5d} {rr['actual_down_rate']:7.1%} {m3['accuracy']:8.2%} {m3['p_value']:7.3f} {m3['down_bias']:8.1%}  (段朴素{naive_seg:.1%}{flag})")
