# -*- coding: utf-8 -*-
"""诊断「其他」占类：吉判凶案例的信号构成 + 原文标签核对。"""
import json, sys, os
from collections import Counter
sys.path.insert(0, ".")
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

def ok_yj(x):
    return isinstance(x, str) and x in VALID

wrong_list = []
ok_list = []
for c in REAL:
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rizhu = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rizhu or len(rizhu) < 2:
        continue
    truth = c.get("label", "")
    if truth not in ("吉", "凶", "平"):
        continue
    if c.get("zhanlei", "其他") != "其他":
        continue
    clean = {
        "id": c["case_id"], "name": c.get("name", ""), "category": "其他",
        "rizhu": rizhu, "yue_jiang": c["yue_jiang"] if ok_yj(c.get("yue_jiang")) else "",
        "shichen": c["shichen"] if ok_yj(c.get("shichen")) else "",
        "sanchuan": sc, "keti": [], "label": truth,
        "label_confidence": c.get("label_conf", 0),
        "month": c.get("month"), "ben_ming_zhi": c.get("ben_ming_zhi"),
        "year": c.get("year") or "",
    }
    pred = predict_ancient_case(clean, "M3")
    p = pred.get("prediction", "")
    rec = {
        "id": c["case_id"], "name": c.get("name", ""), "truth": truth, "pred": p,
        "label_ev": c.get("label_ev", ""), "original": (c.get("duanyu") or "")[:500],
        "signals": pred.get("fusion_detail", {}).get("signals") or pred.get("signals") or [],
        "score": pred.get("score"), "prob": pred.get("probability"),
    }
    if p != truth:
        wrong_list.append(rec)
    else:
        ok_list.append(rec)

print(f"「其他」占类: 共{len(wrong_list)+len(ok_list)}案, 判错{len(wrong_list)}案\n")
for r in wrong_list:
    print(f"### §{r['id']} {r['name']}  truth={r['truth']} pred={r['pred']}  label_ev={r['label_ev'][:60]}")
    print(f"  原文: {r['original'][:300]}")
    sigs = r["signals"]
    if sigs:
        for s in sigs:
            # 兼容 (group, score, up, conf) 或 dict
            if isinstance(s, (list, tuple)):
                g, sc, up, cf = s[0], s[1], s[2], s[3]
                print(f"    [{g}] {sc:+} (up={up}) conf={cf}")
            elif isinstance(s, dict):
                print(f"    [{s.get('group','?')}] {s.get('score',0):+} up={s.get('up')}")
    print()
