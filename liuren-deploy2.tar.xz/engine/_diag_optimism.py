# -*- coding: utf-8 -*-
"""诊断引擎在真实案上的"吉"乐观偏置来源：
统计每例 collect_signals 的各 group 信号(涨-positive分数)分布 + caishen override 触发率
+ 最终 mass 涨/跌。定位系统性推"吉"的信号组。
"""
import json
import sys
from collections import defaultdict, Counter
sys.path.insert(0, ".")
from engine.ancient_backtest import build_result_from_ancient
from engine.judgment_fusion import collect_signals, fuse

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")


def ok_zhi(x):
    return isinstance(x, str) and x in VALID


agg = defaultdict(lambda: {"pos": 0, "neg": 0, "zero": 0, "sum": 0.0, "n": 0})
caishen_ovr = 0
final_up = 0
final_down = 0
final_flat = 0
n = 0
up_when_truth_xiong = 0
truth_xiong = 0

for c in REAL:
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rizhu = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rizhu or len(rizhu) < 2:
        continue
    truth = c.get("label", "")
    if truth not in ("吉", "凶", "平"):
        continue
    clean = {
        "id": c["case_id"], "name": c.get("name", ""), "category": c.get("zhanlei", "其他"),
        "rizhu": rizhu,
        "yue_jiang": c["yue_jiang"] if ok_zhi(c.get("yue_jiang")) else "",
        "shichen": c["shichen"] if ok_zhi(c.get("shichen")) else "",
        "sanchuan": sc, "keti": [], "label": truth, "label_confidence": c.get("label_conf", 0),
    }
    result = build_result_from_ancient(clean)
    sigs = collect_signals(result)
    fj = fuse(result)
    n += 1
    for group, score, up, bconf in sigs:
        # score 是 涨-positive: >0 推吉, <0 推凶
        a = agg[group]
        a["n"] += 1
        a["sum"] += score
        if score > 0:
            a["pos"] += 1
        elif score < 0:
            a["neg"] += 1
        else:
            a["zero"] += 1
    reasons = " ".join(fj.get("active_signals", []))
    if "caishen_ovr" in reasons:
        caishen_ovr += 1
    mu = fj["mass"]["涨"]
    md = fj["mass"]["跌"]
    mf = fj["mass"]["平"]
    if mu > md and mu > mf:
        final_up += 1
        if truth == "凶":
            up_when_truth_xiong += 1
    elif md > mu and md > mf:
        final_down += 1
    else:
        final_flat += 1
    if truth == "凶":
        truth_xiong += 1

print(f"有效案例 n={n} | 真实凶案={truth_xiong}")
print("\n=== 各信号组 涨-positive 分数分布 ===")
print(f"{'group':<14}{'n':>5}{'推吉+':>7}{'推凶-':>7}{'零':>5}{'Σ分数':>9}{'均值':>8}")
for g, a in sorted(agg.items(), key=lambda kv: -kv[1]["sum"]):
    mean = a["sum"] / a["n"] if a["n"] else 0
    print(f"{g:<14}{a['n']:>5}{a['pos']:>7}{a['neg']:>7}{a['zero']:>5}{a['sum']:>9.1f}{mean:>8.2f}")

print(f"\n=== 最终倾向 ===")
print(f"  看涨(吉)={final_up}  看跌(凶)={final_down}  平={final_flat}")
print(f"  caishen override 触发率 = {caishen_ovr}/{n} ({caishen_ovr/n*100:.1f}%)")
print(f"  真实凶案中被判看涨(吉) = {up_when_truth_xiong}/{truth_xiong} ({up_when_truth_xiong/truth_xiong*100:.1f}%)  ← 乐观偏置核心")
print(f"  推吉信号总数 vs 推凶信号总数 = {sum(a['pos'] for a in agg.values())} vs {sum(a['neg'] for a in agg.values())}")
