# -*- coding: utf-8 -*-
"""长征第1期 · sec09 一课二事(3) + sec10 交易谋为(2) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§一课二事各断式09·144": {
        "leishen": ["官：申(初传申官)", "太常：日上巳作太常", "青龙：喜庆", "朱雀：举荐", "天后：恩泽"],
        "liqi": ["日上见巳作太常主兼职而费力", "甲木生巳火故费力、太常为职巳为双女故兼职", "初传申官临于双女之上亦是兼职", "中传亥与行年上亥皆是官长之属、亥为天庭朱雀为举荐", "末传寅为己身下临于长生之地又登天门上乘天后恩泽之神同生甲与寅木", "甲以亥为长生学堂故主绛帐之职、在天门则为内绛帐", "甲木生巳火虽费力却得天后水及亥水之生申金官星居巳火上又得青龙→费力中加升"],
        "leixiang": ["巳=双女(太常兼职)、申=官(青龙)、亥=天庭(长生学堂)、寅=己身(天后天门)"],
        "yingqi": ["任满面君得诸王宫教授", "汪五公买卖=染红紫退发斑点(染皂)"],
    },
    "§一课二事各断式09·145": {
        "leishen": ["墓：辰(日上见墓神)", "天后：滞神", "本命：本命在中传", "闭口：戌(戌为闭口)"],
        "liqi": ["日上见墓神天后又是滞神", "今方自墓中脱去中传未是旬末", "末传归家却见旬首旬首加旬尾", "本命在中传甲戌旬末是癸未未土癸水为三传全鬼却变成财", "若要求官仍复为鬼所以治生必然兴发", "刘一翁代占：行年在未上见戌为闭口戌为九月→九月积块疼痛气塞胀蛊而终"],
        "leixiang": ["辰=墓、未=旬末(本命)、戌=旬首(闭口)、天后=滞神"],
        "yingqi": ["刘判官治生十二年发三十五万贯", "刘一翁代占明年九月胀蛊而终"],
    },
    "§一课二事各断式09·146": {
        "leishen": ["官星：亥(本命在日上作初传即是官星)", "贵人：上见贵人", "太阴：宅上丑作太阴", "勾陈：末传为勾陈所拘"],
        "liqi": ["本命在日上作初传即是官星上见贵人贵人带官来→三十岁及第", "亥水克丁为官本命又是官是自家官星相催", "三十乃丙辰年分辰上见申申金生亥水官星有气故及第", "及第后大病先论官次论克、病得不死者亥卯未木局木能生火", "宅上丑作太阴终身居旧宅一生不能建造", "卯乃生丁之神卯数六故六任", "末传未是本身加日禄卯上为勾陈所拘木能生风死败之气乃虚风", "未死于卯丁败于卯未为守土之任既死败不能赴"],
        "leixiang": ["亥=官星(本命贵人)、卯=生丁(木局)、未=本身(勾陈虚风)、丑=太阴(旧宅)"],
        "yingqi": ["三十及第、六任授台州太守风瘫不能赴", "何学录四十九岁数不永辛亥死"],
    },
    "§交易谋为10·147": {
        "leishen": ["财：日上见财乘雀", "儿：巳(乙以巳为儿)", "雀：财乘雀"],
        "liqi": ["反吟体见凶将必难成【原文课体·反吟】", "日上见财乘雀→必见争闹而后成", "两家俱有孝服", "乙以巳为儿巳中丙戊二姓→过房子来争"],
        "leixiang": ["巳=儿(财雀)、反吟=难成"],
        "yingqi": ["周姓丧母罗姓丧妻", "三人作闹、丁丑日事成"],
    },
    "§交易谋为10·148": {
        "leishen": ["勾陈：支上丑作勾陈", "阴阳：三传四课皆阴"],
        "liqi": ["支上丑作勾陈→自宜用旧未利谋新", "三传四课皆阴→岂宜进干", "大吉临干为死旧天罡加日是生新", "阳宜动为生为新为德阴宜静为杀为旧为刑"],
        "leixiang": ["丑=勾陈(大吉死旧)、阴=宜静"],
        "yingqi": ["宜用旧未利谋新"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec09 144-146 + sec10 147-148）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
