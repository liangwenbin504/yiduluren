# -*- coding: utf-8 -*-
"""次日预测(lead-1) 诚实对比：N1(六亲ON) vs N2(六亲OFF) vs 朴素基线55.3%，并分各类别(年份/牛熊)列准确率"""
import os, sys, json, math
sys.path.insert(0, ".")
import regime_backtest as rb

TAGS = ("nextday_full", "nextday_liuqinoff")
reports = {t: json.load(open(f"engine/regime_backtest_{t}.json", encoding="utf-8")) for t in TAGS}
base_down = reports["nextday_full"]["base_down_rate"]
NAIVE_UP = 1.0 - base_down
series = rb.parse_index()
actual_up = sum(1 for d, (o, c) in series if c > o)
n_valid = reports["nextday_full"]["n_valid"]
print(f"次日预测设计: {reports['nextday_full']['pred_design']}")
print(f"有效交易日(去掉首日无前盘): {n_valid}  朴素基线(永远猜涨) = {NAIVE_UP:.2%}  (涨日 {actual_up}/{len(series)})")


def binom_p(k, n, p0):
    if n == 0: return 1.0
    se = math.sqrt(n * p0 * (1 - p0))
    if se == 0: return 1.0
    z = (k - n * p0) / se
    return math.erfc(abs(z) / math.sqrt(2))


print("\n=== A. 总体 A/B vs 朴素基线 55.3% ===")
print(f"{'variant':16s} {'method':4s} {'cov':>5s} {'acc':>7s} {'CI95':>16s} {'p_vs50':>7s} {'excess_vs53':>11s} {'downbias':>8s}")
for t in TAGS:
    label = "N1 六亲ON" if t == "nextday_full" else "N2 六亲OFF"
    o = reports[t]["overall"]
    for mk in ("M1", "M2", "M3", "M4"):
        m = o[mk]
        excess = m["accuracy"] - NAIVE_UP
        p_naive = binom_p(m["correct"], m["committed"], NAIVE_UP)
        print(f"{label:16s} {mk:4s} {m['coverage']:5.1%} {m['accuracy']:7.2%} "
              f"[{m['ci95'][0]:.2%},{m['ci95'][1]:.2%}] {m['p_value']:7.3f} {excess:+11.2%} {m['down_bias']:8.1%}")

print("\n=== B. 六亲(十神)信号组消融效应 (N1 -> N2, 看 M3 变化) ===")
m1 = reports["nextday_full"]["overall"]["M3"]
m2 = reports["nextday_liuqinoff"]["overall"]["M3"]
print(f"  M3 准确率: {m1['accuracy']:.2%} -> {m2['accuracy']:.2%}  (Δ{(m2['accuracy']-m1['accuracy'])*100:+.2f}pp)")
print(f"  M3 看跌偏置: {m1['down_bias']:.1%} -> {m2['down_bias']:.1%}")
print(f"  M3 覆盖率: {m1['coverage']:.1%} -> {m2['coverage']:.1%}")

print("\n=== C. 各类别准确率（N1 次日预测基线, M3）===")
print("-- 按年份 --")
print(f"  {'year':6s} {'n':>5s} {'实际跌':>7s} {'M3_acc':>8s} {'p_vs50':>7s} {'downbias':>8s}")
for y, r in reports["nextday_full"]["by_year"].items():
    m3 = r["M3"]
    print(f"  {y:6s} {r['n']:5d} {r['actual_down_rate']:7.1%} {m3['accuracy']:8.2%} {m3['p_value']:7.3f} {m3['down_bias']:8.1%}")

print("-- 按牛熊周期 --")
print(f"  {'cycle':18s} {'n':>5s} {'实际跌':>7s} {'M3_acc':>8s} {'p_vs50':>7s} {'downbias':>8s}")
for name, r in reports["nextday_full"]["by_cycle"].items():
    m3 = r["M3"]
    print(f"  {name:18s} {r['n']:5d} {r['actual_down_rate']:7.1%} {m3['accuracy']:8.2%} {m3['p_value']:7.3f} {m3['down_bias']:8.1%}")
