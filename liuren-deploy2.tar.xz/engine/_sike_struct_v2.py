# -*- coding: utf-8 -*-
"""四课天将改为真太阳时（浙江坐标 30N/120E）：
1. 从原文补农历月（month）
2. 干支年+农历月+日干支 → 公历日期（sxtwl）
3. get_gui_ren_pan 用真太阳时（日出日落）算天将
"""
import re, json, sys
sys.path.insert(0, '.')
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_daynight import get_gui_ren_pan
from engine.ganzhi_date import find_solar

text = open('data/断案疏正_全文.txt', encoding='utf-8').read()
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', text, flags=re.M)]
CN = {'正': 1, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7,
      '八': 8, '九': 9, '十': 10, '冬': 11, '腊': 12}
GZ = '甲乙丙丁戊己庚辛壬癸'
ZHI = '子丑寅卯辰巳午未申酉戌亥'
GAN = set(GZ)


def cn2int(s):
    if s == '十':
        return 10
    if s.startswith('十'):
        return 10 + CN.get(s[1], 0)
    if '十' in s:
        return CN.get(s[0], 0) * 10 + CN.get(s[-1], 0)
    return CN.get(s)


def extract_date(blk):
    """从案例 block 提取（干支年, 农历月, 日干支），用「干支日」作锚点向前找年月"""
    gz_m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])日', blk)
    if not gz_m:
        return None, None, None
    day_gz = gz_m.group(1)
    prefix = blk[:gz_m.start()]
    yues = list(re.finditer(r'([一二三四五六七八九十冬腊]+)月', prefix))
    lunar_month = cn2int(yues[-1].group(1)) if yues else None
    nians = list(re.finditer(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])年', prefix))
    year_gz = nians[-1].group(1) if nians else None
    return year_gz, lunar_month, day_gz


blocks = {}
for i, m in enumerate(titles):
    start = m.start()
    end = titles[i + 1].start() if i + 1 < len(titles) else min(start + 600, len(text))
    case_id = f'§{m.group(1)}{m.group(2)}·{m.group(3)}'
    blocks[case_id] = text[start:end][:500]

eng = DaLiuRenEngine()
real = json.load(open('engine/shuzheng_real_cases.json', encoding='utf-8'))
LAT, LON = 30.0, 120.0  # 浙江杭州

filled_month = 0
solar_ok = 0
for c in real:
    cid = c['case_id']
    gz = c.get('day_ganzhi', '')
    yj = c.get('yue_jiang', '')
    shi = c.get('shichen', '')
    # 1. 从原文提取年月（覆盖 JSON 可能错的 year，补 month；day_ganzhi 用 JSON 已验证值）
    blk = blocks.get(cid, '')
    year_gz, month, _ = extract_date(blk)
    if month:
        c['month'] = month
        filled_month += 1
    if year_gz:
        c['year'] = year_gz
    # 2. 日期换算
    solar_date = None
    if year_gz and month and len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI:
        solar_date = find_solar(year_gz, month, gz)
        if solar_date:
            solar_ok += 1
    # 3. 真太阳时天将
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI and yj in ZHI and shi in ZHI):
        continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    pan = get_gui_ren_pan(gz[0], shi, lat=LAT, lon=LON, d=solar_date)
    sike = []
    for k in sk:
        sike.append({'课': k['name'], '上神': k['top'], '下神': k['bottom'],
                     '天将': pan.get(k['top'], '')})
    c['sike'] = sike

json.dump(real, open('engine/shuzheng_real_cases.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'补农历月 {filled_month} 案；日期换算成功 {solar_ok} 案')
c = [x for x in real if x['case_id'] == '§宅墓02·036'][0]
print('§宅墓02·036 天将:', [k['天将'] for k in c.get('sike', [])])
