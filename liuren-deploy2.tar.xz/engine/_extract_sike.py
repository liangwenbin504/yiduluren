# -*- coding: utf-8 -*-
"""从 PDF 文字层提取四课（坐标法）——用完整三传行 word 定位三传，四课在三传左侧"""
import fitz, json, re

doc = fitz.open('data/大六壬断案疏正.pdf')
ZHI = '子丑寅卯辰巳午未申酉戌亥'
GAN = '甲乙丙丁戊己庚辛壬癸'
TJ = '后阴玄常虎空青勾合朱蛇贵'
LQ = '财官父兄子鬼比贼'

full = '\n'.join(doc[i].get_text() for i in range(len(doc)))
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', full, flags=re.M)]


def page_of(case_id):
    for i in range(len(doc)):
        if case_id in doc[i].get_text():
            return i
    return None


def extract_sike(page):
    raw = page.get_text('rawdict')
    # 收集 line（含 y、x、text）
    lines = []
    for b in raw['blocks']:
        for l in b.get('lines', []):
            txt = ''.join(ch['c'] for s in l.get('spans', []) for ch in s.get('chars', []))
            y, x = round(l['bbox'][1]), round(l['bbox'][0])
            lines.append((y, x, txt))
    # 三传定位：完整行「六亲+遁干?+地支+天将」 + 拆分「六亲」单字行
    sanchuan = []
    for y, x, txt in lines:
        if re.fullmatch(r'[' + LQ + r'](?:[' + GAN + r'])?[' + ZHI + r'][' + TJ + r']', txt):
            sanchuan.append((y, x))
        elif re.fullmatch(r'[' + LQ + r']', txt):
            sanchuan.append((y, x))
    if len(sanchuan) < 3:
        return None
    sanchuan.sort(key=lambda t: t[0])
    y_chu, y_zhong, y_mo = sanchuan[0][0], sanchuan[1][0], sanchuan[2][0]
    maxx = max(x for y, x in sanchuan)
    x_lo, x_hi = maxx - 105, maxx - 30

    # 用 rawdict 逐字符提取四课
    chars = []
    for b in raw['blocks']:
        for l in b.get('lines', []):
            for s in l.get('spans', []):
                for ch in s.get('chars', []):
                    x, y, c = ch['bbox'][0], ch['bbox'][1], ch['c']
                    if c.strip():
                        chars.append((round(x), round(y), c))

    def row(y, pred):
        return sorted([(x, c) for x, yy, c in chars
                       if abs(yy - y) <= 3 and pred(c) and x_lo <= x <= x_hi],
                      key=lambda t: -t[0])

    shang = row(y_zhong, lambda c: c in ZHI)
    xia = row(y_mo, lambda c: c in ZHI or c in GAN)
    jiang = row(y_chu, lambda c: c in TJ)
    if len(shang) < 4 or len(xia) < 4:
        return None
    sike = []
    for i in range(4):
        sike.append({
            '上神': shang[i][1] if i < len(shang) else '',
            '下神': xia[i][1] if i < len(xia) else '',
            '天将': jiang[i][1] if i < len(jiang) else '',
        })
    return sike


cases = {}
for pg in range(len(doc)):
    t = doc[pg].get_text()
    for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', t, re.M):
        case_id = f'§{m.group(1)}{m.group(2)}·{m.group(3)}'
        sike = extract_sike(doc[pg])
        if sike is None and pg + 1 < len(doc):
            sike = extract_sike(doc[pg + 1])  # 跨页 fallback
        if case_id not in cases or cases[case_id]['sike'] is None:
            cases[case_id] = {'case_id': case_id, 'sike': sike}
cases = list(cases.values())

json.dump(cases, open('data/_pdf_sike_cases.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
ok = sum(1 for c in cases if c['sike'] is not None)
print(f'四课提取：{ok}/{len(cases)} 案成功')
for c in cases[:8]:
    print(f"  {c['case_id']}: {c['sike']}")
