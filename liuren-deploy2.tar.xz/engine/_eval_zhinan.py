# -*- coding: utf-8 -*-
"""《大六壬指南》卷三 78案 单独评估（M3，与老语料分开跑）"""
import sys, json
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

from engine.ancient_backtest import run_backtest

report = run_backtest(str(BASE / 'engine' / 'ancient_truth_labels_zhinan_v3.json'), methods=['M3'])

print('\n===== 新语料(指南卷三78案) M3 评估 =====')
s = report['summary']['M3']
print(json.dumps(s, ensure_ascii=False, indent=1))
# 分类别
print('\n分类别:')
for cat, st in sorted(report['summary'].get('M3_categories', {}).items()):
    print(f"  {cat}: {st.get('correct',0)}/{st.get('total',0)} = {st.get('accuracy',0)*100:.1f}%")
# 错误案例
print('\n判错案例:')
for r in report['detailed_results']['M3']:
    if not r.get('correct'):
        print(f"  {r.get('case_id')} [{r.get('category')}] truth={r.get('truth')} pred={r.get('prediction')}")
