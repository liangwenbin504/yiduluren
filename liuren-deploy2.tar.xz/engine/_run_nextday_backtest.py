# -*- coding: utf-8 -*-
"""次日预测(lead-1) 诚实回测驱动
================================================
用户要求：用第 D-1 天的六壬盘局预测第 D 天的涨跌（领式 lead-1），再与真实对比。
两个变体（均 caishen OFF、stock_valence OFF，隔离财域看涨注入器）：
  N1  nextday_full     : pred_offset=1, 六亲(十神) ON   —— 次日预测基线
  N2  nextday_liuqinoff: pred_offset=1, 六亲(十神) OFF  —— 六亲信号组单独消融

纪律同前：force=True 重算；重定向 rb.REPORT；备份/还原生产 RAW_CACHE。
"""
import os, sys, json, time, shutil
sys.path.insert(0, ".")
import regime_backtest as rb
import engine.judgment_fusion as jf

RAW = rb.RAW_CACHE
RAW_BAK = RAW + ".prod.bak"
if os.path.exists(RAW) and not os.path.exists(RAW_BAK):
    shutil.copy(RAW, RAW_BAK)
    print("已备份原始 RAW_CACHE ->", RAW_BAK)

series = rb.parse_index()
print("total days:", len(series))


def run_variant(tag, disable_liuqin):
    rb.REPORT = os.path.join(rb.HERE, f"regime_backtest_{tag}.json")
    jf.DISABLE_CAISHEN = True                       # 关闭财域看涨注入器
    os.environ["DISABLE_STOCK_VALENCE"] = "1"       # 关闭股票 valence（本实验不评它）
    if disable_liuqin:
        os.environ["DISABLE_LIUQIN"] = "1"          # 六亲信号组消融
    else:
        os.environ.pop("DISABLE_LIUQIN", None)
    t0 = time.time()
    rb.run_engine(series, force=True, pred_offset=1)   # 次日预测：D-1 盘 -> D 标签
    rb.main(pred_offset=1)                             # 读缓存、统计、写报告
    print(f"[{tag}] done in {time.time()-t0:.0f}s -> {rb.REPORT}")


try:
    run_variant("nextday_full", disable_liuqin=False)      # N1
    run_variant("nextday_liuqinoff", disable_liuqin=True)  # N2
finally:
    # 还原生产参考缓存
    if os.path.exists(RAW_BAK):
        shutil.copy(RAW_BAK, RAW)
        print("已还原原始 RAW_CACHE")

print("ALL DONE")
