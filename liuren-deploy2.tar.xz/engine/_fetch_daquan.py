# -*- coding: utf-8 -*-
"""抓取维基文库 六壬大全（四库全书本）各卷"""
import urllib.request, re, os
from urllib.parse import quote

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36'}
OUT = 'extracted_data/_guji_fetch'
os.makedirs(OUT, exist_ok=True)

def fetch(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')

def save(name, text):
    with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
        f.write(text)
    print(f'  ✓ {name}: {len(text)} 字')

def wiki_to_text(html):
    m = re.search(r'<div[^>]*class="[^"]*mw-parser-output[^"]*"[\s\S]*?</div>\s*</div>', html)
    body = m.group(0) if m else html
    body = re.sub(r'<script[\s\S]*?</script>', '', body, flags=re.I)
    body = re.sub(r'<style[\s\S]*?</style>', '', body, flags=re.I)
    body = re.sub(r'<(br|/p|/div|/li|/h\d)[^>]*>', '\n', body, flags=re.I)
    body = re.sub(r'<[^>]+>', '', body)
    body = re.sub(r'[ \t]+', '', body)
    body = re.sub(r'\n{2,}', '\n', body)
    return body.strip()

# 目录页
base = 'https://zh.wikisource.org/wiki/'
title = '六壬大全_(四庫全書本)'
print('=== 抓目录页 ===')
try:
    html = fetch(base + quote(title))
    txt = wiki_to_text(html)
    save('六壬大全_目录_维基文库.txt', txt)
    # 找各卷链接
    vols = []
    for m in re.finditer(r'href="(/wiki/[^"]*六壬大全[^"]*)"[^>]*>([^<]{1,30})', html):
        u, t = m.group(1), m.group(2).strip()
        if '卷' in t:
            vols.append((t, u))
            print(f'  卷: {t} -> {u}')
    # 抓前3卷（卷一课体、卷二毕法、卷三）
    for t, u in vols[:3]:
        try:
            print(f'抓 {t} ...')
            h2 = fetch('https://zh.wikisource.org' + u)
            t2 = wiki_to_text(h2)
            save(f'六壬大全_{t}_维基文库.txt', t2)
        except Exception as e:
            print(f'  ERR {t}: {str(e)[:80]}')
except Exception as e:
    print(f'ERR: {str(e)[:150]}')
