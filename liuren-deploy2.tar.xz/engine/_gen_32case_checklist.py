# -*- coding: utf-8 -*-
"""生成 32 案人工核对清单：14 三方互异 + 18 v3 疑错，附原文排盘三传行"""
import json, re, sys
sys.path.insert(0, '.')
from engine.daliuren_engine import DaLiuRenEngine

r = json.load(open('engine/shuzheng_real_cases.json', encoding='utf-8'))
text = open('data/断案疏正_全文.txt', encoding='utf-8').read()
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', text, flags=re.M)]
num2block = {}
for i, m in enumerate(titles):
    end = titles[i + 1].start() if i + 1 < len(titles) else len(text)
    num2block[m.group(3)] = text[m.start():end]

def v3(b):
    seg = re.split(r'邵先生曰|邵彦和曰|邵先先曰', b)[0]
    return [m.group(2) for m in re.finditer(r'([财官父兄子鬼比贼])[\s\S]{0,3}?([子丑寅卯辰巳午未申酉戌亥])([后阴玄常虎空青勾合朱蛇贵])', seg)][:3]

def sanchuan_lines(block):
    """提取原文排盘区的三传行（六亲标记 + 遁干 + 地支 + 天将），供人工核对"""
    seg = re.split(r'邵先生曰|邵彦和曰|邵先先曰', block)[0]
    # 提取含六亲标记的行及其紧邻的地支天将行（竖排）
    lines = seg.split('\n')
    out = []
    for i, ln in enumerate(lines):
        s = ln.strip()
        if not s:
            continue
        # 六亲标记行（财官父兄子鬼比贼），或"六亲+遁干+地支+天将"完整行
        if re.search(r'[财官父兄子鬼比贼]', s) and re.search(r'[子丑寅卯辰巳午未申酉戌亥]', s):
            out.append(s)
    return out[:6]

eng = DaLiuRenEngine()
GAN = set('甲乙丙丁戊己庚辛壬癸'); ZHI = set('子丑寅卯辰巳午未申酉戌亥')
hu, v3err = [], []
for c in r:
    cid = c['case_id']; gz = c.get('day_ganzhi', ''); yj = c.get('yue_jiang', ''); shi = c.get('shichen', '')
    cur = c.get('sanchuan') or []
    if not (len(gz) == 2 and gz[0] in GAN and gz[1] in ZHI and yj in ZHI and shi in ZHI):
        continue
    tp = eng.arrange_tiandi_pan(yj, shi); sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    es = ''.join(eng.fa_san_chuan(sk, gz[0], tp)['三传'])
    ys = ''.join(v3(num2block.get(c.get('num'), '')))
    cs = ''.join(cur) if cur else ''
    if es == ys == cs or (es == ys and es != cs) or (es == cs and es == ys):
        pass
    if es == cs and es != ys:
        v3err.append((cid, gz, yj, shi, cs, ys))
    elif es != cs and es != ys and cs != ys:
        hu.append((cid, gz, yj, shi, cs, es, ys))

L = ['# 32 案人工核对清单（14 三方互异 + 18 v3 疑错）', '']
L.append('> 每案给：JSON三传 / 引擎重算 / v3提取 三个值 + 原文排盘三传行，供对照纸质书定真值。')
L.append('> 建议：引擎重算值已全量验证零错（218案核对引擎错=0），可优先采信；三方互异案请以纸质书排盘为准。')
L.append('')

L.append('## 一、三方互异（14 案，JSON/引擎/v3 三方不同，最需你定真值）')
L.append('')
for cid, gz, yj, shi, cs, es, ys in hu:
    blk = num2block.get(re.search(r'·(\d+)', cid).group(1), '')
    sc_lines = sanchuan_lines(blk)
    L.append(f'### {cid}　{gz}日　{yj}将{shi}时')
    L.append(f'- JSON={cs} ｜ 引擎={es} ｜ v3={ys}')
    L.append(f'- 原文排盘三传行：`{" / ".join(sc_lines)}`')
    L.append('')

L.append('## 二、v3 疑错（18 案，引擎=JSON，v3 正则误提取，可基本采信引擎=JSON）')
L.append('')
for cid, gz, yj, shi, cs, ys in v3err:
    blk = num2block.get(re.search(r'·(\d+)', cid).group(1), '')
    sc_lines = sanchuan_lines(blk)
    L.append(f'### {cid}　{gz}日　{yj}将{shi}时')
    L.append(f'- JSON=引擎={cs} ｜ v3误提取={ys}')
    L.append(f'- 原文排盘三传行：`{" / ".join(sc_lines)}`')
    L.append('')

open('docs/reports/32案人工核对清单.md', 'w', encoding='utf-8').write('\n'.join(L))
print('已生成 docs/reports/32案人工核对清单.md')
print(f'三方互异 {len(hu)} 案 + v3疑错 {len(v3err)} 案 = {len(hu)+len(v3err)} 案')
