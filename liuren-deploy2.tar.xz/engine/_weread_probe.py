# -*- coding: utf-8 -*-
"""微信读书《壬占汇选》提取流水线 - 探查版
目标：确认翻页机制、总页数、最佳截图区域，为整卷OCR打基础。
注意：仅用于校验项目已有v2数据的质量（个人合法副本对照），不对外分发。
"""
import asyncio, os, sys

URL = 'https://weread.qq.com/web/reader/33932640813abaad7g018f8ckc81322c012c81e728d9d180'
OUT = '_weread_pages'
os.makedirs(OUT, exist_ok=True)

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser = await p.chromium.launch(channel='msedge', headless=True)
        ctx = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
            viewport={'width': 1440, 'height': 1000})
        page = await ctx.new_page()
        # 拦截网络，找内容API
        api_hits = []
        page.on('request', lambda r: api_hits.append(r.url) if ('chapter' in r.url.lower() or 'content' in r.url.lower() or 'reader' in r.url.lower()) else None)
        await page.goto(URL, wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(6000)
        print('URL:', page.url)
        # 找页面指示器（如 "3 / 520"）
        ind = await page.evaluate('''() => {
            const els = [...document.querySelectorAll('*')];
            for (const e of els) {
                const t = e.innerText || '';
                const m = t.match(/\\d+\\s*\\/\\s*\\d+/);
                if (m && e.children.length === 0) return t.trim().slice(0,40);
            }
            return 'NO_PAGE_INDICATOR';
        }''')
        print('页码指示器:', ind)
        # 找 canvas 区域
        box = await page.evaluate('''() => {
            const c = document.querySelector('canvas');
            if (!c) return null;
            const r = c.getBoundingClientRect();
            return {x:r.x, y:r.y, w:r.width, h:r.height};
        }''')
        print('canvas区域:', box)
        # 测试翻页：尝试 ArrowRight / PageDown / 点击下一页
        for method in ['ArrowRight', 'PageDown']:
            try:
                await page.keyboard.press(method)
                await page.wait_for_timeout(1500)
                print(f'按 {method} 翻页 OK')
                break
            except Exception as e:
                print(f'按 {method} 失败: {str(e)[:50]}')
        # 截图前5页确认
        for i in range(5):
            path = os.path.join(OUT, f'p{i:03d}.png')
            if box:
                await page.screenshot(path=path, clip={'x': box['x'], 'y': box['y'], 'width': box['w'], 'height': box['h']})
            else:
                await page.screenshot(path=path)
            print(f'截图 {path}')
            try:
                await page.keyboard.press('ArrowRight')
                await page.wait_for_timeout(1500)
            except: pass
        print('=== 捕获的疑似内容API(前20) ===')
        for u in api_hits[:20]:
            print(' ', u)
        await browser.close()

asyncio.run(main())
