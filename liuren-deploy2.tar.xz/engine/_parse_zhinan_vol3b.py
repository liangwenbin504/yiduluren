# -*- coding: utf-8 -*-
"""解析v2：《大六壬指南》卷三 → 结构化（修正年/课体提取，课体用词典匹配）"""
import re, json
from collections import Counter

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_会纂占验指南_guoxuedashi.txt'
OUT = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'

KE_TI = ['元首','重审','知一','比用','涉害','见机','察微','复等','蒿矢','弹射','昴星','仰视','俯视',
         '别责','八专','伏吟','反吟','连茹','进茹','退茹','进间','退间','间传','玄胎','三交','乱首',
         '赘婿','度厄','无禄','绝嗣','天网','天狱','铸印','斫轮','斩关','高盖','迎阳','三光','三阳',
         '三奇','六仪','富贵','官爵','回环','周遍','稼穑','曲直','炎上','润下','从革','全局','升阶',
         '顾祖','龙战','虎斗','芜淫','独足','天心','游子','罗网','闭口','孤辰','寡宿','龙虎','不备',
         '励德','微服','斩关','三合','华盖','天马','天乙','贵人','驿马','德禄','生气','死气','四绝',
         '四离','天寇','天祸','二烦','六片板','六仪','空禄','祿粮','運粮','傳墓','脱氣','墓绝']
KE_TI = sorted(KE_TI, key=len, reverse=True)

with open(SRC, encoding='utf-8') as f:
    text = f.read()
lines = text.split('\n')
start = next(i for i, ln in enumerate(lines) if '会纂' in ln and '卷三' in ln)
lines = lines[start:]
for i, ln in enumerate(lines):
    if '返回' in ln and '检索' in ln and '首页' in ln:
        lines = lines[:i]
        break

CHAPTERS = ['总论','天时','阳宅','阴地','迁移','香火','婚姻','孕产','疾病','出行','行人','趋谒','选举',
            '武举','仕宦','求财','买卖','占讼','隐遁','逃亡','贼盗','田蚕','六畜','应候','岁占','射覆',
            '钦差','章奏','兵斗','三合']

cases = []
cur_chapter = ''
cur = None
for ln in lines:
    ln = ln.strip()
    if not ln:
        continue
    m = re.match(r'^(总论|天时|阳宅|阴地|迁移|香火|婚姻|孕产|疾病|出行|行人|趋谒|选举|武举|仕宦|求财|买卖|占讼|隐遁|逃亡|贼盗|田蚕|六畜|应候|岁占|射覆|钦差|章奏|兵斗|三合)章第[一二三四五六七八九十]+$', ln)
    if m:
        cur_chapter = m.group(1)
        continue
    m2 = re.match(r'^占验([一二三四五六七八九十]+)、(.*)$', ln)
    if m2:
        cur = {'章节': cur_chapter, '编号': m2.group(1), '正文': ln}
        cases.append(cur)
        continue
    if cur is not None:
        cur['正文'] += '\n' + ln

def extract_meta(body):
    meta = {'年': '', '月': '', '日干支': '', '时辰': '', '课体': [], '空亡': ''}
    head = body.split('。')[0]
    # 年：干支年（可能带"年"字或直接接月）
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])年?(?=[正二三四五六七八九十冬腊]月)', head)
    if m:
        meta['年'] = m.group(1)
    # 月
    m = re.search(r'([正二三四五六七八九十冬腊]月)', head)
    if m:
        meta['月'] = m.group(1)
    # 日干支
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])日', head)
    if m:
        meta['日干支'] = m.group(1)
    # 时辰
    m = re.search(r'([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])时', head)
    if m:
        meta['时辰'] = m.group(1)
    # 空亡
    m = re.search(r'((?:[子丑寅卯辰巳午未申酉戌亥]{1,2}[空]|旬空)[^。]{0,12}落空)', head)
    if m:
        meta['空亡'] = m.group(1).strip('，,、 ')
    # 课体：词典匹配
    found = []
    for kt in KE_TI:
        if kt in head:
            found.append(kt)
    # 去重保持顺序
    seen = set()
    meta['课体'] = [k for k in found if not (k in seen or seen.add(k))]
    return meta

for c in cases:
    meta = extract_meta(c['正文'])
    c.update(meta)
    m = re.search(r'(断曰|余曰|予曰|余答|愚按|予谓)[：:，]?([\s\S]*)$', c['正文'])
    c['断语'] = m.group(2).strip() if m else ''

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(cases, f, ensure_ascii=False, indent=1)

full = [c for c in cases if c['日干支'] and c['月']]
print(f'总案例: {len(cases)}')
print(f'有日干支+月: {len(full)}')
print(f'有日干支+月+时: {len([c for c in cases if c["日干支"] and c["月"] and c["时辰"]])}')
print(f'有断语: {len([c for c in cases if c["断语"]])}')
print(f'有课体: {len([c for c in cases if c["课体"]])}')
print()
cnt = Counter(c['章节'] for c in cases)
print('按章节:')
for k, v in cnt.items():
    print(f'  {k}: {v}')
print()
print('样例（孕产）:')
for c in cases:
    if c['章节'] == '孕产':
        print(f"  [{c['编号']}] 年={c['年']} 月={c['月']} 日={c['日干支']} 时={c['时辰']} 课体={c['课体']} 空亡={c['空亡']}")
