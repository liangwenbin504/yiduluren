# -*- coding: utf-8 -*-
"""《大六壬指南》卷三 78案 → ancient_backtest 评估格式
- 农历月 → 月支 → 月将（简化：按节气月取中气后月将，接受跨月误差，同壬占汇选口径）
- 三传缺失 → 引擎重算（SiKeSanChuanCalculator2）
- 单独文件，与老语料分开跑 A/B
"""
import json, sys, os
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'
OUT = 'engine/ancient_truth_labels_zhinan_v3.json'

# 农历月 → 月支
MONTH_TO_ZHI = {'正月':'寅','二月':'卯','三月':'辰','四月':'巳','五月':'午','六月':'未',
                '七月':'申','八月':'酉','九月':'戌','十月':'亥','十一月':'子','十二月':'丑'}
# 月支 → 月将（YUE_JIANG_ZHI 反向：月建→月将）
ZHI_TO_YUEJIANG = {'寅':'亥','卯':'戌','辰':'酉','巳':'申','午':'未','未':'午',
                   '申':'巳','酉':'辰','戌':'卯','亥':'寅','子':'丑','丑':'子'}

# 章节 → category
CAT_MAP = {'仕宦':'功名','选举':'功名','武举':'功名','孕产':'胎产','疾病':'疾病',
           '出行':'出行','行人':'出行','占讼':'官讼','婚姻':'婚姻','兵斗':'征战',
           '章奏':'其他','钦差':'其他','应候':'其他','贼盗':'走失','射覆':'其他','天时':'其他','阴地':'其他','求财':'求财','买卖':'求财'}

def main():
    with open(SRC, encoding='utf-8') as f:
        cases = json.load(f)

    # 取可判（吉/凶）且可接入（日+月+时）的案例
    usable = [c for c in cases if c['日干支'] and c['月'] and c['时辰'] and c.get('label') in ('吉','凶')]
    print(f'可判可接入: {len(usable)}')

    from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
    ssc = SiKeSanChuanCalculator2()

    out_cases = []
    no_sanchuan = 0
    for c in usable:
        rizhu = c['日干支']
        ri_gan, ri_zhi = rizhu[0], rizhu[1]
        yue_zhi = MONTH_TO_ZHI.get(c['月'], '')
        yue_jiang = ZHI_TO_YUEJIANG.get(yue_zhi, '')
        shichen = c['时辰']
        if not yue_jiang:
            print(f"  跳过(月无法换算): {c['章节']}/{c['编号']} 月={c['月']}")
            continue
        # 重算三传
        sanchuan = []
        try:
            calc = ssc.calculate(ri_gan, ri_zhi, yue_jiang, shichen)
            sanchuan = [x for x in (calc.get('sanchuan') or [])]
            if len(sanchuan) == 1 and isinstance(sanchuan[0], str) and len(sanchuan[0]) >= 3:
                sanchuan = [sanchuan[0][i] for i in range(3)]
        except Exception as e:
            print(f"  三传重算失败 {c['章节']}/{c['编号']}: {str(e)[:60]}")
        if len(sanchuan) < 3:
            no_sanchuan += 1
            sanchuan = sanchuan + [''] * (3 - len(sanchuan))
        out_cases.append({
            'source': 'Zhinan_Vol3',
            'id': f"ZN-{c['章节']}-{c['编号']}",
            'name': c['章节'] + c['编号'],
            'question': c['章节'],
            'category': CAT_MAP.get(c['章节'], '其他'),
            'ri_gan': ri_gan, 'ri_zhi': ri_zhi, 'rizhu': rizhu,
            'yue_jiang': yue_jiang, 'shichen': shichen,
            'keti': c['课体'],
            'sanchuan': sanchuan,
            'era': '古代',
            'label': c['label'],
            'label_confidence': 0.85,
            'label_evidence': c.get('label_ev', ''),
            'interpretation': c['断语'],
            'month': c['月'],
        })

    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump({'cases': out_cases}, f, ensure_ascii=False, indent=1)
    print(f'已生成 {OUT}: {len(out_cases)} 案（三传不全 {no_sanchuan}）')
    from collections import Counter
    print('category:', dict(Counter(x['category'] for x in out_cases)))
    print('label:', dict(Counter(x['label'] for x in out_cases)))
    # 样例
    for c in out_cases[:3]:
        print(f"  {c['id']} {c['rizhu']} {c['yue_jiang']}将 {c['shichen']} 三传{c['sanchuan']} {c['label']}")

if __name__ == '__main__':
    main()
