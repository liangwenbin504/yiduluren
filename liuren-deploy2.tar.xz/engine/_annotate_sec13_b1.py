# -*- coding: utf-8 -*-
"""长征第1期 · sec13 疾病 batch1 (162-170) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§疾病13·162": {
        "leishen": ["长生：日上长生(空亡)", "寺院：申(申为寺院)", "肺：申(申金肺脏)"],
        "liqi": ["日上长生是空亡申为寺院虚生是寄舍", "壬受申之虚生却去生寅木木生巳火巳火克申金申金受克走来壬上避之非本意来生→终身瘦弱", "申数七亥数四四七二十八", "初巳火主上热末亥水主下冷上膈在热而不渴中间缘寅木主风气相击下部不通", "巳火伤申金→肺脏上喘"],
        "leixiang": ["巳=火(上热)、亥=水(下冷)、寅=木(风气)、申=肺(寺院空亡)"],
        "yingqi": ["二十一岁后状如老人", "二十八岁不能过(申七亥四)"],
    },
    "§疾病13·163": {
        "leishen": ["午：四午蚀甲寅", "病符：六月午为月病符", "天鬼：四个天鬼", "白虎：四个白虎", "心：午(午为心)"],
        "liqi": ["日辰皆见午甲寅二木皆死于午那堪中末又是午初传又是绝神", "六月午为月病符旺火蚀休木本宫又克父母", "日上午辰上午中传午末传午共四午来蚀甲寅→四个月病符四个天鬼四个天地转杀四个白虎→丧四子", "午为心遇虎→主颠狂", "木死于午→为废人"],
        "leixiang": ["午=心(病符天鬼白虎)、寅木=死于午"],
        "yingqi": ["三十七癫痴、三十九又复", "四十一岁太岁到寅死"],
    },
    "§疾病13·164": {
        "leishen": ["心：午(日上见午为心)", "蛇：午作蛇", "血：亥(亥坐空亡)", "天后：辰加亥为天后"],
        "liqi": ["日上见午为心癸水灭午火又空亡→心受制而不足", "午为阴人空则无位为妾蛇在午上扰→为此阴人所苦", "午为目蛇扰水制又空亡→自然昏暗", "己卯生人禄在午空则乱蛇扰→痛", "戌土上见青龙→主多趾、戌为足", "血败者亥坐空亡又乘天空", "血瘿者辰加亥为天后辰坚土加血上→血瘿、天后主厌秽癸水人辰墓→瘿破而死"],
        "leixiang": ["午=心(蛇妾目)、亥=血(空亡天空)、辰=血瘿(天后墓)、戌=足(青龙多趾)"],
        "yingqi": ["生子十一胎存三人", "四十一血败三年成瘿", "五十四养蚕夜出瘿破血死"],
    },
    "§疾病13·165": {
        "leishen": ["父母：寅(丙日寅为父母爻)", "白虎：寅上见白虎", "妻：妻宫", "财：财爻入课"],
        "liqi": ["自本身传归妻宫妻宫又传归父母", "六旬向上人占病不宜见父母、父母既故是下世重见父母", "因财上及旧事不足以致伤心", "中间又是财爻入课必是财切兼与妻不足→激成病", "丙日寅为父母爻上见白虎→父母坟不安", "六旬人见父爻本不利然寅为丙之长生故得不死", "父母宫艮山坟左边地风吹骨转右边白蚁入棺→移坟可延年"],
        "leixiang": ["寅=父母(白虎坟不安)、巳=本身、申=财妻"],
        "yingqi": ["移坟病退、安乐八十岁方卒"],
    },
    "§疾病13·166": {
        "leishen": ["脱气：上下俱脱", "水：日上生水(冷涎)", "火：支上见巳(虚火)"],
        "liqi": ["上下俱脱→病恐是泄泻上得之", "日上生水金去生水→多主冷涎", "支上见巳木生虚火→必心下不宁兼之白浊", "始终见凶神上下皆盗气", "巳亥俱四数申数七四七二十八两爽皆见五十六日"],
        "leixiang": ["申=金(冷涎)、亥=水、巳=火(虚火心下)"],
        "yingqi": ["死在二十八日不然再历二十八日(五十六日)"],
    },
    "§疾病13·167": {
        "leishen": ["木局：满盘皆财", "天医：中传", "地医：末传", "白虎：兽头"],
        "liqi": ["金日得木局满盘皆财", "午来化许多败气木又死于午作贵人偏不利医贵人", "天医在中传地医在末传能制午火", "白虎立亥在卯之上是本家屋上之兽头", "亥本宫上见未有夜之白虎是西北邻家之兽头"],
        "leixiang": ["木局=财、午=败气(不利医)、白虎=兽头、天医地医=制午火"],
        "yingqi": ["次年正月初七治翻胃即效、三月十八治小儿中风即效"],
    },
    "§疾病13·168": {
        "leishen": ["妻：支上未为妻", "勾陈：酉作勾陈", "天后：寅加妻爻上作天后", "太常：手帕"],
        "liqi": ["日上见酉作勾陈思虑已伤肌肤", "酉为闭口此事难言", "日投入四课发用复传归日循环不断", "支为宅支上未为妻四课者宅内也是妻家", "寅投入四课加妻爻上作天后→与妻家妇人通", "酉为色勾为思虑今得日鬼→思虑已伤肌肤", "辰为皮为肌肤加酉败气上乘元武为走泄→主消瘦", "行年在戌戌上巳作太常常主丝棉是手帕、巳与酉三合→情人之物"],
        "leixiang": ["酉=色(勾陈闭口)、寅=天后(私情)、辰=肌肤(元武消瘦)、巳=太常(手帕)"],
        "yingqi": ["思虑成病肌肤消瘦、服药而愈"],
    },
    "§疾病13·169": {
        "leishen": ["天鬼：午(天鬼午)", "羊刃：中末日上三个羊刃杀", "龙：夺命神"],
        "liqi": ["天鬼午受病鬼之生犯了东岳城隍香火神→疫气入宅主合宅病", "寅正春旺之鬼鬼有气不止一人", "中末日上三个羊刃杀→丧三人", "龙到巳午皆名夺命神最不利"],
        "leixiang": ["午=天鬼(羊刃)、寅=春旺之鬼、龙=夺命神"],
        "yingqi": ["七口病死三人、急告东岳余免"],
    },
    "§疾病13·170": {
        "leishen": ["子息：子(胎在子)", "六合：日上子作六合", "水局：丁日会起水局(鬼)"],
        "liqi": ["丁日火生于寅胎在子子又为子息更作六合临日→主孕", "会起水局为鬼→故曰鬼胎【原文课体·水局鬼胎】", "末见卯与子刑→次年二月见鬼形", "若不会起申子辰却是官星→必生贵子非鬼胎"],
        "leixiang": ["子=胎(六合子息)、卯=刑(鬼形)、水局=鬼胎"],
        "yingqi": ["次年二月三日生鬼胎"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec13 162-170）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
