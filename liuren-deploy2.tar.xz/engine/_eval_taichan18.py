# -*- coding: utf-8 -*-
"""胎产 18 案合评：断案7 + 指南5 + 壬占汇选6"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

# 1. 断案 7 案
with open('engine/shuzheng_real_cases.json', encoding='utf-8') as f:
    shuzheng = json.load(f)
cases = shuzheng if isinstance(shuzheng, list) else shuzheng.get('cases', [])
old = [c for c in cases if c.get('zhanlei') == '胎产' or '胎产' in (c.get('zhanlei_code') or '')]
old_out = []
for c in old:
    sc = c.get('sanchuan') or []
    if isinstance(sc, str):
        sc = list(sc[:3])
    old_out.append({
        'source': 'Longmarch', 'id': c.get('case_id', ''),
        'name': c.get('case_id', ''), 'question': '胎产', 'category': '胎产',
        'ri_gan': (c.get('day_ganzhi') or '')[:1], 'ri_zhi': (c.get('day_ganzhi') or '')[1:2],
        'rizhu': c.get('day_ganzhi', ''), 'yue_jiang': c.get('yue_jiang', ''),
        'shichen': c.get('shichen', ''), 'keti': c.get('keti', []), 'sanchuan': sc,
        'era': '古代', 'label': c.get('label', ''), 'label_confidence': 0.9,
        'label_evidence': '', 'interpretation': c.get('duanyu', ''),
    })

# 2. 指南 5 案
with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    zn_tc = [c for c in json.load(f)['cases'] if c['category'] == '胎产']

# 3. 壬占汇选 6 案
with open('engine/ancient_truth_labels_rzhy.json', encoding='utf-8') as f:
    rz_tc = [c for c in json.load(f)['cases'] if c['category'] == '胎产']

merged = old_out + zn_tc + rz_tc
with open('engine/ancient_truth_labels_taichan18.json', 'w', encoding='utf-8') as f:
    json.dump({'cases': merged}, f, ensure_ascii=False, indent=1)
print(f'合并 {len(merged)} 案: 断案{len(old_out)} + 指南{len(zn_tc)} + 壬占汇选{len(rz_tc)}')

from engine.ancient_backtest import run_backtest
report = run_backtest(str(BASE / 'engine' / 'ancient_truth_labels_taichan18.json'), methods=['M3'])
s = report['summary']['M3']
print(f'\n胎产{len(merged)}案 M3: {s["correct"]}/{s["total"]} = {s["accuracy"]*100:.1f}%')
print('混淆:', json.dumps(s['confusion_matrix'], ensure_ascii=False))
print('\n逐案:')
for r in report['detailed_results']['M3']:
    mark = 'OK' if r.get('correct') else 'XX'
    print(f"  {mark} {r.get('case_id')} [{r.get('source')}] truth={r.get('truth')} pred={r.get('prediction')}")
