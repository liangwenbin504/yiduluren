# -*- coding: utf-8 -*-
"""ML 重标定 valence 驱动：跑当日/次日(日内+次日收益) 三变体 × LR/HGB，落盘 JSON。"""
import os, sys, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for _p in (ROOT, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import engine.judgment_fusion as jf
import engine.ml_valence as mv

jf.DISABLE_CAISHEN = True                       # 关财域看涨注入器，聚焦六壬结构
os.environ.pop("DISABLE_LIUQIN", None)           # 保留六亲作为特征
os.environ.pop("DISABLE_STOCK_VALENCE", None)    # 保留股票 valence 作为特征

t0 = time.time()
res = mv.run_all()
OUT = os.path.join(mv.rb.HERE, "regime_backtest_ml.json")
json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=2, default=str)
print(f"\n已落盘 -> {OUT}  ({time.time()-t0:.0f}s)")
