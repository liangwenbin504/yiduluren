# -*- coding: utf-8 -*-
"""从天地盘反推月将（大六壬指南卷三）
原理：天盘 = 月将加时；地盘时辰位上的天盘地支 = 月将
盘面格式：4行"天将+天盘地支"（行1→巳午未申、行2→辰酉、行3→卯戌、行4→寅丑子亥）
"""
import json, re
from collections import Counter

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'
with open(SRC, encoding='utf-8') as f:
    cases = json.load(f)

TIAN_JIANG = set('贵蛇朱六勾青龙空虎常玄阴后')
ZHI = set('子丑寅卯辰巳午未申酉戌亥')

# 地盘布局（4行，每行从左到右）
DI_PAN_LAYOUT = [
    ['巳','午','未','申'],
    ['辰','酉'],
    ['卯','戌'],
    ['寅','丑','子','亥'],
]

def extract_pan_rows(body):
    """从正文提取盘面4行（天将+地支混合行）"""
    rows = []
    for ln in body.split('\n'):
        ln = ln.strip()
        if not ln:
            continue
        # 盘面行 = 含天将字 且 含地支 且 不含六亲词(财官父兄子)且不含断曰
        if any(t in ln for t in TIAN_JIANG) and any(z in ln for z in ZHI):
            if re.search(r'[财官父兄子]', ln) or '断曰' in ln or '余曰' in ln:
                continue
            # 提取地支（去掉天将）
            zhis = [ch for ch in ln if ch in ZHI]
            if zhis and len(zhis) in (2,4):
                rows.append(zhis)
    return rows

def reverse_yj(rows, shichen):
    """从盘面行反推月将"""
    if len(rows) < 4:
        return '', '盘面行不足'
    # 文本顺序 → 地盘
    di_to_tian = {}
    for row_zhi, di_row in zip(rows, DI_PAN_LAYOUT):
        for i, t in enumerate(row_zhi):
            if i < len(di_row):
                di_to_tian[di_row[i]] = t
    if shichen not in di_to_tian:
        return '', f'时辰{shichen}不在盘面'
    return di_to_tian[shichen], ''

# 验证：用已知月将案例（搜狐版）
KNOWN = [
    ('选举','四','巳','子'),   # 占验四 子将
    ('仕宦','三十四','未','寅'),  # 占验三十四 寅将
    ('仕宦','三十六','申','亥'),  # 占验三十六 亥将
]
print('=== 已知月将案例验证 ===')
for ch, num, shi, expect in KNOWN:
    for c in cases:
        if c['章节'] == ch and c['编号'] == num:
            rows = extract_pan_rows(c['正文'])
            yj, err = reverse_yj(rows, shi)
            ok = '✓' if yj == expect else '✗'
            print(f'  {ch}/{num} {c["日干支"]} {shi}时 反推={yj}将 期望={expect}将 {ok} {err}')
            break

# 全量反推
print('\n=== 全量反推 78案 ===')
results = []
for c in cases:
    if not (c['日干支'] and c['月'] and c['时辰'] and c.get('label') in ('吉','凶')):
        continue
    shi = c['时辰'][-1]
    rows = extract_pan_rows(c['正文'])
    yj, err = reverse_yj(rows, shi)
    results.append((c['章节'], c['编号'], c['日干支'], c['月'], shi, yj, err))

ok = [r for r in results if r[5]]
print(f'总78案 | 反推成功 {len(ok)} | 失败 {len(results)-len(ok)}')
# 失败案例分析
fails = [r for r in results if not r[5]]
for f in fails[:15]:
    print(f'  失败: {f[0]}/{f[1]} {f[2]} {f[3]} {f[4]}时 {f[6]}')
# 保存
with open('extracted_data/_guji_fetch/指南卷三_反推月将.json', 'w', encoding='utf-8') as f:
    json.dump([{'章节':r[0],'编号':r[1],'日干支':r[2],'月':r[3],'时辰':r[4],'月将':r[5],'err':r[6]} for r in results], f, ensure_ascii=False, indent=1)
print('\n已保存 指南卷三_反推月将.json')
