# -*- coding: utf-8 -*-
"""诊断：确认 ancient_backtest 路径真实产出 八杀/神煞，并统计可抽取比例。"""
import json
import sys
sys.path.insert(0, ".")
from collections import Counter
from engine.ancient_backtest import build_result_from_ancient

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")


def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2:
        return None
    if c.get("label") not in ("吉", "凶", "平"):
        return None
    return {
        "rizhu": rz,
        "yue_jiang": c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
        "shichen": c["shichen"] if c.get("shichen") in VALID else "",
        "sanchuan": sc,
        "keti": [],
        "duanyu": c.get("duanyu", ""),
        "label": c["label"],
    }


cases = [x for x in (build_clean(c) for c in REAL) if x]
print(f"有效真实案: {len(cases)}")

# 八杀各杀出现统计（含空亡/未现）
ba_sha_present = Counter()
ba_sha_real = 0  # 至少一个非"未现"的杀
# 神煞（日干支-based 才是真实）统计
REAL_SHEN = ["驿马", "劫煞", "灾煞", "贵人", "日德", "日禄", "桃花", "天罗", "地网", "天乙贵人"]
shen_present = Counter()
shen_real_case = 0  # 至少一个真实神煞
n_ba = 0
n_shen = 0

for clean in cases:
    res = build_result_from_ancient(clean)
    a = res.get("analysis", {})
    ba = a.get("ba_sha", {}) or {}
    ss = a.get("shen_sha", {}) or {}
    # 八杀
    if isinstance(ba, dict):
        n_ba += 1
        for x in ba.get("八杀明细", []):
            if isinstance(x, dict):
                ba_sha_present[x.get("杀", "?")] += 1
                if x.get("状态") != "未现":
                    ba_sha_real += 1
    # 神煞
    if isinstance(ss, dict):
        n_shen += 1
        has_real = False
        for k in REAL_SHEN:
            if ss.get(k):
                shen_present[k] += 1
                has_real = True
        if has_real:
            shen_real_case += 1

print(f"\n八杀路径产出: {n_ba}/{len(cases)} 例有 ba_sha dict")
print("八杀各杀(含空亡/未现)出现计数:")
for k, v in ba_sha_present.most_common():
    print(f"   {k:<4} {v}")
print(f"   非'未现'杀实例总数: {ba_sha_real}")

print(f"\n神煞路径产出: {n_shen}/{len(cases)} 例有 shen_sha dict")
print("真实神煞(日干支-based)出现计数:")
for k in REAL_SHEN:
    print(f"   {k:<6} {shen_present.get(k,0)}")
print(f"   至少一个真实神煞的例数: {shen_real_case}")

# 样例：打印第1个有八杀/神煞的 case
for clean in cases[:3]:
    res = build_result_from_ancient(clean)
    a = res.get("analysis", {})
    print(f"\n--- 样例 rizhu={clean['rizhu']} sanchuan={clean['sanchuan']} ---")
    print("  八杀明细:", json.dumps(a.get('ba_sha', {}).get('八杀明细', []), ensure_ascii=False))
    print("  真实神煞:", {k: a.get('shen_sha', {}).get(k) for k in REAL_SHEN if a.get('shen_sha', {}).get(k)})
