# -*- coding: utf-8 -*-
"""长征第1期 · sec05 流年(2) + sec06 婚姻(3) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§流年05·120": {
        "leishen": ["鬼：日鬼传归宅上", "火鬼：午(午为仓库火鬼)", "妻：妻扰", "仓库：午"],
        "liqi": ["日鬼传归宅上宅上却又生鬼", "午为仓库火鬼来乘克身", "本身值火星又传从火上起支上与末传寅又生火", "火鬼春归午夏月逐鸡飞三秋寻鼠穴冬至兔相期"],
        "leixiang": ["午=仓库火鬼、寅=生火(末传)、火星"],
        "yingqi": ["正月飞灾二月省墓扰三月妻扰四月官长追五月当直人失六七防火八月闲扰", "九月进横财(财中有失)十月婢妾失十一月仆走十二月媳妇服", "七月仓邻火发烧仓、五月当直人堕坑死、三月妻中风"],
    },
    "§流年05·121": {
        "leishen": ["妻：丧妻又得妻", "财：妻有财", "店：争店事", "尊长：叔"],
        "liqi": ["主丧妻又得妻妻有财", "后争店事起讼有四人遭刑", "又主与尊长争厨屋地基"],
        "leixiang": ["妻=财、店、尊长(叔)"],
        "yingqi": ["当年三月丧妻、十一月再娶(客人之妻)", "次年七月与叔争厨屋地却得理"],
    },
    "§婚姻06·122": {
        "leishen": ["婢：酉(酉乃婢)", "六合：和合", "元武：奸淫之神", "血支：卯(血支在卯)", "宅：卯(卯为宅)"],
        "liqi": ["血支在卯必非女身主暗有退子", "男以克干为嗣女以干生为子一土生二金是退子", "女命上见日干青龙是女先有其夫、男年并日上见天后是男先有其女", "女命乘男男年乘女→婚姻岂有不成", "酉乃婢六合加之为和合又加元武奸淫之神更加酉上→婢子为引", "门来加户户又加门→主门户重叠", "卯为宅上见酉→小门在宅"],
        "leixiang": ["卯=宅(血支)、酉=婢(六合元武奸淫)、青龙=女先有夫、天后=男先有女"],
        "yingqi": ["私情久已通、主暗有退子"],
    },
    "§婚姻06·123": {
        "leishen": ["长生：申(初传申长生)", "学堂：长生为学堂", "子孙：寅(末寅为子孙)", "天后：同天后"],
        "liqi": ["癸日见初传申长生主轻盈金主清白长生为学堂主知书算善治家", "亥乘丁临长生之上又乘常→主服动", "末寅为子孙同天后加木之长生丁亥上→成亲即有子息", "巳与申合寅与亥合→无不成就", "四课三传无空亡→终身享福"],
        "leixiang": ["申=长生(清白学堂)、寅=子孙(天后)、亥=丁(服动)"],
        "yingqi": ["次年生子、五十八又生一子", "娶来未十四个月母亡"],
    },
    "§婚姻06·124": {
        "leishen": ["妻：日上便见妻宫", "子：子作蛇(退子)", "蛇：子作蛇", "勾陈：酉作勾"],
        "liqi": ["日上便见妻宫妻宫上作天罗地网兜牢不欲开去【原文课体·罗网】", "子作蛇名退子纵生子不育", "又主妻宫血风从此成废疾、酉作勾"],
        "leixiang": ["子=蛇(退子不育)、妻宫=天罗地网、酉=勾(血风废疾)"],
        "yingqi": ["成亲后生小口舌", "难得子", "妻宫血风成废疾"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec05 120-121 + sec06 122-124）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
