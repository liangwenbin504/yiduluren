# -*- coding: utf-8 -*-
import json, sys, traceback
sys.path.insert(0, ".")
from engine.liuren_analysis_engine import LiurenAnalysisEngine
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list): sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2: return None
    if c.get("label") not in ("吉","凶","平"): return None
    return {"rizhu":rz,"yue_jiang":c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
            "shichen":c["shichen"] if c.get("shichen") in VALID else "","sanchuan":sc,
            "keti":[],"duanyu":c.get("duanyu",""),"label":c["label"]}

cases = [x for x in (build_clean(c) for c in REAL) if x]
eng = LiurenAnalysisEngine()
YUE_JIANG_ZHI={"寅":"亥","卯":"戌","辰":"酉","巳":"申","午":"未","未":"午","申":"巳","酉":"辰","戌":"卯","亥":"寅","子":"丑","丑":"子"}

fail=0
samples=0
for clean in cases:
    rz=clean["rizhu"]; rg=rz[0]; rzhi=rz[1]
    sc=clean["sanchuan"]
    yj=clean["yue_jiang"]; sc2=clean["shichen"]
    si_ke=[]; tdp={}
    try:
        ss=SiKeSanChuanCalculator2(); cr=ss.calculate(rg,rzhi,yj,sc2)
        si_ke=cr.get("sike",[]); tdp=cr.get("tiandi_pan",{})
    except Exception: pass
    sike_for_analysis=[(sk[2],sk[1]) if len(sk)>=3 else ("","") for sk in si_ke]
    sd={"初传":sc[0],"中传":sc[1],"末传":sc[2]}
    yjz=YUE_JIANG_ZHI.get(yj,"寅")
    try:
        full=eng.analyze(ri_gan=rg,ri_zhi=rzhi,sanchuan=sd,sike=sike_for_analysis,
                         tiandi_pan=tdp or {},yue_jiang=yj,shi_chen=sc2,
                         lunar_month=1,nian_zhi="午",yuejian_zhi=yjz,ri_gan_zhi=rz)
        ba=full.get("八杀分析",{})
        if not ba.get("八杀明细"):
            fail+=1
            if samples<3:
                samples+=1
                print(f"[空八杀] rizhu={rz} sanchuan={sc} sike={si_ke}")
    except Exception as e:
        fail+=1
        if samples<3:
            samples+=1
            print(f"[异常] rizhu={rz} sanchuan={sc}")
            traceback.print_exc()

print(f"\n失败(空或异常): {fail}/{len(cases)}")
