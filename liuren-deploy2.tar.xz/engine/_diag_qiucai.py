# -*- coding: utf-8 -*-
"""求财诊断：对 12 例求财跑 build_result_from_ancient+fuse(text-off)，
逐案打印 真值/预测/财爻(日干所克)现三传·空亡·被冲·墓/青龙财将临三传/官鬼现/关键信号，
定位 吉→凶 错误模式与可翻吉的特征落点。"""
import json
import sys
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import (
    set_enabled, set_text_enabled, set_derive_enabled, set_shen_sha_enabled,
    GAN_WX, ZHI_WX, KE, _ZHI_ORDER, _xunkong, WX_KE,
)
from engine.ancient_backtest import build_result_from_ancient, fuse

set_enabled(True); set_text_enabled(False); set_derive_enabled(True); set_shen_sha_enabled(True)

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

_LIU_CHONG = [{'子', '午'}, {'丑', '未'}, {'寅', '申'}, {'卯', '酉'}, {'辰', '戌'}, {'巳', '亥'}]

def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2:
        return None
    if c.get("label") not in ("吉", "凶", "平"):
        return None
    return {
        "id": c.get("case_id", ""), "name": c.get("name", ""),
        "category": c.get("zhanlei", "其他"), "rizhu": rz,
        "yue_jiang": c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
        "shichen": c["shichen"] if c.get("shichen") in VALID else "",
        "sanchuan": sc, "keti": [], "duanyu": c.get("duanyu", ""),
        "label": c["label"], "label_confidence": c.get("label_conf", 0),
    }

cases = [x for x in (build_clean(c) for c in REAL) if x]
print(f"有效真实案: {len(cases)}")

sub = [x for x in cases if x["category"] == "求财"]
print(f"\n========== 求财 (n={len(sub)}) ==========")
cc = 0
for x in sub:
    result = build_result_from_ancient(x)
    fused = fuse(result)
    truth = x["label"]
    pred = {"看涨": "吉", "看跌": "凶", "平": "平", "震荡": "平"}.get(fused.get("trend", "平"), "平")
    ok = (pred == truth)
    cc += 1 if ok else 0
    a = result.get("analysis", {})
    ba = a.get("_shen_sha_valence", {}).get("ba_sha", {})
    ss = a.get("_shen_sha_valence", {}).get("shen_sha", {})
    qc = a.get("_qiucai_valence", {}) or {}
    keti = a.get("keti_duanyu", {}).get("level", "?")
    bi = result.get("basic_info", {})
    rg = bi.get("ri_gan", "")
    sc = [z for z in x["sanchuan"] if z in ZHI_WX]
    kong = _xunkong(rg, x["rizhu"][1] if len(x["rizhu"]) >= 2 else "")
    rgwx = GAN_WX.get(rg, "")
    cai_wx = KE.get(rgwx, "")          # 财爻 = 日干所克(我克者)
    cai_zhi = [z for z in sc if ZHI_WX.get(z) == cai_wx]   # 财爻支现三传
    # 财爻状态
    cai_kong = any(z in kong for z in cai_zhi)
    cai_chong = False
    for z in cai_zhi:
        for pair in _LIU_CHONG:
            if z in pair and (pair - {z}).pop() in set(sc):
                cai_chong = True
    # 青龙(财将)临三传
    tj = result.get("sanchuan_tianjiang", []) or []
    qinglong = '青龙' in tj
    qinglong_idx = [i for i, t in enumerate(tj) if t == '青龙']
    # 官鬼(克我)现三传
    gg_wx = WX_KE.get(rgwx, "")
    gg = any(ZHI_WX.get(z) == gg_wx for z in sc)
    sigs = " | ".join(fused.get("active_signals", []))
    mark = "✓" if ok else "✗"
    cai_str = f"财爻({cai_wx})={''.join(cai_zhi) if cai_zhi else '—'}"
    cai_state = []
    if cai_zhi:
        if cai_kong: cai_state.append("空亡")
        if cai_chong: cai_state.append("被冲")
    # 青龙所乘之神空亡?（天将空亡：青龙位支落旬空）
    ql_kong = False
    for i in qinglong_idx:
        if i < len(sc) and sc[i] in kong:
            ql_kong = True
    # 财爻入墓（墓支：木墓未/火墓戌/金墓丑/水墓辰/土墓辰）
    MU = {'木': '未', '火': '戌', '金': '丑', '水': '辰', '土': '辰'}
    cai_mu = MU.get(cai_wx, '')
    cai_in_mu = cai_mu in set(sc) and bool(cai_zhi)  # 墓支现三传（财入墓）
    print(f"[{mark}] {x['name'][:8]:<8} 真={truth} 预={pred} {cai_str}{('['+','.join(cai_state)+('入墓' if cai_in_mu else '')+']') if (cai_state or cai_in_mu) else ''} 青龙={qinglong}({qinglong_idx}){'[空]' if ql_kong else ''} 官鬼现={gg} ri_gan={rg} ri_zhi={x['rizhu'][1] if len(x['rizhu'])>=2 else '?'} dzg={x.get('day_ganzhi','')}")
    print(f"      三传={x['sanchuan']} 天将={tj} 旬空={sorted(kong)}")
    print(f"      KETI={keti} 八杀={ba.get('score')} 神煞={ss.get('score')} 求财={qc.get('fired','')}({qc.get('score')})")
    print(f"      信号: {sigs}")
    if not ok:
        print(f"      【原文】{x['duanyu'][:300]}")
print(f"  >>> 求财 准确率 = {cc}/{len(sub)} = {cc/len(sub)*100:.1f}%")
