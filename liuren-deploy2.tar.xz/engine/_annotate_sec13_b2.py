# -*- coding: utf-8 -*-
"""长征第1期 · sec13 疾病 batch2 (171-178) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§疾病13·171": {
        "leishen": ["禄：行年退一步就禄", "风邪：惑风邪", "绝神：宅上见绝神", "太常：燕乐神"],
        "liqi": ["本身虽坚固不合传进迤逦脱气", "子与丑合作常因与人相会饮酒食而喜乐太过遂惑风邪", "行年退一步而就禄壬水又旺玄又同途水既太盛虽生木不为害", "宅上见绝神三传丑寅卯若非行年退却一步定见进脱不可疗", "壬日得丑寅卯迄逦进脱支上又见绝神必不可治", "初传本命来与子合太常为燕乐神过饮遂使风邪入内", "喜时令在秋壬癸水秋生得亥子相并旺相必不至死"],
        "leixiang": ["丑=破碎(太常燕乐)、寅卯=进脱、绝神=宅上"],
        "yingqi": ["今冬得子", "目下主服(初丑破碎作常)"],
    },
    "§疾病13·172": {
        "leishen": ["粽子：戌(己日见戌为同宗)", "面：酉麦申面", "元武：主过水(冷淘)", "太阴：老妇"],
        "liqi": ["己日见戌为同宗日上见午火中之物", "己乃未形似米以米配宗字象粽子加亥水→冷粽", "酉麦申面→面、元武主过水→冷淘", "二物积中遂发热积坚肠塞致令手足拳束"],
        "leixiang": ["戌=粽子(同宗)、亥=水(冷)、酉申=面、元武=过水、太阴=老妇"],
        "yingqi": ["以陈皮青皮乌药汤治下黑粪三五块全愈"],
    },
    "§疾病13·173": {
        "leishen": ["妻：思前妻", "少妇：恋一少妇", "长子：卯(卯为长子作蛇)", "禄：行年在末传带禄"],
        "liqi": ["三交中有空亡六合者皆不正之合", "支干上子丑合而乘太阴又是夜神是淫乱合、却又空亡乃虚想其合而无实效", "四课遥克为传事主在内", "长子非横乃卯为长子作蛇故主非横", "主事初传空亡便不行传、喜得末上行年相接所以用之", "日上丑土得中午生土遂生金丑八故八年"],
        "leixiang": ["卯=长子(蛇非横)、子丑=淫乱合(空亡)、午=鬼(禄居火上)"],
        "yingqi": ["若能如愿尚可活七八年", "丙辰年死"],
    },
    "§疾病13·174": {
        "leishen": ["情人：官作使女", "妻：另娶", "鬼：午未合乃鬼合"],
        "liqi": ["未作后生日支上午与未合乃鬼合便是不正之交传退与妇人相离", "三交交易之象宅上贵人是合入贵人宅去", "末传是子行年上丑子又与丑合更日辰上实合末又见空亡合→思望悬切", "欲合不合传退既值空亡只得在此思想→成痨", "午未合子丑合子午冲丑未冲合处相伤反成不足", "子丑又空是去彼不得见"],
        "leixiang": ["午未=鬼合(不正交)、子丑=空亡合(思望)、贵人=合入宅"],
        "yingqi": ["烧手迹另娶病自愈、否则成痨"],
    },
    "§疾病13·175": {
        "leishen": ["白虎：乘午作鬼", "心：午(午主心心主血)", "天医：午是天医", "阴人：宅中有阴人死得不明"],
        "liqi": ["四课俱下贼绝阴之象", "白虎乘午作鬼→男病主三日内死、无阳气", "午主心心主血→血病", "午是天之真火克日主灸神乘虎→不宜灸、又是天医→不宜服药", "涉害深为用→主久病", "火加水→主寒热往来克日主痨血"],
        "leixiang": ["午=心(白虎鬼天医灸神)、阴人=死得不明作鬼"],
        "yingqi": ["男病主三日内死"],
    },
    "§疾病13·176": {
        "leishen": ["常：巳作常为用", "蛇：中又蛇乘戌加巳", "火：丁日巳用皆火"],
        "liqi": ["巳作常为用主言语", "丁日巳用皆火中又蛇乘戌加巳是火加旺地→主发狂", "火墓戌阴气尽", "阴绝阳弱更主发喘"],
        "leixiang": ["巳=火(常言语)、戌=火墓(蛇)、卯=阴气绝"],
        "yingqi": ["狂言发喘而死"],
    },
    "§疾病13·177": {
        "leishen": ["肺：三传金主肺", "心神：午火盛发心神散乱", "鬼神：未(未主鬼神之状)"],
        "liqi": ["三传金主肺主嗽", "午火又加丙午火盛发心神散乱→主发躁狂言", "申加未未临宅未主鬼神之状", "传归死墓→其人死"],
        "leixiang": ["申酉戌=金(肺嗽)、午=火(心神狂言)、未=鬼神"],
        "yingqi": ["咳嗽狂言见鬼见神而死"],
    },
    "§疾病13·178": {
        "leishen": ["常：辰(辰作常覆日)", "阴阳：纯阴(无阳气)"],
        "liqi": ["昴星课纯阴之象阴掩其阳是无阳气【原文课体·昴星】", "辰作常覆日阴上被丑破末戌加丑", "阴气将尽于戌阳气将尽于辰阴阳气绝绝者促也→病人气促而短", "阳气将尽外应虚热烦躁又主热渴"],
        "leixiang": ["辰=常(覆日)、子丑戌=阴阳绝、纯阴=无阳气"],
        "yingqi": ["先热渴而后喘死"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec13 171-178）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
