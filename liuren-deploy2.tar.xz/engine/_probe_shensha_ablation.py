# -*- coding: utf-8 -*-
"""聚焦消融：仅推导(DERIVE=True,TEXT=False)下，测量 八杀/神煞/德降权 各自的 M3 贡献。
目标：凶重语料下，找出不伤害(且尽量提升) M3 的组合。"""
import json, sys
from collections import Counter
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import (
    set_enabled, set_text_enabled, set_derive_enabled,
    set_shen_sha_enabled, set_ba_sha_enabled,
)
import engine.judgment_fusion as jf
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")


def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list): sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2: return None
    if c.get("label") not in ("吉", "凶", "平"): return None
    return {"rizhu": rz, "yue_jiang": c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
            "shichen": c["shichen"] if c.get("shichen") in VALID else "",
            "sanchuan": sc, "keti": [], "duanyu": c.get("duanyu", ""),
            "category": c.get("zhanlei", "其他"), "label": c["label"]}


cases = [x for x in (build_clean(c) for c in REAL) if x]
set_enabled(True); set_text_enabled(False); set_derive_enabled(True)


def run_m3(ba_on, ss_on, de_mult):
    set_ba_sha_enabled(ba_on); set_shen_sha_enabled(ss_on)
    jf.DE_HALF_MULT = de_mult
    n = cor = 0; cm = Counter()
    for c in cases:
        p = predict_ancient_case(c, "M3").get("prediction", "")
        t = c["label"]
        n += 1; cor += (p == t)
        cm[f"{t}->{p}"] += 1
    return cor / n, dict(cm)


combos = [
    ("八杀关 神煞关 德0.5", False, False, 0.5),
    ("八杀关 神煞关 德0.7", False, False, 0.7),
    ("八杀开 神煞关 德0.5", True, False, 0.5),
    ("八杀开 神煞关 德0.7", True, False, 0.7),
    ("八杀关 神煞开 德0.5", False, True, 0.5),
    ("八杀关 神煞开 德0.7", False, True, 0.7),
    ("八杀开 神煞开 德0.5", True, True, 0.5),
    ("八杀开 神煞开 德0.7", True, True, 0.7),
]
print(f"有效案 {len(cases)}  仅推导 M3 消融：")
for name, ba, ss, dm in combos:
    acc, cm = run_m3(ba, ss, dm)
    print(f"  {name:<22} M3={acc*100:>5.1f}%  {cm}")
