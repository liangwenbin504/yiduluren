# -*- coding: utf-8 -*-
"""40 案三传补全（v2）——以原文三传为权威真值
方法：行首§分块 + v3 正则（六亲+可选遁干+地支+天将，跨行），从原文竖排三传精确提取。
引擎重算仅作 fallback（九宗门争议案如弹射课，引擎会算错，必须原文优先）。
"""
import json, re, sys
sys.path.insert(0, ".")
from engine.daliuren_engine import DaLiuRenEngine

ZHI = "子丑寅卯辰巳午未申酉戌亥"
GAN = "甲乙丙丁戊己庚辛壬癸"
TIANJIANG = "后阴玄常虎空青勾合朱蛇贵"

real = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
text = open("data/断案疏正_全文.txt", encoding="utf-8").read()

# 行首§案例标题分块（排除目录点号行和正文内引用）
titles = [m for m in re.finditer(r'^§([\u4e00-\u9fff、]+?)(\d{1,2})·(\d{1,3})\s*$', text, flags=re.M)]
num2block = {}
for i, m in enumerate(titles):
    end = titles[i + 1].start() if i + 1 < len(titles) else len(text)
    num2block[m.group(3)] = text[m.start():end]


def v3(block):
    seg = re.split(r'邵先生曰|邵彦和曰|邵先先曰', block)[0]
    pat = re.compile(r'([财官父兄子鬼比贼])[\s\S]{0,3}?([子丑寅卯辰巳午未申酉戌亥])([' + TIANJIANG + r'])')
    return [m.group(2) for m in pat.finditer(seg)][:3]


eng = DaLiuRenEngine()

# 40 案（原三传<3）
TARGET = {"§宅墓02·006","§宅墓02·007","§宅墓02·011","§宅墓02·020","§宅墓02·022","§宅墓02·027","§宅墓02·041",
"§前程仕进03·045","§前程仕进03·046","§前程仕进03·047","§前程仕进03·052","§前程仕进03·053","§前程仕进03·058","§前程仕进03·062","§前程仕进03·071","§前程仕进03·076","§前程仕进03·088","§前程仕进03·097","§前程仕进03·103",
"§终身04·108","§终身04·113","§终身04·117","§婚姻06·122","§胎产子息07·128","§胎产子息07·131","§财产08·134","§财产08·137",
"§出行访谒11·152","§行人音信11·156","§行人音信12·158","§行人音信12·159","§疾病13·164","§疾病13·167","§疾病13·175",
"§亡盗15·191","§亡盗15·194","§亡盗15·201","§官讼16·205","§官讼16·211","§杂占17·218"}

report = []
v3_ok = 0
eng_fallback = 0
for c in real:
    if c["case_id"] not in TARGET:
        continue
    cid = c["case_id"]
    num = c.get("num", "")
    gz = c.get("day_ganzhi", "")
    yj = c.get("yue_jiang", "")
    shi = c.get("shichen", "")
    if cid == "§亡盗15·194":
        gz = "庚辰"
    if cid == "§宅墓02·027":
        shi = "戌"

    eng_sc = []
    if len(gz) == 2 and gz[0] in set(GAN) and gz[1] in set(ZHI) and yj in set(ZHI) and shi in set(ZHI):
        tp = eng.arrange_tiandi_pan(yj, shi)
        sk = eng.arrange_si_ke(gz[0], gz[1], tp)
        res = eng.fa_san_chuan(sk, gz[0], tp)
        eng_sc = res.get("三传", []) or []

    yuan_sc = v3(num2block.get(num, ""))

    # 以原文为准
    final = None
    src = ""
    if len(yuan_sc) == 3:
        final = yuan_sc
        src = "原文"
        v3_ok += 1
    elif len(eng_sc) == 3:
        final = eng_sc
        src = "引擎(原文提取失败)"
        eng_fallback += 1

    if final:
        c["sanchuan"] = final
        if cid == "§亡盗15·194":
            c["day_ganzhi"] = "庚辰"
        if cid == "§宅墓02·027":
            c["shichen"] = "戌"

    match = "✓" if (yuan_sc and eng_sc and yuan_sc == eng_sc) else ("⚠️争议" if (yuan_sc and eng_sc) else ("—" if not eng_sc else "原文未提取"))
    report.append((cid, gz, yj, shi, yuan_sc, eng_sc, src, match))

json.dump(real, open("engine/shuzheng_real_cases.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print(f"补全: 原文{v3_ok}案 + 引擎fallback{eng_fallback}案 = {v3_ok+eng_fallback}/40")
print()
print(f"{'case_id':<22}{'干支':<5}{'原文三传':<10}{'引擎三传':<10}{'采用':<14}{'一致'}")
for cid, gz, yj, shi, yuan, eng_sc, src, match in report:
    ys = "".join(yuan) if yuan else "—"
    es = "".join(eng_sc) if eng_sc else "—"
    print(f"{cid:<22}{gz:<5}{ys:<10}{es:<10}{src:<14}{match}")
