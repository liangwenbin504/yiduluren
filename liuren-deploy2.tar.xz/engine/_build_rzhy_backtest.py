# -*- coding: utf-8 -*-
"""壬占汇选 v2 接入评估：三传重提 + 待标注清单导出
- 三传从 case_text 重提（六亲+干支/地支+天将，容忍空格）
- 筛三键齐全(日+月将+时) + 三传完整 + 占问可判 + 断语含结局词
- 导出待标注清单（供逐案核 label，守长征铁律）
"""
import json, re, os

SRC = 'extracted_data/壬占汇选_训练数据_v2.json'
OUT_LIST = 'extracted_data/_guji_fetch/壬占汇选_待标注清单.txt'
OUT_CAND = 'extracted_data/_guji_fetch/壬占汇选_候选.json'

with open(SRC, encoding='utf-8') as f:
    cases = json.load(f)

ZHI = set('子丑寅卯辰巳午未申酉戌亥')
def clean_yj(x):
    x = (x or '').replace('将', '').strip()
    return x if x in ZHI else ''
def clean_shi(x):
    x = (x or '').replace('时', '').strip()
    if len(x) >= 2 and x[-1] in ZHI:
        return x[-1]
    return x if x in ZHI else ''

# 三传重提：六亲 + [干]支 + 天将
PAT = re.compile(r'[财官父兄子][ 　]*[甲乙丙丁戊己庚辛壬癸]?([子丑寅卯辰巳午未申酉戌亥])[ 　]*[贵蛇朱六勾青龙空虎常玄阴后]')
def re_extract(t):
    return re.findall(PAT, t)

NO_JB = ['来意', '射覆', '风角', '杂占', '占梦', '天气', '晴', '雨']
OUT_WORD = re.compile(r'(果|果然|后果|应验|遂|竟|卒|殒|死|痊愈|病愈|升迁|升官|降|被参|参劾|中试|中式|得财|失财|破财|生子|得子|不孕|有孕|难产|吉|凶|无事|无妨)')

cands = []
for idx, c in enumerate(cases):
    rz = (c.get('ganzhi') or '').strip()
    yj = clean_yj(c.get('yuejiang'))
    shi = clean_shi(c.get('shichen'))
    if len(rz) != 2 or not yj or not shi:
        continue
    # 排除现代验证案例（outcome 字段是现代的）
    if c.get('outcome'):
        continue
    sc = re_extract(c.get('case_text', ''))
    if len(sc) < 3:
        continue
    q = c.get('question') or ''
    if not q or any(k in q for k in NO_JB):
        continue
    body = c.get('case_text', '')
    if not OUT_WORD.search(body):
        continue
    cands.append({
        'idx': idx,
        'ganzhi': rz, 'yuejiang': yj, 'shichen': shi,
        'sanchuan': sc[:3], 'source': c.get('source', ''),
        'question': q, 'case_text': body,
    })

print(f'候选: {len(cands)} 案')
# 按 source 分布
from collections import Counter
src_cnt = Counter(c['source'] for c in cands)
print('按 source:', dict(src_cnt))

# 导出待标注清单
with open(OUT_LIST, 'w', encoding='utf-8') as f:
    for i, c in enumerate(cands, 1):
        f.write(f"===== {i}/{len(cands)} [{c['ganzhi']} {c['yuejiang']}将 {c['shichen']}时] 三传={''.join(c['sanchuan'])} 占={c['question']} 源={c['source']} =====\n")
        # 断语取"曰/断曰"之后
        body = c['case_text']
        m = re.search(r'(?:曰|断曰|占曰)[：:，,]?\s*([\s\S]*)$', body)
        duan = m.group(1).strip() if m else body
        f.write(f"断语: {duan[:400]}\n\n")

json.dump(cands, open(OUT_CAND, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'已导出 {OUT_LIST} 和 {OUT_CAND}')
