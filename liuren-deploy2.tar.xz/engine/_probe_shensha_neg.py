# -*- coding: utf-8 -*-
"""验证：八杀ON + 神煞(仅负向:劫煞/灾煞/天罗/地网/桃花) + 德0.7 是否 >= 78.7%。"""
import json, sys
from collections import Counter
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import (
    set_enabled, set_text_enabled, set_derive_enabled,
    set_shen_sha_enabled, set_ba_sha_enabled, SHEN_SHA_GLOBAL,
)
import engine.judgment_fusion as jf
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list): sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2: return None
    if c.get("label") not in ("吉","凶","平"): return None
    return {"rizhu":rz,"yue_jiang":c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
            "shichen":c["shichen"] if c.get("shichen") in VALID else "",
            "sanchuan":sc,"keti":[],"duanyu":c.get("duanyu",""),
            "category":c.get("zhanlei","其他"),"label":c["label"]}

cases = [x for x in (build_clean(c) for c in REAL) if x]
set_enabled(True); set_text_enabled(False); set_derive_enabled(True); set_ba_sha_enabled(True)
jf.DE_HALF_MULT = 0.7

def run_m3(ss_global):
    import engine.liuren_keti_bifa as kb
    kb.SHEN_SHA_GLOBAL = ss_global
    set_shen_sha_enabled(bool(ss_global))
    n=cor=0; cm=Counter()
    for c in cases:
        p = predict_ancient_case(c, "M3").get("prediction", "")
        n+=1; cor+=(p==c["label"]); cm[f"{c['label']}->{p}"]+=1
    return cor/n, dict(cm)

print(f"有效案 {len(cases)}")
acc, cm = run_m3({})  # 神煞关
print(f"  八杀ON 神煞关 德0.7        M3={acc*100:.1f}%  {cm}")
acc, cm = run_m3({"桃花":-1,"劫煞":-1,"灾煞":-1,"天罗":-1,"地网":-1})  # 神煞负向only
print(f"  八杀ON 神煞(负向only) 德0.7 M3={acc*100:.1f}%  {cm}")
acc, cm = run_m3(dict(SHEN_SHA_GLOBAL))  # 神煞全开(对照)
print(f"  八杀ON 神煞全开 德0.7      M3={acc*100:.1f}%  {cm}")
