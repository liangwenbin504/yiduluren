# -*- coding: utf-8 -*-
"""
十三吉课精细判定（依据《大六壬 64 课经》完整定义，见 engine/daliuren_64ke_rules.py）。
2026-08-17 憨爷要求精细版：不得用"简化判断"，逐课按 64 课经 definition 落码。

十三吉课（憨爷清单 12 个 + 华盖即轩盖课）：
  龙德、官爵、元首、富贵、和美、亨通、华盖(轩盖)、斫轮、德庆、时泰、铸印、荣华、引从
  引从课：日辰干支前后上神发用为初末传（2026-08-17 憨爷明确为第 13 吉课）。

各课 definition（daliuren_64ke_rules.py 逐字）：
  龙德课：太岁月将乘贵人发用
  官爵课：岁、月、年、命 驿马发用，又天魁、太常人传
  元首课：一上克下，余课无克（九宗门课体）
  富贵课：天乙乘旺相气，上下相生，更临日、辰、年、命发用
  和美课：干支遇三合六合，上下递互相合
  亨通课：用神生日，及三传递生日干，或干支俱互生旺
  华盖(轩盖)课：值胜光(午)为用，遇太冲(卯)、神后(子)
  斫轮课：卯加庚或加辛为用
  德庆课：日辰于支德神，及天月二德发用，并在年命乘吉将
  时泰课：用起太岁、月建，乘青龙、六合，又带财德之神
  铸印课：得戌加巳中传
  荣华课：禄马贵人临干支年命，并旺相气发用人传，更乘吉将
"""
from typing import Dict, List, Tuple

JIKE_13 = ['龙德', '官爵', '元首', '富贵', '和美', '亨通', '华盖', '斫轮', '德庆', '时泰', '铸印', '荣华', '引从']

# 日德（标准日德表：阳干取禄前、阴干取合）
_RI_DE = {'甲': '寅', '乙': '申', '丙': '巳', '丁': '亥', '戊': '巳',
          '己': '寅', '庚': '申', '辛': '巳', '壬': '亥', '癸': '寅'}
# 支德（日支→支德神）
_ZHI_DE = {'子': '巳', '丑': '午', '寅': '未', '卯': '申', '辰': '酉', '巳': '戌',
           '午': '亥', '未': '子', '申': '丑', '酉': '寅', '戌': '卯', '亥': '辰'}
# 天德贵人（按月支→支：干值取寄宫、卦值取方位，《协纪辨方书》口诀：
# 正丁二坤(申)三壬四辛五乾(亥)六甲七癸八艮(寅)九丙十乙十一巽(巳)十二庚）
_TIAN_DE = {'寅': '未', '卯': '申', '辰': '亥', '巳': '戌', '午': '亥', '未': '寅',
            '申': '丑', '酉': '寅', '戌': '巳', '亥': '辰', '子': '巳', '丑': '申'}
# 月德贵人（按月支三合局旺气阳干寄宫：寅午戌→丙(巳)、申子辰→壬(亥)、亥卯未→甲(寅)、巳酉丑→庚(申)）
_YUE_DE = {'寅': '巳', '午': '巳', '戌': '巳', '申': '亥', '子': '亥', '辰': '亥',
           '亥': '寅', '卯': '寅', '未': '寅', '巳': '申', '酉': '申', '丑': '申'}
# 十干阴阳贵（阳贵=昼贵，阴贵=夜贵）
_GUI_YANG = {'甲': '未', '乙': '申', '丙': '酉', '丁': '亥', '戊': '未',
             '己': '申', '庚': '未', '辛': '午', '壬': '巳', '癸': '卯'}
_GUI_YIN = {'甲': '丑', '乙': '子', '丙': '亥', '丁': '酉', '戊': '丑',
            '己': '子', '庚': '丑', '辛': '寅', '壬': '卯', '癸': '巳'}
# 地支五行
_ZHI_WX = {'子': '水', '丑': '土', '寅': '木', '卯': '木', '辰': '土', '巳': '火',
           '午': '火', '未': '土', '申': '金', '酉': '金', '戌': '土', '亥': '水'}
# 天干五行
_GAN_WX = {'甲': '木', '乙': '木', '丙': '火', '丁': '火', '戊': '土',
           '己': '土', '庚': '金', '辛': '金', '壬': '水', '癸': '水'}
# 五行相生（我生）：生我者 = SHENG_WO
_WX_SHENG = {'木': '火', '火': '土', '土': '金', '金': '水', '水': '木'}
_WX_SHENG_WO = {'木': '水', '火': '木', '土': '火', '金': '土', '水': '金'}  # 生我
# 六合 / 三合
_LIU_HE = {'子': '丑', '丑': '子', '寅': '亥', '亥': '寅', '卯': '戌', '戌': '卯',
           '辰': '酉', '酉': '辰', '巳': '申', '申': '巳', '午': '未', '未': '午'}
_SAN_HE_GROUPS = (('申', '子', '辰'), ('寅', '午', '戌'), ('巳', '酉', '丑'), ('亥', '卯', '未'))


def _is_liu_he(a, b):
    return _LIU_HE.get(a) == b


def _is_san_he(a, b):
    return a != b and any(a in g and b in g for g in _SAN_HE_GROUPS)


def _ma_of(zhi: str) -> str:
    """三合局驿马（申子辰马寅、寅午戌马申、巳酉丑马亥、亥卯未马巳）。"""
    ma = {'申': '寅', '子': '寅', '辰': '寅', '寅': '申', '午': '申', '戌': '申',
          '巳': '亥', '酉': '亥', '丑': '亥', '亥': '巳', '卯': '巳', '未': '巳'}
    return ma.get(zhi, '')


def check_jike_13(keti: str = '', sike: list = None, sanchuan_dizhi: List[str] = None,
                  tianjiang_list: List[str] = None, ri_gan: str = '', ri_zhi: str = '',
                  nian_zhi: str = '', yue_zhi: str = '', lu_zhi: str = '', ma_zhi: str = '',
                  longde_matched: bool = False, ben_ming_zhi: str = '') -> Dict:
    """十三吉课精细判定。返回 {hits, is_jike, details: [(课名, 依据)]}。
    sike: 四课 [[课名,上神,下神,天将],...]；sanchuan_dizhi: [初,中,末]；tianjiang_list: 三传天将。"""
    sc = [z for z in (sanchuan_dizhi or []) if z]
    tj = [t for t in (tianjiang_list or []) if t]
    hits: List[str] = []
    details: List[str] = []

    def _hit(name, why):
        hits.append(name)
        details.append(why)

    # 四课干上/支上
    gan_shang = zhi_shang = ''
    if sike and isinstance(sike, (list, tuple)):
        for sk in sike:
            if isinstance(sk, (list, tuple)) and len(sk) >= 2:
                if sk[0] == '第一课':
                    gan_shang = sk[1]
                elif sk[0] == '第三课':
                    zhi_shang = sk[1]
    if len(sc) < 3:
        return {'hits': [], 'is_jike': False, 'details': []}

    chu, zhong, mo = sc[0], sc[1], sc[2]

    # 1. 元首课（九宗门课体：一上克下余课无克）
    if keti and '元首' in keti:
        _hit('元首', f'课体{keti}（一上克下余课无克）')

    # 2. 龙德课：太岁月将乘贵人发用
    if longde_matched:
        _hit('龙德', '太岁=月将乘贵人发用')

    # 3. 官爵课：岁/月/年/命驿马发用 + 天魁(戌)太常人传
    mas = [z for z in [_ma_of(nian_zhi), _ma_of(yue_zhi), _ma_of(ri_zhi), _ma_of(ben_ming_zhi)] if z]
    if mas and chu in mas and '戌' in sc and '太常' in tj:
        _hit('官爵', f'驿马{chu}发用，天魁戌在传，太常在传')

    # 4. 富贵课：天乙乘旺相临日辰年命发用
    gui_zy = {_GUI_YANG.get(ri_gan, ''), _GUI_YIN.get(ri_gan, '')}
    if (gan_shang in gui_zy or zhi_shang in gui_zy) and '贵人' in tj:
        _hit('富贵', f'天乙(贵人)临日辰({gan_shang or zhi_shang})且乘贵人发用')

    # 5. 和美课：干支遇三合六合，上下递互相合
    if gan_shang and zhi_shang and (_is_liu_he(gan_shang, zhi_shang) or _is_san_he(gan_shang, zhi_shang)):
        _hit('和美', f'干上{gan_shang}与支上{zhi_shang}六合/三合')

    # 6. 亨通课：用神生日，及三传递生日干
    gwx = _GAN_WX.get(ri_gan, '')
    chu_wx = _ZHI_WX.get(chu, '')
    sheng_ri = False
    if gwx and chu_wx and _WX_SHENG.get(chu_wx) == gwx:
        sheng_ri = True  # 初传生日干（初传生我）
    # 三传递生：初生中、中生末
    di_sheng = (_WX_SHENG.get(_ZHI_WX.get(chu, '')) == _ZHI_WX.get(zhong, '') and
                _WX_SHENG.get(_ZHI_WX.get(zhong, '')) == _ZHI_WX.get(mo, ''))
    if sheng_ri or di_sheng:
        _hit('亨通', '用神生日干/三传递相生')

    # 7. 华盖(轩盖)课：胜光午为用，遇太冲卯神后子
    if set(sc) == {'午', '卯', '子'}:
        _hit('华盖', '三传午卯子（胜光为用遇太冲神后）')

    # 8. 斫轮课：卯加庚或加辛为用
    if chu == '卯' and ri_gan in ('庚', '辛'):
        _hit('斫轮', f'卯加{ri_gan}为用')

    # 9. 德庆课：日辰支德神 + 天月二德发用
    de_zhi = {_RI_DE.get(ri_gan, ''), _ZHI_DE.get(ri_zhi, '')}
    if yue_zhi:
        de_zhi |= {_TIAN_DE.get(yue_zhi, ''), _YUE_DE.get(yue_zhi, '')}
    if chu in de_zhi:
        _hit('德庆', f'德神{chu}发用（干德/支德/天月二德）')

    # 10. 时泰课：用起太岁、月建，乘青龙六合，带财德之神
    if (chu == nian_zhi or chu == yue_zhi) and ('青龙' in tj or '六合' in tj):
        _hit('时泰', f'太岁/月建{chu}发用，乘青龙/六合')

    # 11. 铸印课：得戌加巳中传（三传巳戌卯）
    if chu == '巳' and zhong == '戌' and mo == '卯':
        _hit('铸印', '巳戌卯（戌加巳中传铸印）')

    # 12. 荣华课：禄马贵临干支，旺相发传乘吉将
    lmg = [z for z in (lu_zhi, ma_zhi, _GUI_YANG.get(ri_gan, ''), _GUI_YIN.get(ri_gan, '')) if z]
    lmg_lin = any(x in (gan_shang, zhi_shang) for x in lmg)
    jj = ('青龙', '六合', '太常', '贵人')
    if lmg_lin and chu in lmg and any(j in tj for j in jj):
        _hit('荣华', f'禄马贵{chu}临干支且发传乘吉将')

    # 13. 引从课：日辰干支前后上神发用为初末传。
    # 近似实现：干上神为初传（从干引）、支上神为末传（从支从）。
    # 原文"干前支后"精确地盘前后位判定待《通解》原文核对（与 liuren_64ke_judge.judge_yin_cong 同步近似）。
    if gan_shang and zhi_shang and chu == gan_shang and mo == zhi_shang:
        _hit('引从', f'干上{gan_shang}为初、支上{zhi_shang}为末，引从日辰（近似：缺地盘前后精确判定）')

    return {'hits': hits, 'is_jike': bool(hits), 'details': details}


if __name__ == '__main__':
    # 自测：元首课 + 三传午卯子(华盖) + 龙德
    print(check_jike_13(keti='元首课',
                        sike=[['第一课', '午', '甲', '贵人'], ['第二课', '未', '午', '太常'],
                              ['第三课', '卯', '子', '青龙'], ['第四课', '辰', '卯', '六合']],
                        sanchuan_dizhi=['午', '卯', '子'], tianjiang_list=['青龙', '六合', '贵人'],
                        ri_gan='甲', ri_zhi='子', nian_zhi='寅', yue_zhi='辰',
                        lu_zhi='寅', ma_zhi='寅', longde_matched=True, ben_ming_zhi='寅'))
    # 自测：铸印课（巳戌卯）
    print(check_jike_13(keti='重审课', sanchuan_dizhi=['巳', '戌', '卯'], tianjiang_list=['太常', '六合', '青龙'],
                        ri_gan='辛', ri_zhi='丑'))
    # 自测：斫轮课（卯加庚）
    print(check_jike_13(keti='重审课', sanchuan_dizhi=['卯', '戌', '巳'], tianjiang_list=['太常', '六合', '青龙'],
                        ri_gan='庚', ri_zhi='子'))
