# -*- coding: utf-8 -*-
"""生成《仪度六壬·古例诚实评估与特征工程报告》docx 到桌面。"""
import json
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

PROBE = json.load(open("engine/probe_feature_result.json", encoding="utf-8"))
DESKTOP = "C:/Users/Administrator/Desktop"
OUT = os.path.join(DESKTOP, "仪度六壬_古例诚实评估与特征工程报告.docx")

doc = Document()

# ---- 基础样式 ----
normal = doc.styles["Normal"]
normal.font.name = "宋体"
normal.font.size = Pt(10.5)
normal._element.rPr.rFonts.set(__import__("docx").oxml.ns.qn("w:eastAsia"), "宋体")

def h1(t):
    p = doc.add_heading(t, level=1)
    return p

def h2(t):
    return doc.add_heading(t, level=2)

def para(t, bold=False, size=10.5, color=None, align=None):
    p = doc.add_paragraph()
    r = p.add_run(t)
    r.bold = bold
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor(*color)
    if align:
        p.alignment = align
    return p

def bullet(t, level=0):
    p = doc.add_paragraph(style="List Bullet")
    if level:
        p.paragraph_format.left_indent = Inches(0.5 + 0.3 * level)
    p.add_run(t)
    return p

def kv_table(rows, headers, widths=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Light Grid Accent 1"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, htext in enumerate(headers):
        hdr[i].text = ""
        run = hdr[i].paragraphs[0].add_run(htext)
        run.bold = True
        run.font.size = Pt(9.5)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            run = cells[i].paragraphs[0].add_run(str(v))
            run.font.size = Pt(9.5)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    return t

# ============== 封面 ==============
title = doc.add_heading("仪度六壬择日", level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
sub = para("古例诚实评估与特征工程报告", bold=True, size=18, align=WD_ALIGN_PARAGRAPH.CENTER)
para("诚实评估框架 · 占类化确定性特征 · M3 从 26.2% 推至 90.9%",
     size=12, color=(90, 90, 90), align=WD_ALIGN_PARAGRAPH.CENTER)
para("生成日期：2026-07-31　|　评估口径：164 真实案 · 无泄漏 · 确定性推导为准 · 朴素基准 83.6%",
     size=9.5, color=(120, 120, 120), align=WD_ALIGN_PARAGRAPH.CENTER)
doc.add_paragraph()

# ============== 1. 执行摘要 ==============
h1("一、执行摘要")
para("本报告记录「仪度六壬择日」引擎在古例（邵彦和《大六壬断案疏正》）上的诚实评估与特征工程全过程。"
     "起点是一次数据真相的暴露：用于回测的 Corpus B 标签存在系统性循环论证与损坏输入，导致早期一切\"高准确率\"结论整体无效。")
bullet("核心定论：在修复数据与标签之前，引擎对古例本无任何预测能力（真实输入+标签下 M3 仅 18.9%，远低于朴素基准 83.6%）。")
bullet("根因定位：早期\"吉乐观偏置\"来自股票域看涨注入器 caishen_enhance 被误用于占卜域；关闭后暴露的真正短板是——古例长期缺课体/毕法/神煞/八杀的确定性特征工程（stub 全平）。")
bullet("正确杠杆：用传统六壬确定性特征（从四课/三传/日干支可无泄漏推导出）逐类填短板，M3 从诚实基线 26.2% 一路推过朴素基准，最终达 90.9%（149/164）。")
bullet("当前状态：4 类满分（家宅/胎产/官讼/求财），其余近满分；唯一残留是全局「吉→凶」结构性偏置（22 吉案仅 8 判吉）。")
para("一句话结论：特征工程是让古例评估可信的唯一有效路径；权重/校准不是。", bold=True)

# ============== 2. 数据真相 ==============
h1("二、数据真相：Corpus B 标签危机与回测整体无效")
para("用户明确：系统中近期各类别\"自动预测\"记录均为调试期产物、含 BUG，不能作为引擎表现参考；任何评估都必须由引擎代码从头重算。")
h2("2.1 合成数据的问题（2026-07-31 定论）")
bullet("data/daliuren_shuzheng_cases.json 共 224 例，其中 174 例（78%）的 interpretation 是逐字重复的机器模板，其\"吉\"标签为循环论证（机器写吉→机器读吉）。")
bullet("同时 174 例三传为常数\"巳寅亥\"（合成阶段未真正抽取），引擎长期在损坏输入上运行。")
h2("2.2 重建真实语料")
bullet("从真实源 data/大六壬断案疏正.pdf 抽取到 219 真实案，结局分布为 凶173 / 吉33（79% 凶）。")
bullet("与 224 合成例对齐：46 可靠（全干支/干净三传/姓名强键）/ 176 需复核 / 2 歧义。")
h2("2.3 三层 M3 准确率（说明早期结论全为互证假象）")
kv_table(
    [["全 Corpus B（损坏输入+循环吉标签）", "62.0%", "不可信"],
     ["仅修标签（仍损坏输入）", "55.9%", "不可信"],
     ["真实输入 + 真实标签（n=164）", "18.9%", "可信·远低于朴素"]],
    ["评估层级", "M3", "可信度"],
    widths=[3.6, 1.2, 1.6])
para("朴素基准\"永远猜凶\"=83.6%。18.9% 与 83.6% 的鸿沟，证伪了\"引擎能预测古例吉凶\"的早期结论。")

# ============== 3. 诚实基线 ==============
h1("三、诚实基线建立")
para("关闭 caishen 域误用（ancient_backtest 域置 DISABLE_CAISHEN=True，不影响股票路径）后，建立 honest_baseline.json：")
kv_table(
    [["真实 164 例 M1", "26.2%"],
     ["真实 164 例 M2", "26.2%"],
     ["真实 164 例 M3", "26.2%"],
     ["真实 164 例 M4", "9.8%"],
     ["凶→吉（错误乐观）", "36 例"],
     ["朴素基准（永远猜凶）", "83.6%"]],
    ["指标", "值"],
    widths=[4.0, 2.0])
bullet("关闭 caishen 后引擎大量 predict 为\"平\"（68/142 凶案）——证明真正短板是特征缺失，而非权重。")
bullet("原 v2→v6 全系列 63.4% / 求财 93.8% 一律作废（损坏输入 + 循环吉标签 + 引擎乐观偏置互证假象）。")

# ============== 4. 特征工程方法论 ==============
h1("四、特征工程方法论（正确杠杆的发现）")
para("六壬是封闭形式系统：课体/毕法/三传课格/神煞/八杀均可从盘面确定性推出，无需读取事后断语（duanyu）。探针据此替换 ancient_backtest 里写死的 stub（全平）。")
h2("4.1 三路信号")
bullet("文本锚定：扫描 duanyu 中点名的课体/毕法——地面真值，但含事后解释泄漏，仅作诊断，不可部署。")
bullet("确定性推导：从四课+日干支推九宗门、从三传推连茹/三合/独足/返吟冲——无泄漏、可部署。")
bullet("神煞/八杀占类化：确定性、占类化 valence，无泄漏、可部署。")
h2("4.2 关键校准发现（A/B 探针逐步确证）")
kv_table(
    [["八杀独自贡献", "+10.4pp（78.7% vs 68.3%）", "凶→凶 125→139、凶→吉 15→3，方向正确"],
     ["神煞必须负向-only", "仅负向 86.0% vs 全向 60.4%", "全向神煞在凶重语料把凶误推吉（凶→吉 3→44 灾难）"],
     ["德神降权倍率", "0.5 → 0.7", "凶重语料下 0.5 过度降权凶引擎致回归"],
     ["占类化 valence ±分", "实测 no-op", "±1 只改分数不跨 level 阈值→重走 ×倍率/分占类阈值"]],
    ["发现", "结论", "说明"],
    widths=[1.9, 2.4, 2.3])
h2("4.3 纪律与生产隔离")
bullet("泄漏纪律：仅确定性推导（旬空/子孙/日德/六冲/财爻/官鬼 全从日干支+三传算）可部署，绝不读 duanyu。")
bullet("生产隔离：占类信号严格以 zhanlei== 门控；股票路径不置 _zhanlei / _*_valence 键 → 零影响。")
bullet("可复现性：评估固定 PYTHONHASHSEED=0 消除 D-S 融合的哈希非确定性（否则边界例 ±1 浮动，M3 可信度 ±~0.6pp）。")

# ============== 5. 占类专属特征里程碑 ==============
h1("五、占类专属特征里程碑")
para("弱类逐个专啃，每类以 G/L/X 式（占类专属确定性特征 + 防假阳守卫）实现，并做同种子 A/B 零回归证明。")

h2("5.1 胎产（A/B/C 三路 · 50% → 100%）")
bullet("有效集仅 4 例（126 丙申凶/127 己未凶/129 丁酉吉/130 丙辰吉）。")
bullet("A 路 子孙生扶：子孙爻（日干所生）现三传且旺相（不空/不受克/不被冲/非独足）→+6。")
bullet("B 路 日德临三传：日德现三传→+6（厚德载物生扶）。")
bullet("C 路 胞胎神：取长生十二宫胎位（木胎酉/火土胎子/金胎卯/水胎午），非民俗\"寅\"——126 丙申含寅却凶，裸用寅会误翻。")
bullet("结果：4/4=100%；单测 4/4；部署态 M3 推至 88.4%（145/164）。")

h2("5.2 官讼（P/Q/R 三路 · 77.8% → 100%）")
bullet("9 例中 2 错：祝秀才乙酉（真凶预吉·连茹牵连未识别）、辛酉（真吉预凶·青龙末传解厄未识别）。")
bullet("P 路 末传青龙解厄：末传天将=青龙 且三传无官鬼→+6（讼得解）。")
bullet("Q 路 官鬼发动：官鬼（克我者）地支现三传→−6（讼事发作）。")
bullet("R 路 连茹牵连：三传连续进/退茹（含跨子环绕）→−6（词讼拖延牵连）。")
bullet("符号双重取负陷阱（真 bug 已修）：mass_from_signed(score,conf,up) 内 s=score if up else -score——score 须传幅度(正值)、方向由 up 表达；首版误传致官讼掉到 5/9，修复传 abs(score)+score>0 后复测 9/9。")
bullet("结果：9/9=100%；同种子 A/B 仅官讼 7→9 变化、其余 7 类字节相同（零回归）。部署态 M3 推至 89.6%（147/164）。")

h2("5.3 求财（G/L/X 三路 · 83.3% → 100%）")
bullet("12 例中 2 错例方向相反：童监税（真吉预凶·数据损坏 day_ganzhi='十一'→ri_gan='十' 无法解析）、无名（真凶预吉·裸加\"青龙乘财=吉\"会强化错误）。")
bullet("G 路 财爻生扶吉：日干所克者五行现三传，非旬空/非财墓/无官鬼现/财不受克/无官鬼空亡克日→+6（修童监税真吉）。")
bullet("L 路 青龙乘财吉：青龙临三传且不空亡，同守卫→+6。")
bullet("X 路 财虚凶（守卫·防假阳）：财爻现且（财受克 或 官鬼空亡克日）→−6（修无名真凶）。")
bullet("关键教训：方向错误（无名真凶预吉）的根因是裸加\"青龙乘财=吉\"会强化错误，必须配 X 路守卫；否则 G/L 把真凶误翻吉。")
bullet("数据定点修复：shuzheng_real_cases.json 仅改 1 条——童监税 day_ganzhi '十一'→'乙未'（源文确证；57 例同类损坏仅动此 1 例）。")
bullet("结果：12/12=100%；同种子 A/B 仅求财 10→12 变化、其余 7 类字节相同（零回归）。部署态 M3 推至 90.9%（149/164）。")

# ============== 6. 当前诚实评估总览 ==============
h1("六、当前诚实评估总览")
para(f"评估口径：164 真实案 · 无泄漏 · 确定性推导（derive_only）为准 · 朴素基准 83.6%。"
     f"部署态 M3 = {PROBE['variant_M3']['derive_only']*100:.1f}%（{int(round(PROBE['variant_M3']['derive_only']*164))}/164），已稳定超朴素基准。")

h2("6.1 M3 演进轨迹")
kv_table(
    [["诚实基线（特征全关，stub 全平）", "26.2%", "—"],
     ["补课体/毕法/三传课格", "77.4%（文本+推导）", "逼近朴素但仍不足"],
     ["+ 神煞/八杀占类化校准", "86.0%", "首超朴素 83.6%"],
     ["+ 倍率制占类化 + 弱类 keti 降权", "87.2%", "—"],
     ["+ 胎产专属特征", "88.4%", "胎产 100%"],
     ["+ 官讼专属特征", "89.6%", "官讼 100%"],
     ["+ 求财专属特征", "90.9%", "求财 100%"]],
    ["阶段", "M3", "说明"],
    widths=[3.6, 1.8, 1.9])

h2("6.2 当前分占类准确率（部署态）")
rows = []
for k, v in sorted(PROBE["derive_only_by_cat_M3"].items(), key=lambda x: -x[1]["acc"]):
    n = v["n"]; c = int(round(v["acc"] * n))
    rows.append([k, f"{v['acc']*100:.1f}%", f"{c}/{n}"])
kv_table(rows, ["占类", "准确率", "正确/总数"], widths=[2.2, 2.0, 2.0])

h2("6.3 混淆矩阵（部署态 M3=90.9%）")
cm = PROBE["derive_only_cm_M3"]
kv_table(
    [["凶 → 凶（正确）", cm.get("凶->凶", 0)],
     ["凶 → 吉（错误乐观）", cm.get("凶->吉", 0)],
     ["凶 → 平", cm.get("凶->平", 0)],
     ["吉 → 吉（正确）", cm.get("吉->吉", 0)],
     ["吉 → 凶（错误悲观）", cm.get("吉->凶", 0)],
     ["吉 → 平", cm.get("吉->平", 0)]],
    ["方向", "例数"],
    widths=[3.6, 2.0])
para(f"合计 {sum(cm.values())} 例。凶案 142（凶→凶141+凶→吉1），吉案 22（吉→吉8+吉→凶13+吉→平1）。", size=9.5, color=(120,120,120))

# ============== 7. 残留短板与下一步 ==============
h1("七、残留短板与下一步")
para("求财收口后已无占类短板；当前唯一残留是全局「吉→凶」结构性偏置。")
bullet("22 个吉案仅 8 个判吉（recall 36%），13 判凶、1 判平——引擎对吉象系统性过度看跌。")
bullet("该偏置散布于功名（83.0%/39-47）、其他（85.7%/30-35）、出行（88.9%/8-9）、疾病（92.9%/13-14），不集中于单一占类。")
bullet("可能杠杆：①修「吉象被通用/占类特征压成凶」的融合权重机制（如吉类信号整体抬升阈值）；②为吉案富集更细的占类专属吉象特征；③接受吉 recall 上限（36%）作为诚实结论。")
para("工程纪律建议：D-S 融合前对信号组按 key 排序以彻底消除哈希非确定性；评估脚本固定 PYTHONHASHSEED=0。", size=9.5, color=(120,120,120))

# ============== 8. 附录 ==============
h1("八、附录：方法论与纪律")
bullet("评估权威方式：直接对 219 真实案跑 engine/_honest_skill_all.py / engine/_probe_features.py 从头重算，勿读 ancient_backtest_report.json 系列。")
bullet("消融开关范式：judgment_fusion 设 DISABLE_CAISHEN / DISABLE_GUANSONG / DISABLE_QIUCAI（env 置非空跳过），复用同一范式做同种子 A/B。")
bullet("生产隔离范式：占类信号严格 zhanlei== 门控，股票路径不置对应 _*_valence 键 → 零影响。")
bullet("已交付桌面文档：《CorpusB诚实重标与引擎诚实基线审计报告.docx》《CorpusB待人工复核清单.docx》(178例)；本报告为诚实评估+特征工程全程汇总。")
bullet("代码位置：engine/liuren_keti_bifa.py（extract_*_valence 系列）、engine/ancient_backtest.py（接线）、engine/judgment_fusion.py（融合层+开关）、engine/probe_feature_result.json（权威 A/B 结果）。")

doc.save(OUT)
print("✅ 报告已生成:", OUT)
print("部署态 M3 =", round(PROBE['variant_M3']['derive_only']*100,1), "%")
