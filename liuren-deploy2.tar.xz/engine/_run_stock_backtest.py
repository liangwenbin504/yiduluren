# -*- coding: utf-8 -*-
"""股票域自有特征库 · 诚实回测驱动（修正版）
================================================
对两个变体跑 regime_backtest（独立市场标签 = 收盘>开盘），对比朴素基线
（永远猜涨 = 1 - base_down_rate = 55.3%）：
  A'  clean    : caishen OFF, stock_valence OFF  （无财域注入的原始管线）
  B'  stockval : caishen OFF, stock_valence ON   （干净六壬结构检验）

修正点（相对初版）：
  - run_engine 只写 RAW_CACHE、不写报告；本驱动在 run_engine 之后显式调用
    rb.main()（读缓存、写报告到重定向的 rb.REPORT）。
  - 启用 rb._CAPTURE_STOCK，在 RAW_CACHE 中额外记录每日 stock valence
    理论触发值，供覆盖率统计（不影响生产路径）。

纪律：
  - force=True 重算全部 5239 日，杜绝 RAW_CACHE 旧预测污染 A/B。
  - 重定向 rb.REPORT，不动原始 regime_backtest_report.json。
  - 备份/还原原始 RAW_CACHE，不静默改写生产参考缓存。
"""
import os, sys, json, time, shutil
sys.path.insert(0, ".")
import regime_backtest as rb
import engine.judgment_fusion as jf

RAW = rb.RAW_CACHE
RAW_BAK = RAW + ".prod.bak"
if os.path.exists(RAW) and not os.path.exists(RAW_BAK):
    shutil.copy(RAW, RAW_BAK)
    print("已备份原始 RAW_CACHE ->", RAW_BAK)

series = rb.parse_index()
print("total days:", len(series))


def run_variant(tag, disable_caishen, disable_stock):
    rb.REPORT = os.path.join(rb.HERE, f"regime_backtest_{tag}.json")
    jf.DISABLE_CAISHEN = bool(disable_caishen)
    if disable_stock:
        os.environ["DISABLE_STOCK_VALENCE"] = "1"
    else:
        os.environ.pop("DISABLE_STOCK_VALENCE", None)
    # 两变体都记录理论触发值（用于覆盖率对比，开销极小）
    rb._CAPTURE_STOCK = True
    t0 = time.time()
    rb.run_engine(series, force=True)   # 重算全部 5239 日，填充 RAW_CACHE
    rb.main()                           # 读缓存、统计、写报告到 rb.REPORT
    print(f"[{tag}] done in {time.time()-t0:.0f}s -> {rb.REPORT}")


try:
    run_variant("clean", disable_caishen=True, disable_stock=True)      # A'
    run_variant("stockval", disable_caishen=True, disable_stock=False)  # B'
finally:
    rb._CAPTURE_STOCK = False
    # 还原生产参考缓存，避免静默改写
    if os.path.exists(RAW_BAK):
        shutil.copy(RAW_BAK, RAW)
        print("已还原原始 RAW_CACHE")

print("ALL DONE")
