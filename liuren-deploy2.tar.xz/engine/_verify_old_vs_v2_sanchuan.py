# -*- coding: utf-8 -*-
"""旧引擎 DaLiuRenEngine vs 权威 V2 SiKeSanChuanCalculator2 三传一致性验证
60 甲子 × 12 月将 × 午时 = 720 组合；另加 4 时辰抽查。
Python 3.12 + PYTHONHASHSEED=0 运行。
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.daliuren_engine import DaLiuRenEngine
from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2

TIANGAN = list("甲乙丙丁戊己庚辛壬癸")
DIZHI = list("子丑寅卯辰巳午未申酉戌亥")
# 60 甲子：阳干配阳支，阴干配阴支
YANG_GAN = "甲丙戊庚壬"; YANG_ZHI = "子寅辰午申戌"
YIN_GAN = "乙丁己辛癸"; YIN_ZHI = "丑卯巳未酉亥"
GANZHI = [g + z for g in YANG_GAN for z in YANG_ZHI] + [g + z for g in YIN_GAN for z in YIN_ZHI]

old = DaLiuRenEngine()
v2 = SiKeSanChuanCalculator2()

def old_sanchuan(gan, zhi, yj, shi):
    tp = old.arrange_tiandi_pan(yj, shi)
    sk = old.arrange_si_ke(gan, zhi, tp)
    res = old.fa_san_chuan(sk, gan, tp)
    chuan = res.get('三传') or []
    # 旧引擎三传可能带课名如 '初传:子' 或纯地支
    def norm(c):
        if isinstance(c, dict):
            return c.get('支') or c.get('地支') or list(c.values())[0]
        return str(c).split(':')[-1]
    return [norm(c) for c in chuan], res.get('课体', '')

def v2_sanchuan(gan, zhi, yj, shi):
    r = v2.calculate(gan, zhi, yj, shi)
    sc = r['sanchuan']
    return [sc.get('初传', ''), sc.get('中传', ''), sc.get('末传', '')], sc.get('课体', '')

def old_sike(gan, zhi, yj, shi):
    tp = old.arrange_tiandi_pan(yj, shi)
    sk = old.arrange_si_ke(gan, zhi, tp)
    return [(k['name'], k['top'], k['bottom']) for k in sk]

def v2_sike(gan, zhi, yj, shi):
    r = v2.calculate(gan, zhi, yj, shi)
    return [(n, s, x) for n, s, x, _ in r['sike']]

mismatch = []
sike_mismatch = 0
total = 0
for gz in GANZHI:
    gan, zhi = gz[0], gz[1]
    for yj in DIZHI:
        for shi in ['午']:
            total += 1
            o, ok = old_sanchuan(gan, zhi, yj, shi)
            v, vk = v2_sanchuan(gan, zhi, yj, shi)
            if old_sike(gan, zhi, yj, shi) != v2_sike(gan, zhi, yj, shi):
                sike_mismatch += 1
            if o != v:
                mismatch.append((gz, yj, shi, '三传', o, v))
            elif ok and vk and ok != vk:
                mismatch.append((gz, yj, shi, '课体', ok, vk))

# 多时辰抽查（覆盖天地盘不同转盘）
extra_shichen = ['子', '卯', '酉']
for gz in GANZHI[::6]:
    gan, zhi = gz[0], gz[1]
    for yj in ['子', '午']:
        for shi in extra_shichen:
            total += 1
            o, ok = old_sanchuan(gan, zhi, yj, shi)
            v, vk = v2_sanchuan(gan, zhi, yj, shi)
            if old_sike(gan, zhi, yj, shi) != v2_sike(gan, zhi, yj, shi):
                sike_mismatch += 1
            if o != v:
                mismatch.append((gz, yj, shi, '三传', o, v))
            elif ok and vk and ok != vk:
                mismatch.append((gz, yj, shi, '课体', ok, vk))

print(f"总组合: {total}, 不一致: {len(mismatch)}, 其中四课不一致: {sike_mismatch}")
for m in mismatch[:40]:
    print("  MISMATCH:", m)
if mismatch:
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_old_vs_v2_mismatch.json')
    json.dump(mismatch, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print("详细清单:", out)
