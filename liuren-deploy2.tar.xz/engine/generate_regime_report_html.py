# -*- coding: utf-8 -*-
"""读取 regime_backtest_report.json, 生成带图表的 HTML 回测报告。"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT = os.path.join(HERE, "regime_backtest_report.json")
OUT = os.path.join(HERE, "regime_backtest_report.html")

R = json.load(open(REPORT, encoding="utf-8"))
ov = R["overall"]
base = R["base_down_rate"]

# ---- 方法对比卡 ----
def card(name, m, brier=True):
    ci = m["ci95"]
    sig = "✅ 无显著" if m["p_value"] > 0.05 else ("⚠️ 显著劣于随机" if m["accuracy"] < 0.5 else "⚠️ 显著优于随机")
    br = f"{m['brier']:.3f}" if (brier and m["brier"]) else "—"
    return f"""
    <div class="card">
      <div class="cname">{name}</div>
      <div class="big">{m['accuracy']*100:.1f}%</div>
      <div class="sub">决断准确率 (CI {ci[0]*100:.1f}–{ci[1]*100:.1f}%)</div>
      <div class="row"><span>覆盖率</span><b>{m['coverage']*100:.1f}%</b></div>
      <div class="row"><span>看跌偏置</span><b>{m['down_bias']*100:.1f}%</b></div>
      <div class="row"><span>Brier</span><b>{br}</b></div>
      <div class="row"><span>p 值(vs 50%)</span><b>{m['p_value']:.3f}</b></div>
      <div class="verdict">{sig}</div>
    </div>"""

methods = [
    ("M1 原20d引擎", ov["M1"], False),
    ("M2 融合①②③", ov["M2"], True),
    ("M3 融合+CBR", ov["M3"], True),
    ("M4 CBR单独", ov["M4"], False),
]
cards_html = "".join(card(n, m, b) for n, m, b in methods)

# ---- SVG: 方法准确率 + 看跌偏置 ----
def svg_method():
    W, H = 720, 320
    methods4 = [("M1", ov["M1"]), ("M2", ov["M2"]), ("M3", ov["M3"]), ("M4", ov["M4"])]
    maxv = 100
    barw = 64
    gap = (W - 80) / 4
    svg = [f'<svg viewBox="0 0 {W} {H}" width="100%">']
    # 50% 基准线
    y50 = H - 40 - (50 / maxv) * (H - 70)
    svg.append(f'<line x1="60" y1="{y50}" x2="{W-20}" y2="{y50}" stroke="#e67e22" stroke-dasharray="5 4" stroke-width="1.5"/>')
    svg.append(f'<text x="{W-18}" y="{y50-6}" fill="#e67e22" font-size="11">50% 随机基准</text>')
    for i, (nm, m) in enumerate(methods4):
        x = 70 + i * gap
        # 准确率柱 + CI
        y_acc = H - 40 - (m["accuracy"] * 100 / maxv) * (H - 70)
        svg.append(f'<rect x="{x}" y="{y_acc}" width="{barw}" height="{H-40-y_acc}" fill="#3498db"/>')
        ci_lo = m["ci95"][0] * 100; ci_hi = m["ci95"][1] * 100
        ylo = H - 40 - (ci_lo / maxv) * (H - 70)
        yhi = H - 40 - (ci_hi / maxv) * (H - 70)
        svg.append(f'<line x1="{x+barw/2}" y1="{yhi}" x2="{x+barw/2}" y2="{ylo}" stroke="#1f3a5f" stroke-width="2"/>')
        svg.append(f'<text x="{x+barw/2}" y="{y_acc-6}" fill="#1f3a5f" font-size="11" text-anchor="middle">{m["accuracy"]*100:.1f}%</text>')
        # 看跌偏置柱 (半透明)
        yb = H - 40 - (m["down_bias"] * 100 / maxv) * (H - 70)
        svg.append(f'<rect x="{x+barw+6}" y="{yb}" width="{barw*0.5}" height="{H-40-yb}" fill="#e74c3c" opacity="0.55"/>')
        svg.append(f'<text x="{x+barw/2}" y="{H-22}" fill="#333" font-size="12" text-anchor="middle">{nm}</text>')
    svg.append('</svg>')
    return "".join(svg)

# ---- SVG: 分周期准确率 ----
def svg_cycle():
    cyc = R["by_cycle"]
    items = [(k, v["M3"]["accuracy"]*100, v["M3"]["p_value"], v["actual_down_rate"]*100, v["n"]) for k, v in cyc.items()]
    W, H = 760, 360
    n = len(items)
    bw = (W - 120) / n - 8
    svg = [f'<svg viewBox="0 0 {W} {H}" width="100%">']
    y50 = H - 55 - (50/100)*(H-90)
    svg.append(f'<line x1="90" y1="{y50}" x2="{W-10}" y2="{y50}" stroke="#e67e22" stroke-dasharray="5 4"/>')
    svg.append(f'<text x="{W-8}" y="{y50-6}" fill="#e67e22" font-size="11" text-anchor="end">50%</text>')
    for i,(k,acc,p,adr,nn) in enumerate(items):
        x = 100 + i*(bw+8)
        y = H-55 - (acc/100)*(H-90)
        col = "#27ae60" if p>0.05 else ("#e74c3c" if acc<50 else "#3498db")
        svg.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{H-55-y}" fill="{col}" opacity="0.85"/>')
        svg.append(f'<text x="{x+bw/2}" y="{y-4}" fill="#333" font-size="9" text-anchor="middle">{acc:.1f}</text>')
        # 竖排周期名
        short = k.split(" ")[0]
        svg.append(f'<text x="{x+bw/2}" y="{H-40}" fill="#555" font-size="9" text-anchor="middle" transform="rotate(40 {x+bw/2} {H-40})">{short}</text>')
    svg.append('</svg>')
    return "".join(svg)

# ---- 周期表 ----
def cycle_table():
    rows = ""
    for k, v in R["by_cycle"].items():
        m3 = v["M3"]
        flag = "" if m3["p_value"]>0.05 else ("🔻" if m3["accuracy"]<0.5 else "🔺")
        rows += f"""<tr><td>{k}</td><td>{v['n']}</td><td>{v['actual_down_rate']*100:.1f}%</td>
        <td>{m3['accuracy']*100:.1f}%</td><td>{m3['ci95'][0]*100:.1f}–{m3['ci95'][1]*100:.1f}%</td>
        <td>{m3['p_value']:.3f} {flag}</td><td>{m3['coverage']*100:.1f}%</td><td>{m3['down_bias']*100:.1f}%</td></tr>"""
    return rows

def year_table():
    rows=""
    for y,v in R["by_year"].items():
        m3=v["M3"]
        flag = "" if m3["p_value"]>0.05 else ("🔻" if m3["accuracy"]<0.5 else "🔺")
        rows+=f"<tr><td>{y}</td><td>{v['n']}</td><td>{v['actual_down_rate']*100:.1f}%</td><td>{m3['accuracy']*100:.1f}%</td><td>{m3['p_value']:.3f}{flag}</td><td>{m3['coverage']*100:.1f}%</td></tr>"
    return rows

band = R["by_trailing_band"]
band_rows=""
for k,v in band.items():
    m3=v["M3"]
    band_rows+=f"<tr><td>{k}</td><td>{v['n']}</td><td>{v['actual_down_rate']*100:.1f}%</td><td>{m3['accuracy']*100:.1f}%</td><td>{m3['p_value']:.3f}</td><td>{m3['down_bias']*100:.1f}%</td></tr>"

m3=ov["M3"]; m1=ov["M1"]; m4=ov["M4"]
html = f"""<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<title>六壬精准引擎 · 跨牛熊扩大回测报告</title>
<style>
 body{{font-family:-apple-system,'Segoe UI','Microsoft YaHei',sans-serif;background:#f5f7fa;color:#222;margin:0;padding:24px;}}
 h1{{font-size:22px;margin:0 0 4px;}} .sub{{color:#666;font-size:13px;margin-bottom:18px;}}
 .cards{{display:flex;gap:14px;flex-wrap:wrap;margin:18px 0;}}
 .card{{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;width:200px;box-shadow:0 1px 3px rgba(0,0,0,.05);}}
 .cname{{font-weight:600;font-size:14px;margin-bottom:6px;}}
 .big{{font-size:30px;font-weight:700;color:#2c3e50;}}
 .sub{{font-size:11px;color:#888;margin-bottom:8px;}}
 .row{{display:flex;justify-content:space-between;font-size:12px;padding:2px 0;color:#444;}}
 .verdict{{margin-top:8px;font-size:11px;font-weight:600;padding:4px 6px;border-radius:5px;background:#eafaf1;color:#1e7e34;}}
 .panel{{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px 18px;margin:16px 0;}}
 .panel h2{{font-size:16px;margin:0 0 10px;}}
 table{{width:100%;border-collapse:collapse;font-size:12px;}}
 th,td{{border:1px solid #eef;padding:5px 7px;text-align:center;}}
 th{{background:#f0f4f8;}}
 .note{{font-size:12px;color:#555;line-height:1.7;background:#fff8e1;border-left:4px solid #f1c40f;padding:10px 14px;border-radius:4px;margin:14px 0;}}
 .key{{font-size:13px;line-height:1.8;}}
 .key b{{color:#c0392b;}}
</style></head><body>
<h1>六壬精准判断引擎 · 跨牛熊扩大回测</h1>
<div class="sub">数据源：上证指数 sh000001 日线（腾讯自选股）｜ 标签：收>开 为涨 ｜ 时辰：午 ｜ 样本区间 {R['date_range'][0]} ~ {R['date_range'][1]} ｜ 共 {R['n_valid']} 个交易日</div>

<div class="cards">{cards_html}</div>

<div class="panel"><h2>① 四方法对比：决断准确率（含95%置信区间）与看跌偏置</h2>
{svg_method()}
<div class="sub" style="color:#666;font-size:11px">蓝柱=决断准确率（误差线=Wilson 95%CI）；红半透明柱=看跌偏置（占决断数比例）。橙虚线=50% 随机基准。</div>
</div>

<div class="note">
<b>核心结论（有效边界）：</b><br>
• <b>M1 原引擎与 M4 CBR 单独</b> 准确率分别为 {m1['accuracy']*100:.1f}% / {m4['accuracy']*100:.1f}%，p 值均 &lt;0.001，<b>显著劣于随机</b>——二者存在强烈的<b>结构性看跌偏置</b>（{m1['down_bias']*100:.1f}% / {m4['down_bias']*100:.1f}%）。若据此交易必亏。<br>
• <b>融合层（M2/M3）把看跌偏置从 {m1['down_bias']*100:.1f}% 纠正到 ~50%</b>，准确率回到 {ov['M2']['accuracy']*100:.1f}% / {m3['accuracy']*100:.1f}%（p={ov['M2']['p_value']:.2f} / {m3['p_value']:.2f}），即<b>无方向性 alpha 的公平硬币</b>。这是支柱①②③校准的实质性成功：它中和了朴素引擎的有害偏置。<br>
• <b>CBR（M3 vs M2）的边际贡献是概率校准而非方向</b>：Brier 由 {ov['M2']['brier']:.3f} 微降至 {m3['brier']:.3f}（越低越好），方向准确率几乎不变 → CBR 权重保持中性(1.0)是正确的。<br>
• 大盘实际跌占比基准为 {base*100:.1f}%（略偏牛），所有方法都无法系统性战胜它。
</div>

<div class="panel"><h2>② 分牛熊周期：M3(融合+CBR) 决断准确率</h2>
{svg_cycle()}
<div class="sub" style="color:#666;font-size:11px">每根柱为该周期的 M3 准确率；绿=不显著，红=显著(p&lt;0.05)。所有周期都在 50% 附近抖动，无一显著优于随机。</div>
</div>

<div class="panel"><h2>③ 分周期明细表</h2>
<table><tr><th>历史阶段</th><th>n</th><th>实际跌占比</th><th>M3准确率</th><th>95%CI</th><th>p值</th><th>覆盖率</th><th>看跌偏置</th></tr>
{cycle_table()}</table>
<div class="sub" style="color:#666;font-size:11px">🔻=显著劣于随机，🔺=显著优于随机。11 个周期中仅个别 p&lt;0.05，符合多重比较下 ~0.5 个假阳性的预期。</div>
</div>

<div class="panel"><h2>④ 分年份明细</h2>
<table><tr><th>年份</th><th>n</th><th>实际跌占比</th><th>M3准确率</th><th>p值</th><th>覆盖率</th></tr>
{year_table()}</table>
</div>

<div class="panel"><h2>⑤ 按 trailing 120日收益带 分段</h2>
<table><tr><th>收益带</th><th>n</th><th>实际跌占比</th><th>M3准确率</th><th>p值</th><th>看跌偏置</th></tr>
{band_rows}</table>
<div class="sub" style="color:#666;font-size:11px">牛/熊/震荡三段 M3 准确率分别为 {band.get('牛( trailing +%)',{}).get('M3',{}).get('accuracy',0)*100:.1f}% / {band.get('熊( trailing -%)',{}).get('M3',{}).get('accuracy',0)*100:.1f}% / {band.get('震荡',{}).get('M3',{}).get('accuracy',0)*100:.1f}% —— 引擎的"看跌偏置"并不随真实熊市升高，证实其为<b>日历人为产物而非市场技能</b>。</div>
</div>

<div class="panel"><h2>⑥ 对"有效边界"的最终判定</h2>
<div class="key">
1. <b>作为方向预测器：无效。</b> 融合+CBR 在 5239 个交易日、11 个牛熊周期、22 个年份上，方向准确率始终≈50%（无统计显著 edge）。这是<b>确定性日历方法</b>与价格无因果联系的必然结果。<br>
2. <b>作为偏置中和器：有效。</b> 它的真实价值在于把朴素引擎(M1)与CBR(M4)那 75%~82% 的有害看跌偏置，纠正为公平的 ~50%，使系统从"必亏"变为"不偏不倚的硬币"。<br>
3. <b>CBR 的正确定位：解释层，不是信号层。</b> 仅贡献边际 Brier 改善，权重保持中性；切勿放大。<br>
4. <b>诚实边界：</b>该引擎是"结构化解读/叙事透镜"，不应作为交易信号。任何将其包装为择时 alpha 的用法都是不成立的。
</div>
</div>
</body></html>"""

open(OUT, "w", encoding="utf-8").write(html)
print("written", OUT, len(html), "bytes")
