# -*- coding: utf-8 -*-
"""长征第1期 · sec12 行人音信(5) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§行人音信12·157": {
        "leishen": ["江：子(子江也)", "元武：发用辰加子作元", "太阳：子(子乃十二月太阳)"],
        "liqi": ["冬占润下课正及时【原文课体·润下】", "发用辰加子作元子江也上得辰土克之→故浅", "甲日子加申子乃十二月太阳今在申→主十二月"],
        "leixiang": ["子=江(太阳)、辰=土(克水浅)、申=传送"],
        "yingqi": ["第三日得信(已到润州水浅)", "十二月至任"],
    },
    "§行人音信12·158": {
        "leishen": ["勾陈：乘岁马作鬼", "雀：中传雀乘太岁", "贵人：末见贵人", "岁马：申(申是岁马)"],
        "liqi": ["传见勾陈乘岁马作鬼、中传又雀乘太岁、末见贵人", "月建前一辰为用→应七月", "申是岁马带鬼克日申为传送又为道路鬼害→故来速"],
        "leixiang": ["申=岁马(传送道路鬼)、戌=太岁(雀)、子=贵人"],
        "yingqi": ["七月癸巳日文字来充替河州"],
    },
    "§行人音信12·159": {
        "leishen": ["马：课传俱马", "青龙：乘青龙作官星", "禄：禄又得后", "天罡：天罡加支"],
        "liqi": ["课传俱马又乘青龙作官星禄又得后→主得官", "天罡加支望事立至用事严紧→故速来"],
        "leixiang": ["寅申=马(青龙官星)、天罡=立至"],
        "yingqi": ["当日榜至、中四十九名"],
    },
    "§行人音信12·160": {
        "leishen": ["日马：初传日马乘后", "天后：恩泽神", "虎：虎乘墓加身"],
        "liqi": ["初传日马乘后为恩泽神又月建主州文字", "巳时为用→故不出时见之", "虎乘墓加身→长老得了自却有灾"],
        "leixiang": ["巳=日马(天后恩泽)、申=传送、虎=墓(灾)"],
        "yingqi": ["当日文字至", "去谢州中路门辕拱柱颠下手废成疾"],
    },
    "§行人音信12·161": {
        "leishen": ["朱雀：朱雀临门", "昴星：昴星课"],
        "liqi": ["昴星课【原文课体·昴星】", "卯日子加卯朱雀临门→主文字立至", "子卯相刑→主其来紧速", "三传俱在日辰之上→日下必然到"],
        "leixiang": ["子=朱雀(临门)、卯=刑"],
        "yingqi": ["文字今日必来"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec12 157-161）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
