# -*- coding: utf-8 -*-
"""长征第1期 · sec15 亡盗 batch2 (196-201) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§亡盗15·196": {
        "leishen": ["类神：度牒以朱雀为类神", "僧人：申(申为僧人)", "元武：乘卯合辛(亲人)"],
        "liqi": ["度牒以朱雀为类神申为僧人而元武乘卯合辛→故为亲人", "辛克卯→卯遂偷去", "外弟偷去手足有疾"],
        "leixiang": ["申=僧人、卯=亲人(元武合辛)、朱雀=类神"],
        "yingqi": ["被亲偷去火焚"],
    },
    "§亡盗15·197": {
        "leishen": ["元武：元武在申(申为高处)", "太阴：未为木墓内有鬼宿乘太阴(神庙)", "鬼宿", "勾陈：丑为官星勾作刑"],
        "liqi": ["癸为日主刑戌戌为人力又为高楼宿处", "伏吟不离本家【原文课体·伏吟】", "未为木墓内有鬼宿乘太阴→主神庙、太阴主隐匿", "人在高处者元武在申申为高处", "丑为官星勾作刑→故获"],
        "leixiang": ["申=高处(元武)、未=神庙(太阴鬼宿)、戌=人力高楼"],
        "yingqi": ["今日午时二姓徐王人败、本衙神庙龛下寻见"],
    },
    "§亡盗15·198": {
        "leishen": ["类神：酉(酉临火墓)", "太阴：作太阴", "蛇雀：发用巳午蛇雀"],
        "liqi": ["缸边者发用巳午蛇雀", "近水泥湿者乃午未上遁得壬癸水", "类神酉临火墓作太阴→是以贼不出去"],
        "leixiang": ["巳午=蛇雀(炉灶)、午未=遁壬癸(水泥湿)、酉=类神(火墓太阴)"],
        "yingqi": ["灶边水缸下寻见"],
    },
    "§亡盗15·199": {
        "leishen": ["类神：酉(酉为类神)", "元武：辰作元武(主仆)", "勾陈：作勾临午", "太阴：临水"],
        "liqi": ["辰作元武→主仆辈", "酉为类神作勾临午更太阴临水→主湿处", "凡失物须看类神在传或加日辰定见、传日不出日传时不出时"],
        "leixiang": ["酉=类神(勾)、辰=元武(仆)、午=南方炉灶、太阴=水湿"],
        "yingqi": ["南方炉灶前水湿处寻之、自家人盗"],
    },
    "§亡盗15·200": {
        "leishen": ["类神：卯(卯为类神)", "舡：卯(卯乃舡)", "六合：寅作合"],
        "liqi": ["寅作合加辰为用舡在地之象", "寅木也乘合卯乃舡", "今日卯为类神加巳是在地户东南上", "寅卯木三数辰五数共八→初八日内"],
        "leixiang": ["卯=舡(类神)、寅=木(合)、巳=地户(东南)"],
        "yingqi": ["初八日于东南上寻见"],
    },
    "§亡盗15·201": {
        "leishen": ["人力：戌(戌为人力)", "太常：太常为博士(酒食)", "天空：天空亦是人力", "炉灶：巳(巳为炉灶)"],
        "liqi": ["巳为炉灶又铸印体【引擎:课格·铸印】", "太常为博士亦主酒食", "戌为人力天空亦是→两人力合偷", "申为麦面"],
        "leixiang": ["巳=炉灶(铸印)、戌=人力(天空)、太常=博士酒食、申=麦面"],
        "yingqi": ["人力与对门面店博士合偷"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec15 196-201）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
