# -*- coding: utf-8 -*-
"""检查 占类化 valence 在 winning base(八杀ON+神煞负向+德0.7)下帮助还是伤害。"""
import json, sys
from collections import Counter
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import (
    set_enabled, set_text_enabled, set_derive_enabled,
    set_shen_sha_enabled, set_ba_sha_enabled, SHEN_SHA_GLOBAL, ZIL_CATEGORY_OVERRIDE,
)
import engine.judgment_fusion as jf
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list): sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2: return None
    if c.get("label") not in ("吉","凶","平"): return None
    return {"rizhu":rz,"yue_jiang":c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
            "shichen":c["shichen"] if c.get("shichen") in VALID else "",
            "sanchuan":sc,"keti":[],"duanyu":c.get("duanyu",""),
            "category":c.get("zhanlei","其他"),"label":c["label"]}

cases = [x for x in (build_clean(c) for c in REAL) if x]
set_enabled(True); set_text_enabled(False); set_derive_enabled(True)
set_ba_sha_enabled(True); set_shen_sha_enabled(True)
import engine.liuren_keti_bifa as kb
kb.SHEN_SHA_GLOBAL = {"桃花":-1,"劫煞":-1,"灾煞":-1,"天罗":-1,"地网":-1}
jf.DE_HALF_MULT = 0.7

def run_m3(override_on):
    kb.ZIL_CATEGORY_OVERRIDE = ZIL_CATEGORY_OVERRIDE if override_on else {}
    n=cor=0; cm=Counter(); bycat={}
    for c in cases:
        p = predict_ancient_case(c, "M3").get("prediction", "")
        n+=1; cor+=(p==c["label"]); cm[f"{c['label']}->{p}"]+=1
        d=bycat.setdefault(c["category"],[0,0]); d[0]+=1; d[1]+=(p==c["label"])
    return cor/n, dict(cm), bycat

acc,cm,bc = run_m3(True)
print(f"占类化ON  八杀ON 神煞负向 德0.7  M3={acc*100:.1f}%  {cm}")
for k,v in sorted(bc.items(), key=lambda x:-x[1][0]):
    if v[0]>=3: print(f"    {k:<6} {v[1]/v[0]*100:>5.1f}% ({v[1]}/{v[0]})")
acc,cm,bc = run_m3(False)
print(f"占类化OFF 八杀ON 神煞负向 德0.7  M3={acc*100:.1f}%  {cm}")
for k,v in sorted(bc.items(), key=lambda x:-x[1][0]):
    if v[0]>=3: print(f"    {k:<6} {v[1]/v[0]*100:>5.1f}% ({v[1]}/{v[0]})")
