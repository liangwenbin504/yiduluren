# -*- coding: utf-8 -*-
"""验证持久化登录态 + 翻页深度
- 用 _weread_profile 启动 headless persistent context
- 打开书，翻 50 页，看是否还有内容（之前 38 页后空白）
- 截图 p50 确认
"""
import asyncio, os

PROFILE = os.path.abspath('_weread_profile')
URL = 'https://weread.qq.com/web/reader/33932640813abaad7g018f8ckc81322c012c81e728d9d180'

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE, channel='msedge', headless=True,
            viewport={'width': 1440, 'height': 1000})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto(URL, wait_until='domcontentloaded', timeout=40000)
        await page.wait_for_timeout(5000)
        print('URL:', page.url)

        # 检查登录
        cookies = await ctx.cookies()
        login = any('wr_skey' in (c.get('name') or '') for c in cookies)
        print('登录态:', '✓' if login else '✗')

        # 获取canvas
        box = await page.evaluate('''() => {
            const c = document.querySelector('canvas');
            if (!c) return null;
            const r = c.getBoundingClientRect();
            return {x:r.x, y:r.y, w:r.width, h:r.height};
        }''')
        print('canvas:', box)

        # 翻到 p50 验证（之前 p38 之后空白）
        for i in range(50):
            await page.keyboard.press('ArrowRight')
            await page.wait_for_timeout(800)
        await page.wait_for_timeout(2000)
        path = '_weread_p50_check.png'
        if box:
            await page.screenshot(path=path, clip={'x': box['x'], 'y': box['y'], 'width': box['w'], 'height': box['h']})
        else:
            await page.screenshot(path=path)
        sz = os.path.getsize(path)
        print(f'p50 截图: {path} ({sz}B) - {"有内容" if sz > 10000 else "空白!"}')

        # 再翻到 p100
        for i in range(50):
            await page.keyboard.press('ArrowRight')
            await page.wait_for_timeout(700)
        await page.wait_for_timeout(2000)
        path = '_weread_p100_check.png'
        if box:
            await page.screenshot(path=path, clip={'x': box['x'], 'y': box['y'], 'width': box['w'], 'height': box['h']})
        else:
            await page.screenshot(path=path)
        sz = os.path.getsize(path)
        print(f'p100 截图: {path} ({sz}B) - {"有内容" if sz > 10000 else "空白!"}')

        await ctx.close()

asyncio.run(main())
