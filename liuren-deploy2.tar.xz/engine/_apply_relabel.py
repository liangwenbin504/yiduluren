# -*- coding: utf-8 -*-
"""应用对齐结果 -> 生成诚实重标版真值标签 + 复核队列。
- reliable(46): 直接采用真实案真值重标，写入 ancient_truth_labels_v2.json
- needs_review(176) + ambiguous(2): 保留原标签，导出复核队列供人工逐项研究
"""
import json
from collections import Counter

BASE_LABELS = "engine/ancient_truth_labels.json"
RELABEL_MAP = "engine/corpusB_relabel_map.json"
OUT_V2 = "engine/ancient_truth_labels_v2.json"
OUT_QUEUE = "engine/corpusB_review_queue.json"

L = json.load(open(BASE_LABELS, "r", encoding="utf-8"))
RM = json.load(open(RELABEL_MAP, "r", encoding="utf-8"))
cases = L["cases"]
by_id = {c["id"]: c for c in cases}

rel = RM["reliable"]
nr = RM["needs_review"]
amb = RM["ambiguous"]
unm = RM["unmatched"]

applied = 0
flip_stat = Counter()
for r in rel:
    cid = r["id"]
    c = by_id.get(cid)
    if not c:
        continue
    old = c.get("label", "未知")
    new = r["real_label"]
    if old != new:
        flip_stat[(old, new)] += 1
    c["label"] = new
    c["label_confidence"] = r["real_conf"]
    c["label_evidence"] = (
        f"对齐真实疏正案{r['real_case_id']}《{r['real_name']}》重标"
        f"(依据={r['match_basis']}; 原标签={old})"
    )
    c["relabeled_from"] = old
    c["relabel_basis"] = r["match_basis"]
    c["real_case_id"] = r["real_case_id"]
    applied += 1

# 写 v2（仅 reliable 改写；needs_review/ambiguous 保留原标签）
json.dump(L, open(OUT_V2, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

# 复核队列：needs_review + ambiguous，附“建议标签”供人工决断
queue = []
for r in nr + amb:
    cid = r.get("id")
    c = by_id.get(cid, {})
    queue.append({
        "id": cid,
        "category": r.get("syn_zl") or c.get("category", ""),
        "age": r.get("age", c.get("age")),
        "current_label": c.get("label", "未知"),
        "current_conf": c.get("label_confidence", 0),
        "suggested_label": r.get("real_label") or r.get("top_label", ""),
        "suggested_conf": r.get("real_conf", 0),
        "match_score": r.get("score"),
        "match_reasons": r.get("reasons", []),
        "real_case_id": r.get("real_case_id") or r.get("top_real", ""),
        "real_name": r.get("real_name", ""),
        "note": ("歧义(候选分<120)" if r in amb else "已匹配但缺强键(占类+年龄为主)"),
    })
json.dump({"count": len(queue), "queue": queue},
          open(OUT_QUEUE, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

print(f"reliable 总数: {len(rel)} | 已应用重标: {applied}")
print(f"改写方向: {dict(flip_stat)}")
print(f"保留原标签(待复核): needs_review={len(nr)} + ambiguous={len(amb)} = {len(queue)}")
print(f"v2 已写出: {OUT_V2}")
print(f"复核队列已写出: {OUT_QUEUE}")

# 标签分布对比
from collections import Counter as C
old_dist = C(c.get("label", "未知") for c in L["cases"])
# v1 分布从原文件
L1 = json.load(open(BASE_LABELS, "r", encoding="utf-8"))
v1_dist = C(c.get("label", "未知") for c in L1["cases"])
print("\n标签分布  v1(原) -> v2(重标后):")
for k in ["吉", "凶", "平", "未知"]:
    print(f"  {k}: {v1_dist.get(k,0)} -> {old_dist.get(k,0)}")
