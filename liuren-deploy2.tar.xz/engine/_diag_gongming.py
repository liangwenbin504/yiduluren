# -*- coding: utf-8 -*-
"""功名60案：全量信号诊断 + 错误清单 + 吉/凶信号分离度。"""
import json, sys
sys.path.insert(0, ".")
from engine.ancient_backtest import build_result_from_ancient
import engine.judgment_fusion as jf

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")
def ok(x): return isinstance(x, str) and x in VALID

hits = [c for c in REAL if c.get('zhanlei') == '功名']
hits.sort(key=lambda c: str(c.get('case_id', '')))

rows = []
for c in hits:
    sc = c.get('sanchuan') or []
    clean = {'id': c['case_id'], 'name': c.get('name', ''), 'category': c.get('zhanlei', '功名'),
             'rizhu': c['day_ganzhi'], 'yue_jiang': c['yue_jiang'] if ok(c.get('yue_jiang')) else '',
             'shichen': c['shichen'] if ok(c.get('shichen')) else '', 'sanchuan': sc, 'keti': [],
             'label': c.get('label'), 'label_confidence': c.get('label_conf', 0),
             'month': c.get('month'), 'ben_ming_zhi': c.get('ben_ming_zhi'), 'year': c.get('year') or ''}
    result = build_result_from_ancient(clean)
    sigs = jf.collect_signals(result)
    fused = jf.fuse(result)
    trend = fused.get('trend')
    a = result.get('analysis') or {}
    rows.append((c['case_id'], c.get('label'), trend,
                 {g: sc2 for g, sc2, _, _ in sigs},
                 a.get('_gongming_valence'), c.get('name', '')))

print(f"功名占类共 {len(hits)} 案\n")
print(f"{'case':<16}{'truth':<5}{'pred':<5}  信号分解")
err_ji = []   # 吉判凶
err_xiong = []  # 凶判吉
for cid, lab, trend, sigmap, gm, nm in rows:
    pred = '吉' if trend == '看涨' else ('凶' if trend == '看跌' else '平')
    flag = '  <<<错' if pred != lab else ''
    parts = ' '.join(f'{g}:{v:+.1f}' for g, v in sorted(sigmap.items(), key=lambda x: -abs(x[1])))
    gm_s = gm.get('fired', '') if isinstance(gm, dict) else ''
    print(f'{cid:<16}{lab:<5}{pred:<5}  {parts}  [gm:{gm_s}] {nm[:10]}{flag}')
    if pred != lab:
        if lab == '吉' and pred == '凶':
            err_ji.append(cid)
        elif lab == '凶' and pred == '吉':
            err_xiong.append(cid)

print(f"\n=== 错误汇总：共 {len(err_ji)+len(err_xiong)} 错 ===")
print(f"吉判凶（吉案漏判）: {err_ji}")
print(f"凶判吉（凶案误判）: {err_xiong}")
