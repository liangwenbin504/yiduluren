# -*- coding: utf-8 -*-
"""标注标签修正：区分「原文课体」与「引擎课格」。
引擎 64 课（liuren_64ke_judge._JUDGES）+ 九宗门课体 是 engine_hits 的真实输出域。
邵彦和断语里另有课体命名（登三天/涉三渊/四绝/顾祖/虎视/出户/连茹/伏吟/遥克/昴星等），
引擎未实现，误标为【引擎:课格·XXX】会虚标引擎能力。统一改为【原文课体·XXX】。
"""
import json, re

ENG_KETI = {'度厄','无禄','绝嗣','天网','全局','玄胎','连珠','间传','六纯','斩关','龙战','死奇',
            '鬼墓','励德','铸印','轩盖','游子','三交','龙德','时泰','三光','三奇','六仪','合欢',
            '和美','亨通','侵害','刑伤','魄化','殃咎','闭口','天祸','天寇','二烦','斫轮','引从',
            '乱首','赘婿','冲破','淫佚','芜淫','解离','孤辰','寡宿','天狱','三阴','盘珠','荣华',
            '官爵','繁昌','九丑','迍福','三阳','富贵','德庆','灾厄'}

# 课格类别中，需转「原文课体」的课名（引擎无对应）
TO_YUANTI = {'连茹','登三天','涉三渊','四绝','顾祖','虎视','出户','墓神','铸印乘轩','病胎',
             '伏吟','昴星','遥克','弹射','遥克/弹射','润下','炎上','曲直','从革','稼穑'}
# 课格类别中，写法不统一需规整到引擎课名「全局」的
TO_QUANJU = {'全局/木局','全局/水局','全局/火局','全局/金局','全局/土局','全局(三合局)',
             '全局/变格·三传三合','全局·三合','全局三合'}


def fix_label(rule):
    def repl(m):
        val = m.group(1)
        if val in TO_QUANJU:
            return '【引擎:课格·全局】'
        if val in TO_YUANTI:
            return f'【原文课体·{val}】'
        if val in ENG_KETI:
            return m.group(0)
        # 未识别：保守改为原文课体
        return f'【原文课体·{val}】'
    return re.sub(r'【引擎:课格·([^】]+)】', repl, rule)


lm = json.load(open('data/longmarch_annotations.json', encoding='utf-8'))
changed = 0
for c in lm['cases']:
    if not c.get('status', '').startswith('已标注'):
        continue
    ann = c.get('annotation') or {}
    for k in ['leishen', 'liqi', 'leixiang', 'yingqi']:
        rules = ann.get(k) or []
        for i, rule in enumerate(rules):
            new = fix_label(rule)
            if new != rule:
                rules[i] = new
                changed += 1

json.dump(lm, open('data/longmarch_annotations.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(f'已修正 {changed} 条规则标签')

# 复扫验证：确认无引擎课格误标
bad = 0
for c in lm['cases']:
    if not c.get('status', '').startswith('已标注'):
        continue
    ann = c.get('annotation') or {}
    for k in ['leishen', 'liqi', 'leixiang', 'yingqi']:
        for rule in (ann.get(k) or []):
            for m in re.finditer(r'【引擎:课格·([^】]+)】', rule):
                if m.group(1) not in ENG_KETI:
                    bad += 1
                    print('残留误标:', c['case_id'], m.group(1))
print('残留误标课格数:', bad)
