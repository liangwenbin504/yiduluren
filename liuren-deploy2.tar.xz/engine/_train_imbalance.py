# -*- coding: utf-8 -*-
"""长征待办收口：label 类别不平衡训练实验
=================================================
数据：218 案特征向量（label 凶174:吉32:未知11:平1）→ 可判 206 案（凶174:吉32）
对比：无处理 / class_weight=balanced / SMOTE 过采样 × LR / RF / HGB
评估：StratifiedKFold(5, shuffle, seed=42)，指标含 吉recall/凶recall/F1吉/AUC
铁律：Python 3.12 + PYTHONHASHSEED=0；过采样只在训练折内（ImbPipeline 防泄漏）
"""
import json
import sys
import warnings

import numpy as np

sys.path.insert(0, ".")
warnings.filterwarnings("ignore")

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

def _dense(X):
    return X.toarray() if hasattr(X, "toarray") else X

DENSE = FunctionTransformer(_dense)

DATA = "data/longmarch_training_data.json"
RANDOM = 42
N_FOLDS = 5

d = json.load(open(DATA, encoding="utf-8"))
samples = [s for s in d["samples"] if s["label"] in ("吉", "凶")]
num_schema = d["meta"]["numeric_schema"]
cat_schema = d["meta"]["categorical_schema"]

X_num = np.array([[s["numeric"][k] for k in num_schema] for s in samples], dtype=float)
X_cat = np.array([[s["categorical"][k] for k in cat_schema] for s in samples])
y = np.array([1 if s["label"] == "吉" else 0 for s in samples])
n_ji = int(y.sum())
n_xiong = int(len(y) - y.sum())
print(f"样本: {len(y)} 案 | 吉{n_ji} 凶{n_xiong} | 特征: 数值{len(num_schema)} + 类别{len(cat_schema)}")

# 预处理：数值标准化 + 类别 one-hot
pre = ColumnTransformer([
    ("num", StandardScaler(), list(range(7))),
    ("cat", OneHotEncoder(handle_unknown="ignore"), list(range(7, 14))),
], sparse_threshold=0)


def make_pipes():
    return {
        "LR_默认": Pipeline([("pre", pre), ("clf", LogisticRegression(max_iter=2000, random_state=RANDOM))]),
        "LR_balanced": Pipeline([("pre", pre), ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=RANDOM))]),
        "LR_SMOTE": ImbPipeline([("pre", pre), ("smote", SMOTE(random_state=RANDOM)), ("dense", DENSE), ("clf", LogisticRegression(max_iter=2000, random_state=RANDOM))]),
        "RF_默认": Pipeline([("pre", pre), ("clf", RandomForestClassifier(n_estimators=300, random_state=RANDOM))]),
        "RF_balanced": Pipeline([("pre", pre), ("clf", RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=RANDOM))]),
        "RF_SMOTE": ImbPipeline([("pre", pre), ("smote", SMOTE(random_state=RANDOM)), ("dense", DENSE), ("clf", RandomForestClassifier(n_estimators=300, random_state=RANDOM))]),
        "HGB_默认": Pipeline([("pre", pre), ("clf", HistGradientBoostingClassifier(random_state=RANDOM))]),
        "HGB_balanced": Pipeline([("pre", pre), ("clf", HistGradientBoostingClassifier(class_weight="balanced", random_state=RANDOM))]),
        "HGB_SMOTE": ImbPipeline([("pre", pre), ("smote", SMOTE(random_state=RANDOM)), ("dense", DENSE), ("clf", HistGradientBoostingClassifier(random_state=RANDOM))]),
    }


X = np.hstack([X_num, X_cat])
skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM)

rows = []
for name, pipe in make_pipes().items():
    accs, rj, rx, pj, f1j, aucs = [], [], [], [], [], []
    for tr, te in skf.split(X, y):
        pipe.fit(X[tr], y[tr])
        pred = pipe.predict(X[te])
        prob = pipe.predict_proba(X[te])[:, 1]
        accs.append(accuracy_score(y[te], pred))
        rj.append(recall_score(y[te], pred, pos_label=1))
        rx.append(recall_score(y[te], pred, pos_label=0))
        pj.append(precision_score(y[te], pred, pos_label=1))
        f1j.append(f1_score(y[te], pred, pos_label=1))
        aucs.append(roc_auc_score(y[te], prob))
    rows.append((name, np.mean(accs), np.mean(rj), np.mean(rx), np.mean(pj), np.mean(f1j), np.mean(aucs)))

# 朴素基线：永远判凶
base_acc = n_xiong / len(y)
print(f"\n朴素基线(永远判凶): acc={base_acc*100:.1f}% | 吉recall=0.0% | 凶recall=100% | F1吉=0")

print(f"\n{'模型':<12}{'acc':>8}{'吉recall':>10}{'凶recall':>10}{'吉precision':>13}{'F1吉':>8}{'AUC':>8}")
print("-" * 70)
for name, a, rj, rx, pj, f1, auc in rows:
    print(f"{name:<12}{a*100:>7.1f}%{rj*100:>9.1f}%{rx*100:>9.1f}%{pj*100:>12.1f}%{f1:>8.3f}{auc:>8.3f}")

# 汇总最佳
print("\n=== 各维度最佳 ===")
best_acc = max(rows, key=lambda r: r[1])
best_rj = max(rows, key=lambda r: r[2])
best_f1j = max(rows, key=lambda r: r[5])
best_auc = max(rows, key=lambda r: r[6])
print(f"acc 最佳: {best_acc[0]} ({best_acc[1]*100:.1f}%)")
print(f"吉recall 最佳: {best_rj[0]} ({best_rj[2]*100:.1f}%)")
print(f"F1吉 最佳: {best_f1j[0]} ({best_f1j[5]:.3f})")
print(f"AUC 最佳: {best_auc[0]} ({best_auc[6]:.3f})")

# 保存结果
import json as _json
out = {
    "n": len(y), "ji": n_ji, "xiong": n_xiong,
    "baseline_always_xiong": {"acc": base_acc, "ji_recall": 0.0},
    "results": [
        {"model": n, "acc": a, "ji_recall": rj, "xiong_recall": rx, "ji_precision": pj, "f1_ji": f1, "auc": auc}
        for n, a, rj, rx, pj, f1, auc in rows
    ],
}
with open("engine/_imbalance_train_results.json", "w", encoding="utf-8") as f:
    _json.dump(out, f, ensure_ascii=False, indent=1)
print("\n已保存 engine/_imbalance_train_results.json")
