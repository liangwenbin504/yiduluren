# -*- coding: utf-8 -*-
"""探针 A/B：同一批164真实案，对比「课体/毕法特征 关」(基线,读honest_baseline.json) vs 「开」(补特征)。
只跑「开」一遍(约3分钟)，基线从已算好的 honest_baseline.json 读取，避免重复 1312 次预测。
"""
import json
import sys
from collections import Counter
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import set_enabled, set_text_enabled, set_derive_enabled, set_shen_sha_enabled
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")
METHODS = ["M1", "M2", "M3", "M4"]


def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2:
        return None
    if c.get("label") not in ("吉", "凶", "平"):
        return None
    return {
        "id": c.get("case_id", ""),
        "name": c.get("name", ""),
        "category": c.get("zhanlei", "其他"),
        "rizhu": rz,
        "yue_jiang": c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
        "shichen": c["shichen"] if c.get("shichen") in VALID else "",
        "sanchuan": sc,
        "keti": [],
        "duanyu": c.get("duanyu", ""),
        "label": c["label"],
        "label_confidence": c.get("label_conf", 0),
    }


cases = [build_clean(c) for c in REAL]
cases = [x for x in cases if x]
print(f"有效真实案: {len(cases)}")


def run_all():
    stats = {m: {"n": 0, "correct": 0, "cm": Counter(), "by_cat": {}} for m in METHODS}
    for i, clean in enumerate(cases):
        if i % 40 == 0:
            print(f"  进度 {i}/{len(cases)}")
        truth = clean["label"]
        for m in METHODS:
            try:
                p = predict_ancient_case(clean, m).get("prediction", "")
            except Exception:
                continue
            ok = (p == truth)
            s = stats[m]
            s["n"] += 1
            if ok:
                s["correct"] += 1
            s["cm"][f"{truth}->{p}"] += 1
            d = s["by_cat"].setdefault(clean["category"], {"n": 0, "c": 0})
            d["n"] += 1
            if ok:
                d["c"] += 1
    return stats


def run_variant(text_on, derive_on, label):
    set_enabled(True)
    set_text_enabled(text_on)
    set_derive_enabled(derive_on)
    print(f"\n=== 变体：{label} 运行中... ===")
    stats = run_all()
    s = stats["M3"]
    print(f"  M3 = {s['correct']/s['n']*100:.1f}%  ({s['correct']}/{s['n']})  {dict(s['cm'])}")
    return stats


hb = json.load(open("engine/honest_baseline.json", encoding="utf-8"))
print(f"\n基线 M3(特征关, honest_baseline) = {hb['all_real_M3']*100:.1f}%  {hb['all_real_confusion_M3']}")
print(f"朴素基准(永远猜凶) = 83.6%")

v_both = run_variant(True, True, "文本锚定 + 确定性推导(全开)")
v_derive = run_variant(False, True, "仅确定性推导(无泄漏, 真实可部署)")
v_text = run_variant(True, False, "仅文本锚定(含事后解释泄漏)")

# ---- 神煞/八杀 消融：仅推导(DERIVE=True, TEXT=False) + 神煞开 vs 关 ----
set_enabled(True); set_text_enabled(False); set_derive_enabled(True)
set_shen_sha_enabled(False)
print(f"\n=== 消融：仅推导(神煞关) 运行中... ===")
s_noss = run_all()["M3"]
set_shen_sha_enabled(True)
print(f"  仅推导·神煞关 = {s_noss['correct']/s_noss['n']*100:.1f}%  {dict(s_noss['cm'])}")
print(f"  仅推导·神煞开 = {v_derive['M3']['correct']/v_derive['M3']['n']*100:.1f}%  {dict(v_derive['M3']['cm'])}")

nm = v_both["M3"]
print("\n=== 三路分解 M3 对比 ===")
print(f"  文本+推导 = {v_both['M3']['correct']/v_both['M3']['n']*100:.1f}%")
print(f"  仅推导    = {v_derive['M3']['correct']/v_derive['M3']['n']*100:.1f}%")
print(f"  仅文本    = {v_text['M3']['correct']/v_text['M3']['n']*100:.1f}%")
print(f"  基线(关)  = {hb['all_real_M3']*100:.1f}%")
print(f"  仅推导·神煞关 = {s_noss['correct']/s_noss['n']*100:.1f}%  (隔离神煞/八杀贡献)")

print("\n=== 全开后 M3 各类别 ===")
for cat in sorted(nm["by_cat"], key=lambda k: -nm["by_cat"][k]["n"]):
    d = nm["by_cat"][cat]
    if d["n"] >= 3:
        print(f"   {cat:<8} {d['c']/d['n']*100:>5.1f}%  ({d['c']}/{d['n']})")

out = {
    "n": len(cases),
    "baseline_M3": hb["all_real_M3"],
    "naive_always_xiong": 0.836,
    "variant_M3": {
        "both": v_both["M3"]['correct']/v_both["M3"]['n'],
        "derive_only": v_derive["M3"]['correct']/v_derive["M3"]['n'],
        "text_only": v_text["M3"]['correct']/v_text["M3"]['n'],
        "derive_only_shen_sha_off": s_noss['correct']/s_noss['n'],
    },
    "baseline_cm_M3": hb["all_real_confusion_M3"],
    "both_cm_M3": dict(v_both["M3"]['cm']),
    "derive_only_cm_M3": dict(v_derive["M3"]['cm']),
    "derive_only_shen_sha_off_cm_M3": dict(s_noss['cm']),
    "text_only_cm_M3": dict(v_text["M3"]['cm']),
    "both_by_cat_M3": {k: {"n": v["n"], "acc": v["c"]/v["n"]}
                        for k, v in nm["by_cat"].items() if v["n"] >= 3},
    # 部署态(仅推导·无泄漏)分占类 —— 注意：文本锚定(text)开启反而拖累弱类，故以推导态为准
    "derive_only_by_cat_M3": {k: {"n": v["n"], "acc": v["c"]/v["n"]}
                              for k, v in v_derive["M3"]["by_cat"].items() if v["n"] >= 3},
}
json.dump(out, open("engine/probe_feature_result.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
print("\n✅ 结果已保存 engine/probe_feature_result.json")
