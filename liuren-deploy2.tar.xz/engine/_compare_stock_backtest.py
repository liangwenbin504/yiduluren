# -*- coding: utf-8 -*-
"""股票域诚实回测 · A/B 对比 + 朴素基线 + 覆盖率
================================================
把 A'(clean) / B'(stockval) 的 M1-M4 与朴素基线（永远猜涨=1-base_down）
做诚实对比：
  - 与 50% 掷硬币比（regime_backtest 自带 p_value）
  - 与 55.3% 朴素基线比（单侧：是否显著优于基线；双侧：偏离基线的显著度）
  - 覆盖率：每日 stock valence 三分量理论触发占比
"""
import os, sys, json, math
sys.path.insert(0, ".")
import regime_backtest as rb
from liuren_20d_engine import get_liuren_20d_signal
from engine.stock_liuren_features import extract_stock_valence

REPO = os.path.dirname(os.path.abspath("."))
TAGS = ("clean", "stockval")
reports = {t: json.load(open(f"engine/regime_backtest_{t}.json", encoding="utf-8")) for t in TAGS}

base_down = reports["clean"]["base_down_rate"]
NAIVE_UP = 1.0 - base_down          # 永远猜涨 的准确率
n_valid = reports["clean"]["n_valid"]

def wilson(k, n, z=1.96):
    if n == 0: return (0.0, 0.0)
    p = k / n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d
    h = (z*math.sqrt(p*(1-p)/n + z*z/(4*n*n)))/d
    return (max(0.0, c-h), min(1.0, c+h))

def binom_p(k, n, p0):
    """双侧二项检验 H0: p=p0（正态近似）"""
    if n == 0: return 1.0
    se = math.sqrt(n*p0*(1-p0))
    if se == 0: return 1.0
    z = (k - n*p0)/se
    return math.erfc(abs(z)/math.sqrt(2))

# ---- 朴素基线自身 ----
naive_correct = sum(1 for r in (reports["clean"]["overall"] and []) )  # placeholder
# 用真实 actual 统计 UP 天数（两变体 actual 相同）
series = rb.parse_index()
actual_up = sum(1 for d,(o,c) in series if c > o)
naive_correct = actual_up
naive_acc = naive_correct / n_valid
naive_lo, naive_hi = wilson(naive_correct, n_valid)
print(f"朴素基线（永远猜涨）: acc={naive_acc:.2%}  CI=[{naive_lo:.2%},{naive_hi:.2%}]  "
      f"correct={naive_correct}/{n_valid}  base_down={base_down:.4f}")

print("\n=== A/B 对比（vs 50% 与 vs 55.3% 朴素基线）===")
print(f"{'variant':8s} {'method':4s} {'cov':>5s} {'acc':>7s} {'CI95':>16s} "
      f"{'p_vs50':>7s} {'excess_vs53':>11s} {'p_vsNaive':>9s} {'downbias':>8s}")
for t in TAGS:
    o = reports[t]["overall"]
    label = "A'(clean)" if t == "clean" else "B'(stockval)"
    for mk in ("M1","M2","M3","M4"):
        m = o[mk]
        committed = m["committed"]; correct = m["correct"]
        acc = m["accuracy"]
        excess = acc - NAIVE_UP
        p_naive = binom_p(correct, committed, NAIVE_UP)   # 双侧：偏离基线
        print(f"{label:8s} {mk:4s} {m['coverage']:5.1%} {acc:7.2%} "
              f"[{m['ci95'][0]:.2%},{m['ci95'][1]:.2%}] {m['p_value']:7.3f} "
              f"{excess:+11.2%} {p_naive:9.3f} {m['down_bias']:8.1%}")

# ---- 覆盖率：每日 stock valence 理论触发 ----
print("\n=== stock valence 覆盖率（全 5239 日理论触发）===")
comp = {"ba_sha":0, "shen_sha":0, "qiucai":0}
total = 0
for i,(date,(op,cl)) in enumerate(series):
    try:
        r = get_liuren_20d_signal(date, "午")
        sv = extract_stock_valence(r)
        for k in comp:
            if (sv.get("stock_"+k) or 0) != 0:
                comp[k] += 1
        total += 1
    except Exception:
        pass
print(f"有效日={total}")
for k in comp:
    print(f"  stock_{k:8s} 触发 {comp[k]:5d} / {total} = {comp[k]/total:.1%}")
