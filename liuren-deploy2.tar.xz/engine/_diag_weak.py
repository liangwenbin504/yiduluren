# -*- coding: utf-8 -*-
"""弱类诊断：对 求财/出行/胎产 三类，逐案打印 真值/预测/关键信号，定位错误模式。"""
import json
import sys
sys.path.insert(0, ".")
from engine.liuren_keti_bifa import set_enabled, set_text_enabled, set_derive_enabled, set_shen_sha_enabled
from engine.ancient_backtest import build_result_from_ancient, fuse

set_enabled(True); set_text_enabled(False); set_derive_enabled(True); set_shen_sha_enabled(True)

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")

def build_clean(c):
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2:
        return None
    if c.get("label") not in ("吉", "凶", "平"):
        return None
    return {
        "id": c.get("case_id", ""), "name": c.get("name", ""),
        "category": c.get("zhanlei", "其他"), "rizhu": rz,
        "yue_jiang": c["yue_jiang"] if c.get("yue_jiang") in VALID else "",
        "shichen": c["shichen"] if c.get("shichen") in VALID else "",
        "sanchuan": sc, "keti": [], "duanyu": c.get("duanyu", ""),
        "label": c["label"], "label_confidence": c.get("label_conf", 0),
    }

cases = [x for x in (build_clean(c) for c in REAL) if x]
print(f"有效真实案: {len(cases)}")

TARGET = {"求财", "出行", "胎产"}
for cat in ["求财", "出行", "胎产"]:
    sub = [x for x in cases if x["category"] == cat]
    print(f"\n========== {cat} (n={len(sub)}) ==========")
    cc = 0
    for x in sub:
        result = build_result_from_ancient(x)
        fused = fuse(result)
        truth = x["label"]
        pred = {"看涨": "吉", "看跌": "凶", "平": "平", "震荡": "平"}.get(fused.get("trend", "平"), "平")
        ok = (pred == truth)
        cc += 1 if ok else 0
        a = result.get("analysis", {})
        ba = a.get("_shen_sha_valence", {}).get("ba_sha", {})
        ss = a.get("_shen_sha_valence", {}).get("shen_sha", {})
        keti = a.get("keti_duanyu", {}).get("level", "?")
        sigs = " | ".join(fused.get("active_signals", []))
        mark = "✓" if ok else "✗"
        print(f"[{mark}] {x['name'][:6]:<6} 真={truth} 预={pred} KETI={keti} 八杀={ba.get('score')}({','.join(ba.get('details',[]))}) 神煞={ss.get('score')}({','.join(ss.get('details',[]))})")
        print(f"      信号: {sigs}")
    print(f"  >>> {cat} 准确率 = {cc}/{len(sub)} = {cc/len(sub)*100:.1f}%")
