# -*- coding: utf-8 -*-
"""批量探测 v3：精确书名逐本搜索 → 从卡片 href 直取 bookId → 试 reader 判断可读性
- 相比 v2：不遍历宽词卡片、不点击拿 id，改为精确搜 + 读 <a class="wr_bookList_item_link"> href
- 复用 _weread_profile2 登录态（会员）
"""
import asyncio, os, re, json
from urllib.parse import quote

PROFILE = os.path.abspath('_weread_profile2')
OUT = '_weread_books_probe.json'

# 目标书目（来自 08-17 书目探测 + 日志清单）
BOOKS = [
    "大六壬通解", "大六壬毕法赋", "六壬断案", "大六壬指南", "大六壬心镜",
    "图解六壬大全", "六壬大全", "六壬粹言", "六壬经纬", "景祐六壬神定经",
    "壬学琐记", "大六壬管辂神书", "大六壬苗公射覆鬼撮脚", "大六壬翠雨歌",
    "御定六壬", "六壬兵占", "六壬军帐赋", "六壬拃河棹", "太上六壬明鉴符阴经",
    "大六壬指南揭秘", "六壬论命秘要", "大六壬择日探索", "壬占汇选",
]


def norm(s):
    return re.sub(r'[\s\u3000·《》]', '', s or '')


async def search_book(page, name):
    """精确搜索书名，返回 (title, author, bookId) 或 None"""
    url = f'https://weread.qq.com/web/search/books?keyword={quote(name)}'
    try:
        await page.goto(url, wait_until='domcontentloaded', timeout=30000)
        await page.wait_for_timeout(3500)
        items = page.locator('li.wr_bookList_item')
        n = await items.count()
        if n == 0:
            return None
        # 遍历前 8 个卡片，找 title 精确匹配；否则取第一个包含书名的
        candidates = []
        for i in range(min(n, 8)):
            try:
                el = items.nth(i)
                title = (await el.locator('p.wr_bookList_item_title').inner_text()).strip()
                href = await el.locator('a.wr_bookList_item_link').get_attribute('href')
                author = ''
                try:
                    author = (await el.locator('p.wr_bookList_item_author').inner_text()).strip()
                except Exception:
                    pass
                m = re.search(r'/web/reader/([0-9a-zA-Z]+)', href or '')
                if m:
                    candidates.append((title, author, m.group(1)))
            except Exception:
                continue
        if not candidates:
            return None
        # 精确匹配优先
        for t, a, bid in candidates:
            if norm(t) == norm(name):
                return (t, a, bid)
        # 兜底：标题包含书名
        for t, a, bid in candidates:
            if norm(name) in norm(t) or norm(t) in norm(name):
                return (t, a, bid)
        return None
    except Exception as e:
        return f'ERR:{str(e)[:30]}'


async def check_reader(page, name, bid):
    """试读 reader，判断状态"""
    try:
        await page.goto(f'https://weread.qq.com/web/reader/{bid}',
                        wait_until='domcontentloaded', timeout=25000)
        await page.wait_for_timeout(4000)
        has_canvas = await page.evaluate('() => !!document.querySelector("canvas")')
        text = await page.evaluate('() => document.body.innerText')
        if has_canvas:
            # 进一步确认不是空白 canvas（下架页也可能有 canvas）
            if ('下架' in text and '不再支持' in text):
                return '已下架'
            return '可读(canvas)'
        if '下架' in text and ('不再支持' in text or '无法' in text or '不提供' in text):
            return '已下架'
        if '购买' in text or '阅饼' in text or '充值' in text or '付费' in text:
            return '需购买'
        if '404' in text or 'Not Found' in text or '不存在' in text:
            return '404'
        if '试读' in text and ('登录' in text or '会员' in text or '加入书架' in text):
            return '可试读'
        return '其他(需人工)'
    except Exception as e:
        return f'异常:{str(e)[:25]}'


async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE, channel='msedge', headless=True,
            viewport={'width': 1440, 'height': 1000})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        results = []
        for name in BOOKS:
            print(f'[{name}] 搜索...', flush=True)
            hit = await search_book(page, name)
            if hit is None:
                print(f'    无结果')
                results.append({'书名': name, '作者': '', 'bookId': '', '状态': '无结果'})
                continue
            if isinstance(hit, str) and hit.startswith('ERR'):
                print(f'    {hit}')
                results.append({'书名': name, '作者': '', 'bookId': '', '状态': hit})
                continue
            title, author, bid = hit
            status = await check_reader(page, name, bid)
            print(f'    → {title} / {author} / {bid} / {status}')
            results.append({'书名': name, '匹配名': title, '作者': author,
                            'bookId': bid, '状态': status})

        await ctx.close()

        # 汇总
        ok = [r for r in results if '可读' in str(r['状态']) or '试读' in str(r['状态'])]
        gone = [r for r in results if '下架' in str(r['状态']) or '404' in str(r['状态'])]
        pay = [r for r in results if '购买' in str(r['状态'])]
        none = [r for r in results if '无结果' in str(r['状态'])]
        other = [r for r in results if r not in ok + gone + pay + none]
        print('\n========== 汇总 ==========')
        print(f'可读 {len(ok)} 本:')
        for r in ok:
            print(f"  ✓ {r['书名']} ({r['bookId']}) [{r['状态']}]")
        print(f'需购买 {len(pay)} 本:')
        for r in pay:
            print(f"  $ {r['书名']} ({r['bookId']})")
        print(f'下架/404 {len(gone)} 本:')
        for r in gone:
            print(f"  ✗ {r['书名']} ({r['状态']})")
        print(f'无结果 {len(none)} 本:')
        for r in none:
            print(f"  ? {r['书名']}")
        print(f'其他 {len(other)} 本:')
        for r in other:
            print(f"  ~ {r['书名']} ({r['状态']})")

        with open(OUT, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=1)
        print(f'\n已落盘 {OUT}')


asyncio.run(main())
