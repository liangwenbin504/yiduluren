# -*- coding: utf-8 -*-
"""九宗门课体校验：原文九宗门 vs 引擎重算"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    data = json.load(f)
with open('extracted_data/_guji_fetch/大六壬指南_卷三_案例.json', encoding='utf-8') as f:
    raw = json.load(f)
raw_map = {c['章节'] + c['编号']: c for c in raw}

from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
ssc = SiKeSanChuanCalculator2()

# 九宗门词表（原文课体里出现的）
JZM = ['元首','重审','知一','比用','涉害','见机','察微','遥克','蒿矢','弹射',
       '昴星','别责','八专','伏吟','反吟']
# 原文课体名 → 九宗门名
def to_jzm(lst):
    out = set()
    for k in lst:
        if k in ('蒿矢','弹射'): out.add('遥克')
        elif k in ('见机','察微'): out.add('涉害')
        elif k == '比用': out.add('知一')
        elif k in JZM: out.add(k)
    return out

match = 0
n_jzm = 0
mismatch = []
for c in data['cases']:
    raw_c = raw_map.get(c['name'], {})
    orig_jzm = to_jzm(raw_c.get('课体', []))
    if not orig_jzm:
        continue
    n_jzm += 1
    try:
        calc = ssc.calculate(c['ri_gan'], c['ri_zhi'], c['yue_jiang'], c['shichen'])
        eng = calc['sanchuan'].get('课体','').replace('课','')
        # 引擎课体名可能带"格"（如"见机格"）
        eng = eng.replace('格','')
        # 引擎"遥克"可能叫"蒿矢/弹射"？转回
        if eng == '遥克': eng = '遥克'
    except Exception:
        eng = '?'
    if orig_jzm & {eng}:
        match += 1
    else:
        mismatch.append((c['id'], sorted(orig_jzm), eng))

print(f'原文含九宗门课体 {n_jzm} 案 | 一致 {match} ({match/n_jzm*100:.0f}%)')
print(f'不一致 {len(mismatch)}:')
for cid, o, e in mismatch[:30]:
    print(f'  {cid}: 原文九宗门{o} vs 引擎[{e}]')
