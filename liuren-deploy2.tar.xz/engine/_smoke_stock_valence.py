# -*- coding: utf-8 -*-
"""股票域特征库接线冒烟测试：验证 extract_stock_valence 在真实股票盘面上能产出非零点，
且 collect_signals 把 stock_* 信号注入融合。"""
import os
import sys
_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO not in sys.path:
    sys.path.insert(0, _REPO)  # 仓库根，确保 engine 包可导入（不依赖 cwd）
os.environ['DISABLE_CAISHEN'] = '1'   # 关掉有害看涨注入，干净测试
# DISABLE_STOCK_VALENCE 不设 → 股票特征 ON

from liuren_20d_engine import get_liuren_20d_signal
from engine.stock_liuren_features import extract_stock_valence

dates = ['2024-01-02', '2023-06-15', '2020-02-03', '2015-07-09', '2008-10-28']
print(f"{'日期':<12} {'_is_stock':<9} {'八杀':>5} {'神煞':>5} {'求财':>5} {'合计':>5}  ba_sha有八杀明细  触发")
nz = 0
for d in dates:
    r = get_liuren_20d_signal(d, "午")
    a = r.get('analysis', {})
    ba = a.get('ba_sha', {}) or {}
    has_mingxi = '八杀明细' in ba
    sv = extract_stock_valence(r)
    ba_s, sha_s, qc_s = sv['stock_ba_sha'], sv['stock_shen_sha'], sv['stock_qiucai']
    nonzero = (ba_s != 0 or sha_s != 0 or qc_s != 0)
    if nonzero:
        nz += 1
    print(f"{d:<12} {str(a.get('_is_stock')):<9} {ba_s:>5} {sha_s:>5} {qc_s:>5} {sv['score']:>5}  {str(has_mingxi):<10}  {sv['fired']}")
    if sv['details']:
        print("        details:", " | ".join(sv['details'])[:160])

print(f"\n非零 valence 样本: {nz}/{len(dates)}")

# 验证融合层是否注入了 stock 信号
r0 = get_liuren_20d_signal('2024-01-02', "午")
fj = r0.get('fused_judgment', {})
reasons = fj.get('reasons', []) if isinstance(fj, dict) else []
stock_reasons = [x for x in reasons if 'stock' in str(x).lower() or '八杀' in str(x) or '神煞' in str(x) or '求财' in str(x)]
print(f"\n融合层 reasons 中含 stock/八杀/神煞/求财 的条数: {len(stock_reasons)}")
for s in stock_reasons[:6]:
    print("   -", str(s)[:120])
