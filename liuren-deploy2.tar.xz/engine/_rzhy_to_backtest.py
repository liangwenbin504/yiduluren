# -*- coding: utf-8 -*-
"""壬占汇选 166 案 → ancient_backtest 评估格式 v2
三传策略：sanchuan 字段权威（v2 三传自洽 94.8% 已验证）；2 元素时从 case_text 首个六亲行补初传
"""
import json, re

SRC = 'extracted_data/壬占汇选_训练数据_v2.json'
LABELED = 'extracted_data/_guji_fetch/壬占汇选_案例_labeled.json'
OUT = 'engine/ancient_truth_labels_rzhy.json'

CAT_RULES = [
    (('病',), '疾病'),
    (('会试', '前程', '功名', '乡试', '秋试', '省试', '应试', '试', '科', '释褐', '科举'), '功名'),
    (('宅', '风水'), '家宅'),
    (('讼', '官事'), '官讼'),
    (('生产', '胎', '产'), '胎产'),
    (('婚姻', '婚'), '婚姻'),
    (('失', '走失', '寻', '捕'), '走失'),
    (('求财', '财', '店', '交易', '弃产', '盐', '窝'), '求财'),
]
DEFAULT_CAT = '其他'

ZHI = set('子丑寅卯辰巳午未申酉戌亥')
def zhi_only(x):
    return [c for c in x if c in ZHI]

def to_category(q):
    for kws, cat in CAT_RULES:
        if any(k in q for k in kws):
            return cat
    return DEFAULT_CAT

# 首个六亲行（初传）：六亲 + [干]支 + 天将
FIRST_LQ = re.compile(r'[财官父兄子][ 　]*[甲乙丙丁戊己庚辛壬癸]?([子丑寅卯辰巳午未申酉戌亥])[ 　]*[贵蛇朱六勾青龙空虎常玄阴后]')

with open(SRC, encoding='utf-8') as f:
    v2 = json.load(f)
with open(LABELED, encoding='utf-8') as f:
    cands = json.load(f)

def build_sanchuan(c):
    """优先 sanchuan 字段，2元素补初传（首个六亲行）"""
    v2c = v2[c['idx']]
    orig = v2c.get('sanchuan') or []
    orig_zhi = [z for s in orig for z in zhi_only(s)]
    if len(orig_zhi) >= 3:
        return orig_zhi[:3], 'sanchuan字段'
    # 缺初传：从 case_text 取首个六亲行地支
    m = FIRST_LQ.search(c.get('case_text', ''))
    if m:
        return [m.group(1)] + orig_zhi[:2], f'补初传({m.group(1)})+字段{orig_zhi}'
    return orig_zhi[:3] if orig_zhi else [], '字段不全'

out = []
n_src = {'sanchuan字段': 0, '补初传': 0, '字段不全': 0}
for c in cands:
    if c['label'] not in ('吉', '凶'):
        continue
    rz = c['ganzhi']
    sc, src = build_sanchuan(c)
    n_src[src if '字段' in src else ('补初传' if src.startswith('补') else src)] = n_src.get(src, 0) + 1
    if len(sc) < 3:
        continue
    out.append({
        'source': 'RZHY_Vol', 'id': f"RZ-{rz}-{c['yuejiang']}-{c['shichen']}",
        'name': f"{rz}{c['yuejiang']}将{c['shichen']}时",
        'question': c['question'],
        'category': to_category(c['question']),
        'ri_gan': rz[0], 'ri_zhi': rz[1], 'rizhu': rz,
        'yue_jiang': c['yuejiang'], 'shichen': c['shichen'],
        'keti': [], 'sanchuan': sc, 'era': '古代',
        'label': c['label'], 'label_confidence': 0.85,
        'label_evidence': c.get('label_ev', ''),
        'interpretation': c['case_text'][:300],
    })

json.dump({'cases': out}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
from collections import Counter
print(f'生成 {OUT}: {len(out)} 案')
print('三传来源:', dict(Counter(x['sanchuan'] for x in out)) if False else n_src)
print('category:', dict(Counter(x['category'] for x in out)))
print('label:', dict(Counter(x['label'] for x in out)))
