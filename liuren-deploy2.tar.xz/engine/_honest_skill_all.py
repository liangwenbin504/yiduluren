# -*- coding: utf-8 -*-
"""诚实技能测试(全集)：直接对 219 例真实疏正案(日辰/月将/时辰/三传均来自PDF)跑引擎，
与真实结局比对。这是唯一不受 Corpus B 损坏污染的真值基线。
"""
import json
import sys
from collections import Counter
sys.path.insert(0, ".")
from engine.ancient_backtest import predict_ancient_case

REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
methods = ["M1", "M2", "M3", "M4"]
stats = {m: {"n": 0, "correct": 0, "skip": 0, "cm": Counter(),
             "by_cat": {}} for m in methods}
valid_dist = Counter()  # 仅统计有效案例(与 M3 分母一致)的结局分布，用于朴素基准

VALID = set("子丑寅卯辰巳午未申酉戌亥")


def ok_yj(x):
    return isinstance(x, str) and x in VALID


for c in REAL:
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rizhu = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rizhu or len(rizhu) < 2:
        for m in methods:
            stats[m]["skip"] += 1
        continue
    truth = c.get("label", "")
    if truth not in ("吉", "凶", "平"):
        for m in methods:
            stats[m]["skip"] += 1
        continue
    clean = {
        "id": c["case_id"],
        "name": c.get("name", ""),
        "category": c.get("zhanlei", "其他"),
        "rizhu": rizhu,
        "yue_jiang": c["yue_jiang"] if ok_yj(c.get("yue_jiang")) else "",
        "shichen": c["shichen"] if ok_yj(c.get("shichen")) else "",
        "sanchuan": sc,
        "keti": [],
        "label": truth,
        "label_confidence": c.get("label_conf", 0),
        "month": c.get("month"),
        "ben_ming_zhi": c.get("ben_ming_zhi"),
        "year": c.get("year") or "",
        "leishen": c.get("leishen", ""),
    }
    valid_dist[truth] += 1
    for m in methods:
        try:
            pred = predict_ancient_case(clean, m)
            p = pred.get("prediction", "")
            ok = (p == truth)
            stats[m]["n"] += 1
            if ok:
                stats[m]["correct"] += 1
            stats[m]["cm"][f"{truth}->{p}"] += 1
            cat = clean["category"]
            d = stats[m]["by_cat"].setdefault(cat, {"n": 0, "c": 0})
            d["n"] += 1
            if ok:
                d["c"] += 1
        except Exception:
            stats[m]["skip"] += 1

print("=== 诚实技能测试(全集)：219 真实疏正案，引擎输入+标签均来自PDF ===")
for m in methods:
    s = stats[m]
    acc = s["correct"] / s["n"] if s["n"] else 0
    print(f"  {m}: 准确率={acc*100:.1f}%  (正确{s['correct']}/{s['n']}, 跳过{s['skip']})")
    print(f"       混淆={dict(s['cm'])}")

print("\n=== M3 各类别(真实案) ===")
bc = stats["M3"]["by_cat"]
for cat in sorted(bc, key=lambda k: -bc[k]["n"]):
    d = bc[cat]
    if d["n"] >= 3:
        print(f"   {cat:<8} {d['c']/d['n']*100:>5.1f}%  ({d['c']}/{d['n']})")

# 基准率（仅有效案例，与 M3 分母 n=164 对齐）
from collections import Counter as C
dist = valid_dist
print(f"\n真实结局分布(有效164例): {dict(dist)}  -> 永远猜'凶'的准确率={dist.get('凶',0)/sum(dist.values())*100:.1f}%")

print("\n=== 三层对比 ===")
print("  全 Corpus B (损坏输入+循环标签): M3 ≈ 62.0%  [不可信]")
print("  仅修标签 (输入仍损坏):           M3 ≈ 55.9%  [不可信]")
m3 = stats["M3"]
print(f"  真实输入+真实标签 (本全集测试):  M3 ≈ {m3['correct']/m3['n']*100:.1f}%  (n={m3['n']})  [可信]")
