# -*- coding: utf-8 -*-
"""导出待标注案例清单（按章节分组，含完整正文）"""
import json, re

SRC = 'extracted_data/_guji_fetch/大六壬指南_卷三_案例.json'
OUT = 'extracted_data/_guji_fetch/待标注_清单.txt'

with open(SRC, encoding='utf-8') as f:
    cases = json.load(f)

# 有完整 日干支+月+时 的案例
full = [c for c in cases if c['日干支'] and c['月'] and c['时辰']]
print(f'可标注案例: {len(full)}')

# 按章节分组输出
from collections import OrderedDict
groups = OrderedDict()
for c in full:
    groups.setdefault(c['章节'], []).append(c)

lines = []
for ch, clist in groups.items():
    lines.append(f'\n{"="*60}\n【{ch}】{len(clist)}案\n{"="*60}')
    for c in clist:
        lines.append(f"\n--- {ch}/{c['编号']} | 年={c['年']} 月={c['月']} 日={c['日干支']} 时={c['时辰']} 课体={c['课体']} ---")
        # 正文完整
        body = c['正文'].replace('\n', '')
        lines.append(body)
        lines.append(f"【断语】{c['断语']}")

with open(OUT, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print(f'已导出 {OUT}')
# 打印章节分布
for ch, clist in groups.items():
    print(f'  {ch}: {len(clist)}')
