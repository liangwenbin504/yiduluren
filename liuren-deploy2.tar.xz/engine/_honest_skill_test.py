# -*- coding: utf-8 -*-
"""诚实技能测试：用从 PDF 抽取的真实案数据(日辰/月将/时辰/三传)作为引擎输入，
对 46 例高置信对齐(标签+输入均已验证)跑引擎，得到无数据污染的技能估计。
对比：
  - 全 Corpus B(损坏输入+循环标签): M3=62.0%
  - 仅修标签(输入仍损坏):          M3=55.9%
  - 本测试(输入+标签均真实):        M3=?
"""
import json
import sys
from collections import Counter
sys.path.insert(0, ".")
from engine.ancient_backtest import predict_ancient_case

RM = json.load(open("engine/corpusB_relabel_map.json", encoding="utf-8"))
REAL = {c["case_id"]: c for c in json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))}

rel = RM["reliable"]
methods = ["M1", "M2", "M3", "M4"]
stats = {m: {"n": 0, "correct": 0, "skip": 0, "cm": Counter()} for m in methods}
rows = []

for r in rel:
    cid = r["id"]
    real = REAL.get(r["real_case_id"])
    if not real:
        continue
    sc = real.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    if len(sc) < 3:
        for m in methods:
            stats[m]["skip"] += 1
        continue
    yj = real.get("yue_jiang", "")
    sc2 = real.get("shichen", "")
    clean = {
        "id": cid,
        "name": real.get("name", ""),
        "category": r["syn_zl"],
        "rizhu": real.get("day_ganzhi", ""),
        "yue_jiang": yj if yj not in ("天", "", None) else "",
        "shichen": sc2 if sc2 not in ("天", "", None) else "",
        "sanchuan": sc,
        "keti": [],
        "label": real.get("label", ""),
        "label_confidence": real.get("label_conf", 0),
    }
    if not clean["rizhu"] or len(clean["rizhu"]) < 2:
        for m in methods:
            stats[m]["skip"] += 1
        continue
    truth = clean["label"]
    for m in methods:
        try:
            pred = predict_ancient_case(clean, m)
            p = pred.get("prediction", "")
            ok = (p == truth)
            stats[m]["n"] += 1
            if ok:
                stats[m]["correct"] += 1
            stats[m]["cm"][f"{truth}->{p}"] += 1
            if m == "M3":
                rows.append((cid, r["syn_zl"], truth, p, "✓" if ok else "✗",
                             r["real_case_id"], r["match_basis"]))
        except Exception as e:
            stats[m]["skip"] += 1

print("=== 诚实技能测试：46 例高置信(输入+标签均来自真实疏正案) ===")
for m in methods:
    s = stats[m]
    acc = s["correct"] / s["n"] if s["n"] else 0
    print(f"  {m}: 准确率={acc*100:.1f}%  (正确{s['correct']}/{s['n']}, 跳过{s['skip']})  混淆={dict(s['cm'])}")

print("\n=== M3 逐例(输入真实) ===")
for row in rows:
    print(f"  {row[0]:8} [{row[1]}] 真={row[2]} 引擎={row[3]} {row[4]}  源={row[5]}({row[6]})")

# 与损坏基线对比
print("\n=== 三层对比 ===")
print("  全 Corpus B (损坏输入+循环标签): M3 ≈ 62.0% (不可信)")
print("  仅修标签 (输入仍损坏):           M3 ≈ 55.9%")
m3 = stats["M3"]
print(f"  真实输入+真实标签 (本测试):      M3 ≈ {m3['correct']/m3['n']*100:.1f}%  (n={m3['n']})")
