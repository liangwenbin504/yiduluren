# -*- coding: utf-8 -*-
"""校验月将换算：原文课体 vs 引擎重算课体（v2 修 name 匹配）"""
import json, sys
from pathlib import Path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

with open('engine/ancient_truth_labels_zhinan_v3.json', encoding='utf-8') as f:
    data = json.load(f)
with open('extracted_data/_guji_fetch/大六壬指南_卷三_案例.json', encoding='utf-8') as f:
    raw = json.load(f)
raw_map = {c['章节'] + c['编号']: c for c in raw}

from engine.sike_sanchuan_engine import SiKeSanChuanCalculator2
ssc = SiKeSanChuanCalculator2()

def norm_keti(lst):
    out = set()
    for k in lst:
        k = k.replace('课','')
        out.add(k)
    return out

match = 0
partial = 0
mismatch = []
noketi = 0
for c in data['cases']:
    raw_c = raw_map.get(c['name'], {})
    orig_keti = norm_keti(raw_c.get('课体', []))
    if not orig_keti:
        noketi += 1
        continue
    try:
        calc = ssc.calculate(c['ri_gan'], c['ri_zhi'], c['yue_jiang'], c['shichen'])
        eng_keti = norm_keti([calc['sanchuan'].get('课体','').replace('课','')])
    except Exception:
        eng_keti = set()
    if orig_keti & eng_keti:
        match += 1
        if not orig_keti <= eng_keti:
            partial += 1
    else:
        mismatch.append((c['id'], raw_c.get('课体'), calc['sanchuan'].get('课体','')))

total = len(data['cases'])
print(f'总案例 {total} | 原文无课体 {noketi} | 有课体 {total-noketi}')
print(f'课体有交集 {match} ({(match/max(total-noketi,1))*100:.0f}%) | 其中完全一致 {match-partial}')
print(f'不一致 {len(mismatch)}:')
for cid, o, e in mismatch[:25]:
    print(f'  {cid}: 原文{o} vs 引擎[{e}]')
