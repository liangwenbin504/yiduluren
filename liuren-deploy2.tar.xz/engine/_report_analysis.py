# -*- coding: utf-8 -*-
"""生成六壬系统详细报告所需的分析数据 -> analysis_export.json"""
import json
from collections import defaultdict, Counter

DETAILS = "engine/ancient_backtest_details.json"
REPORT = "engine/ancient_backtest_report.json"

with open(DETAILS, "r", encoding="utf-8") as f:
    details = json.load(f)
with open(REPORT, "r", encoding="utf-8") as f:
    report = json.load(f)

METHODS = ["M1", "M2", "M3", "M4"]

# 方法总览
method_overview = {}
for m in METHODS:
    s = report["summary"][m]
    method_overview[m] = {
        "total": s["total"],
        "correct": s["correct"],
        "accuracy": round(s["accuracy"] * 100, 2),
        "avg_confidence": round(s["avg_confidence"], 4),
        "confusion_matrix": s["confusion_matrix"],
    }

# 以 M3 为主分析（最佳方法）
m3 = details["results"]["M3"]

cat_stats = defaultdict(lambda: {"total": 0, "correct": 0, "errors": []})
for r in m3:
    cat = r["category"]
    cat_stats[cat]["total"] += 1
    if r["correct"]:
        cat_stats[cat]["correct"] += 1
    else:
        cat_stats[cat]["errors"].append({
            "id": r["id"],
            "name": r["name"],
            "truth": r["truth"],
            "prediction": r["prediction"],
            "confidence": round(r["confidence"], 3),
            "prob_up": round(r["prob_up"], 3),
            "prob_down": round(r["prob_down"], 3),
            "signals": r.get("caishen_signals", []),
        })

# 错误方向统计
cat_direction = {}
for cat, st in cat_stats.items():
    if st["errors"]:
        d = Counter(f'{e["truth"]}->{e["prediction"]}' for e in st["errors"])
        cat_direction[cat] = dict(d)

# 构建逐类报告，按错误数降序，错误数相同按样本量降序
categories = []
for cat, st in cat_stats.items():
    acc = st["correct"] / st["total"] if st["total"] else 0
    categories.append({
        "category": cat,
        "total": st["total"],
        "correct": st["correct"],
        "errors_count": len(st["errors"]),
        "accuracy": round(acc * 100, 2),
        "direction": cat_direction.get(cat, {}),
        "errors": st["errors"],
    })
categories.sort(key=lambda x: (-x["errors_count"], -x["total"]))
# 把准确率为100%且无误的分类放最后（或单独标注）
perfect = [c for c in categories if c["errors_count"] == 0]
with_errors = [c for c in categories if c["errors_count"] > 0]
categories_sorted = with_errors + perfect

# 逐类 M1/M2/M3/M4 准确率对比（用于看方法增益）
cat_method_acc = {}
for cat in cat_stats:
    cat_method_acc[cat] = {}
    for m in METHODS:
        cs = report["summary"][m]["by_category"].get(cat)
        if cs:
            cat_method_acc[cat][m] = round(cs["accuracy"] * 100, 2)

# 求财专项数据（作为模板/参考）
wealth = details["results"]["M3"]
wealth_errors = [r for r in wealth if r["category"] == "求财" and not r["correct"]]
wealth_all = [r for r in wealth if r["category"] == "求财"]

export = {
    "method_overview": method_overview,
    "categories_sorted": categories_sorted,
    "cat_method_acc": cat_method_acc,
    "wealth": {
        "total": len(wealth_all),
        "correct": sum(1 for r in wealth_all if r["correct"]),
        "errors": [{
            "id": r["id"], "name": r["name"], "truth": r["truth"],
            "prediction": r["prediction"], "confidence": round(r["confidence"], 3),
            "prob_up": round(r["prob_up"], 3), "prob_down": round(r["prob_down"], 3),
            "signals": r.get("caishen_signals", []),
        } for r in wealth_errors],
    },
    "total_cases": report["total_cases"],
}

with open("engine/analysis_export.json", "w", encoding="utf-8") as f:
    json.dump(export, f, ensure_ascii=False, indent=2)

# 控制台打印摘要
print("=== 方法总览 ===")
for m, o in method_overview.items():
    print(f"{m}: {o['accuracy']}% ({o['correct']}/{o['total']}) conf={o['avg_confidence']}")
print(f"\n=== 有错误的类别（按错误数降序）: {len(with_errors)} ===")
for c in with_errors:
    print(f"  {c['category']}: {c['correct']}/{c['total']} ({c['accuracy']}%), 错误{c['errors_count']}个, 方向={c['direction']}")
print(f"\n=== 满分类别: {len(perfect)} ===")
for c in perfect:
    print(f"  {c['category']}: {c['correct']}/{c['total']} (100%)")
print(f"\n=== 求财专项: {export['wealth']['correct']}/{export['wealth']['total']} ===")
print("导出完成 -> engine/analysis_export.json")
