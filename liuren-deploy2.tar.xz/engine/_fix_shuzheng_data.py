# -*- coding: utf-8 -*-
"""《断案疏正》案例库修复脚本（2026-08-16 长征第0期）
1) 补全 2 案空缺字段（§天时01·003、§宅墓02·012 的 sanchuan/duanyu，回原文逐字摘录）
2) 删除 10 条提取垃圾记录（case_id/num/干支全坏，label=未知，本就被评估跳过）
3) 追加 sec14 六畜走失 9 案（§六畜走失14·179~187，回原文逐字摘录）
结果：219 -> 218 案，正好完整覆盖全书编号 §天时01·001 ~ §杂占17·218。
label 一律保持/设为「未知」，不进 M3 有效案，不动基线。
"""
import json

PATH = "engine/shuzheng_real_cases.json"
real = json.load(open(PATH, encoding="utf-8"))

# ---------- 1) 补全 2 案 ----------
FIX = {
    "§天时01·003": {
        "sanchuan": ["丑", "戌", "未"],
        "duanyu": "伏吟课，定是今日来时有云，一霎时起大风，又下小雨。明日甲寅，一日大风，下微雨。至乙卯日风止，大雨一日，水暴涨也。盖丑在癸上，即癸丑为初传，而中戌、末未，叠叠刑开，使癸水下注。癸丑纳音属木，木主风，故未时兼有风，是八月十五日也。至十七日乙卯，是大溪水，故大雨水涨。由丑、寅二日，风以动之也。太阴月宿十五日在戌，十六、十七日在酉，乃是月宿离于毕，毕在酉宫也。十七日朱雀加卯，火败于卯，而得月离于毕，故主大雨。雨常附阴而降，以酉为太阴之门，纯阴之位。凡占雨，但用月宿到今日，看临在酉，则是月离于毕也。癸丑纳音木，克乘神勾陈土，土溃而水漏，故一霎时风雨。甲寅乘六合，木盛多风。至十八日丙火辰土，而纳音又土，辰又为八月太阳，上乘螣蛇火神，至是雨霁而晴矣。",
    },
    "§宅墓02·012": {
        "sanchuan": ["酉", "丑", "巳"],
        "duanyu": "此课人盛宅狭，人与宅替；不出四年，必主修造酒房；厨下一婢，酒中死；不要买叔婆之产，必有退悔；又主有三所店，先开二所见财，后开一所主败。宅前不合置淘镬，主八年内淘镬屋下必停丧，是时其家四分矣。郑兄弟十人，共四十余口，未曾分；至辛亥年，公果造酒房；十二月婢盗酒饮，醉死。己酉年与叔婆交易，叔婆有子二人，年幼不曾预名，后果退悔。又丙辰、戊午二年两店兴旺，己未又开淘镬，正对门前，至乙丑二月弟妇死，殡于内。盖谓人盛者，癸日遇巳、酉、丑，八月旺金来生也。宅狭宅替者，丑为宅，值金局而脱气也。丑为八月死气，加于酉婢之上，丑上见巳，巳为厨灶，癸水见酉，乃酒也，故主婢死于酒房厨下。三店者，日上、支上、传上见三个巳，巳为店业。一所败者，癸水绝于巳故也。又巳为锅镬，值癸水乃淘镬也。八年者，双巳四数也。",
    },
}

# ---------- 2) 删除 10 条垃圾记录 ----------
GARBAGE = {
    "§疾病13·1", "§终身04·11", "§宅墓02·01", "§胎产子息07·13",
    "§杂占17·2", "§胎产子息07·1", "§终身04·1", "§财产08·1",
    "§前程仕进03·09", "§前程仕03·098",
}

# ---------- 3) 六畜走失 9 案 ----------
LIUCHU = [
    dict(case_id="§六畜走失14·179", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="179",
         name="吴四公", age=64, day_ganzhi="癸亥", yue_jiang="卯", shichen="辰",
         sanchuan=["戌", "酉", "申"], pdf_page=364, year="己酉",
         duanyu="欲进六畜，而猪、牛栏皆不得其所。戌加亥作白虎，大猪入栏反小，只如犬大，兼且多病死伤。牛临寅地，自是畏乡，岂能长久？要好移栏到长生西南之地，牛、羊、猪皆可养之。宅基皆不利畜，牛、羊、猪、鸡皆无位，至于犬反要咬猪，猫亦不能捕鼠。盖缘天目在宅，宅中有伏尸，所以不荣。五年之内，伏尸必伤人矣。吴宅自造屋十三、四年来，诸畜皆养不得，故占与之。当先宅前一半足田，一半是山，其山有古冢骸骨，不知姓名，吴尽撤去造屋，是以不利。后至甲寅三月，宅中屡现火光，怪异并作。吴记先生断课之误，遂迁别宅居住。大凡占宅，天目加支，多主伏尸。秋以戌为天目，戌数五，故主五年必现影响也。"),
    dict(case_id="§六畜走失14·180", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="180",
         name="王寺丞", age=None, day_ganzhi="丁亥", yue_jiang="戌", shichen="卯",
         sanchuan=["午", "丑", "申"], pdf_page=365, year=None,
         duanyu="其马必被虎伤死矣。五日后兵士报曰：放马山上吃草，被虎所食。盖午为马，乘虎加亥为用，自刑加自刑上，午被亥克，故然。"),
    dict(case_id="§六畜走失14·181", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="181",
         name="遂安官人", age=None, day_ganzhi="壬午", yue_jiang="丑", shichen="卯",
         sanchuan=["寅", "子", "戌"], pdf_page=366, year=None,
         duanyu="此马不见矣。午为马，加申道路之上，正行也。被人骑去矣。果然。"),
    dict(case_id="§六畜走失14·182", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="182",
         name="", age=None, day_ganzhi="丁丑", yue_jiang="亥", shichen="申",
         sanchuan=["午", "戌", "辰"], pdf_page=367, year=None,
         duanyu="马在东方寺院围墙内，不能出。须从一破门进去，寻见在己卯日也。果于二十五日，于东方寺院从轮藏前破门入墙内寻见。盖马属午，作龙为用，类神在传也。破门者，午破卯，卯为门也。墙垣者，四土周围也。"),
    dict(case_id="§六畜走失14·183", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="183",
         name="", age=None, day_ganzhi="戊子", yue_jiang="酉", shichen="寅",
         sanchuan=["子", "未", "寅"], pdf_page=368, year=None,
         duanyu="子作蛇临日为用，主非横事。中、未加子作天空，未，羊也，加子为六害，羊非水物，不宜临子。况上又作天空，是戊戌土，戌刑未，戍为犬，犬伤羊。子，水也，此羊被犬赶入水中。为人宰了，以瓮器盛之，藏在厕中。天空无气为器物，又为污秽。寅加未，虎又啖食之兽，所以伤羊。不出今日须败，果当日捉获。"),
    dict(case_id="§六畜走失14·184", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="184",
         name="", age=None, day_ganzhi="丁未", yue_jiang="未", shichen="未",
         sanchuan=["未", "丑", "戌"], pdf_page=369, year=None,
         duanyu="伏吟课，其羊定在西南，兄弟姊妹亲眷家寻之，今日申时可见。果申时在西南方妻姊家寻见。盖未为羊，上作太阳月将，丁未日又未发用，故在西南。亲眷者，未为眷属者也。伏吟在本位不旺，未乃月将，五月当相气，故不失。"),
    dict(case_id="§六畜走失14·185", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="185",
         name="", age=None, day_ganzhi="己卯", yue_jiang="亥", shichen="未",
         sanchuan=["未", "亥", "卯"], pdf_page=370, year=None,
         duanyu="春占曲直课，未加卯作龙为用，其羊不失。乃走入他人羊群中，信东方寻之必见。果于东方园内羊群中寻见。盖初传是类神，作龙入传，加日辰，故不失。"),
    dict(case_id="§六畜走失14·186", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="186",
         name="", age=None, day_ganzhi="甲辰", yue_jiang="戌", shichen="寅",
         sanchuan=["戌", "午", "寅"], pdf_page=371, year=None,
         duanyu="白狗寻不见矣。盖戌为类神，加日虽主自归，奈何戌与寅虽作三合，又作六合，而寅反作虎，在末传克戌，故寻不得，定被杀了。后知被木排上人杀了。(寅作虎克戌，寅木也。遂应木排上人，奇妙至此。)盖卯为排，夹克戌土故也。"),
    dict(case_id="§六畜走失14·187", zhanlei_code="六畜走失", zhanlei="其他", sec="14", num="187",
         name="", age=None, day_ganzhi="辛亥", yue_jiang="子", shichen="丑",
         sanchuan=["戌", "酉", "申"], pdf_page=372, year=None,
         duanyu="鸡寻不见矣。被犬冲入邻家，一奴便捉去，杀而食之矣。盖戌为用，奴偷也。邻近人家者，酉为刃作虎，申亦是虎，加酉，酉与戌邻故也。酉为鸡，虽类神入传，加日主自归，奈何加戌，阳刃杀上作虎，如何得活？"),
]

# ---------- 执行 ----------
# 1) 补全 2 案
for c in real:
    if c["case_id"] in FIX:
        c.update(FIX[c["case_id"]])

# 2) 删除垃圾
before = len(real)
real = [c for c in real if c["case_id"] not in GARBAGE]
deleted = before - len(real)

# 3) 追加六畜（label 未知，不进基线）
for x in LIUCHU:
    real.append(dict(
        case_id=x["case_id"], zhanlei_code=x["zhanlei_code"], zhanlei=x["zhanlei"],
        sec=x["sec"], num=x["num"], name=x["name"], age=x["age"],
        day_ganzhi=x["day_ganzhi"], yue_jiang=x["yue_jiang"], shichen=x["shichen"],
        sanchuan=x["sanchuan"], duanyu=x["duanyu"],
        label="未知", label_conf=0.0, label_ev="", pdf_page=x["pdf_page"], year=x["year"],
    ))

# 按 sec+num 排序（原书顺序）
real.sort(key=lambda c: (c.get("sec", "99"), c.get("num", "").zfill(3)))

json.dump(real, open(PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print(f"补全 2 案: {list(FIX.keys())}")
print(f"删除垃圾: {deleted} 条")
print(f"追加六畜: {len(LIUCHU)} 案")
print(f"最终案数: {before} -> {len(real)}")
# 验证完整性
secs = {}
for c in real:
    secs.setdefault(c.get("sec"), []).append(c.get("num"))
print("\n各 sec 案数:")
for s in sorted(secs):
    print(f"  sec{s}: {len(secs[s])} 案")
