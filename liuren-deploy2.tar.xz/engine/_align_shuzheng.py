# -*- coding: utf-8 -*-
"""对齐 224 合成 Corpus B 例 <-> 219 真实疏正案，生成重标映射。
输出: engine/corpusB_relabel_map.json
"""
import json
import re
from collections import defaultdict

REAL = json.load(open("engine/shuzheng_real_cases.json", "r", encoding="utf-8"))
SYN = json.load(open("data/daliuren_shuzheng_cases.json", "r", encoding="utf-8"))
LAB = json.load(open("engine/ancient_truth_labels.json", "r", encoding="utf-8"))
# 旧标签（回测实际使用的）按 id 索引
OLD = {c["id"]: c for c in LAB["cases"]}

# 真实案按占类索引
real_by_zl = defaultdict(list)
for c in REAL:
    real_by_zl[c["zhanlei"]].append(c)

GANZHI_PAIRS = None  # 不用

def szl_group(szl):
    for k in SYN_ZL_TO_REAL:
        if k in szl:
            return k
    return "其他"


def score_match(syn, real):
    """返回 (score, reasons)。"""
    s = 0
    reasons = []
    # 占类（已在候选集内，必匹配）
    s += 100
    # 年龄
    sa = syn.get("age")
    ra = real.get("age")
    if sa is not None and ra is not None and sa == ra:
        s += 80
        reasons.append(f"年龄{sa}")
    # 日干支
    sg = (syn.get("ri_gan", "") or "") + (syn.get("ri_zhi", "") or "")
    rg = real.get("day_ganzhi", "") or ""
    if sg and rg and sg == rg:
        s += 60
        reasons.append(f"日干支{sg}")
    elif sg and rg and (sg[0] == rg[0]):
        s += 20
        reasons.append(f"日干同{sg[0]}")
    # 三传重叠
    st = syn.get("sanchuan") or []
    rt = real.get("sanchuan") or []
    if isinstance(st, str):
        st = list(st)
    if st and rt:
        overlap = sum(1 for x in st if x in rt)
        if overlap:
            s += overlap * 15
            reasons.append(f"三传重叠{overlap}")
    # 姓名重叠（取2字以上）
    sn = syn.get("name", "") or ""
    rn = real.get("name", "") or ""
    if sn and rn:
        common = set(sn) & set(rn)
        if len(common) >= 1 and len(sn) >= 2:
            s += 10 * len(common)
            reasons.append(f"姓名共{''.join(common)}")
    return s, reasons

# 占类对齐映射（合成 category -> 真实 zhanlei 组）
SYN_ZL_TO_REAL = {
    "功名": ["功名"], "考试": ["功名"], "疾病": ["疾病"], "病": ["疾病"],
    "家宅": ["家宅"], "宅": ["家宅"], "婚姻": ["婚姻"], "求财": ["求财"],
    "经营": ["求财"], "财": ["求财"], "胎产": ["胎产"], "产": ["胎产"],
    "孕": ["胎产"], "出行": ["出行"], "官讼": ["官讼"], "讼": ["官讼"],
    "走失": ["走失"], "蚕桑": ["蚕桑"], "征战": ["征战"], "寿元": ["寿元"],
    "其他": ["其他"],
}

results = []
unmatched = []
ambiguous = []
for syn in SYN:
    sid = syn.get("id", "")
    szl = syn.get("category", "") or syn.get("question", "")
    # 解析合成 category
    syn_zl = None
    for k, v in SYN_ZL_TO_REAL.items():
        if k in szl:
            syn_zl = v[0]
            break
    if not syn_zl:
        syn_zl = "其他"
    # 候选真实案
    cands = []
    for zl in SYN_ZL_TO_REAL.get(szl_group(szl), ["其他"]):
        cands.extend(real_by_zl.get(zl, []))
    if not cands:
        # 退而求其次：全占类
        cands = real_by_zl.get("其他", [])
    # 打分
    scored = []
    for r in cands:
        sc, rs = score_match(syn, r)
        if sc > 0:
            scored.append((sc, rs, r))
    scored.sort(key=lambda x: -x[0])
    if not scored:
        unmatched.append({"id": sid, "syn_zl": syn_zl, "age": syn.get("age"),
                          "ri": (syn.get("ri_gan", ""), syn.get("ri_zhi", "")),
                          "sanchuan": syn.get("sanchuan")})
        continue
    top = scored[0]
    second = scored[1] if len(scored) > 1 else (0, [], {})
    rec = {
        "id": sid, "syn_zl": syn_zl,
        "real_case_id": top[2]["case_id"], "real_name": top[2]["name"],
        "real_age": top[2]["age"], "real_zhanlei": top[2]["zhanlei"],
        "real_day": top[2]["day_ganzhi"], "real_sanchuan": top[2]["sanchuan"],
        "real_label": top[2]["label"], "real_conf": top[2]["label_conf"],
        "real_ev": top[2]["label_ev"],
        "score": top[0], "reasons": top[1],
    }
    # 旧标签（回测实际使用的），用于校正方向统计
    old = OLD.get(sid, {})
    rec["old_label"] = old.get("label", "未知")
    rec["old_conf"] = old.get("label_confidence", 0)
    # 可靠性（诚实分级）：合成字段部分损坏——174/224 例三传为常数“巳寅亥”(损坏模板)，
    # 故仅凭日干同(仅天干同、地支异)或“巳寅亥”的重叠都不可信。
    # 仅允许“不会被损坏字段污染”的强键通过自动重标：
    #   ① 合成全干支 == 真实全干支（生成器原样拷贝了真案日辰，铁证）
    #   ② 非损坏三传 与真实三传重叠 >= 2
    #   ③ 年龄 + 姓名共 >= 2 字
    CORRUPT_SC = {"巳寅亥", "巳→寅→亥"}
    syn_sc = syn.get("sanchuan") or []
    if isinstance(syn_sc, str):
        syn_sc = list(syn_sc)
    is_corrupt = "".join(syn_sc) in CORRUPT_SC
    sg = (syn.get("ri_gan", "") or "") + (syn.get("ri_zhi", "") or "")
    full_day = bool(sg) and sg == top[2].get("day_ganzhi", "")
    ov = 0
    for x in top[1]:
        mm = re.search(r"三传重叠(\d)", x)
        if mm:
            ov = int(mm.group(1))
    name_ov = sum(1 for x in top[1] if "姓名共" in x and len(x) >= 4)
    reliable = full_day or ((not is_corrupt) and ov >= 2) \
        or (rec["real_age"] is not None and name_ov >= 2)
    rec["reliable"] = bool(reliable)
    rec["match_basis"] = ("全干支" if full_day else
                          ("三传" if (not is_corrupt and ov >= 2) else
                           ("姓名" if (rec["real_age"] is not None and name_ov >= 2) else "弱")))
    if top[0] >= 120:
        results.append(rec)
    else:
        ambiguous.append({
            "id": sid, "syn_zl": syn_zl, "age": syn.get("age"),
            "old_label": rec["old_label"],
            "top_real": top[2]["case_id"], "top_label": top[2]["label"],
            "score": top[0], "reasons": top[1],
            "alt": [{"case_id": s[2]["case_id"], "label": s[2]["label"], "score": s[0]}
                    for s in scored[:3]],
        })


reliable_list = [r for r in results if r["reliable"]]
needs_review = [r for r in results if not r["reliable"]]
json.dump({
    "reliable": reliable_list,        # 强键对齐，可直接采用真值重标
    "needs_review": needs_review,    # 已匹配但缺强键，需人工复核
    "ambiguous": ambiguous,          # 候选分低（<120）
    "unmatched": unmatched,          # 无候选
}, open("engine/corpusB_relabel_map.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)

print(f"合成 Corpus B 总数: {len(SYN)}")
print(f"可靠对齐(reliable, 直接重标): {len(reliable_list)}")
print(f"需复核(needs_review): {len(needs_review)}")
print(f"歧义(ambiguous): {len(ambiguous)}")
print(f"无候选(unmatched): {len(unmatched)}")
# 校正方向：可靠对齐里，旧标签被改写的统计
from collections import Counter
chg = Counter()
for r in reliable_list:
    if r["old_label"] != r["real_label"]:
        chg[(r["old_label"], r["real_label"])] += 1
print("\n=== 可靠对齐 旧->真 改写方向 ===")
for (o, n), c in chg.most_common():
    print(f"  {o} -> {n}: {c}")
print("\n=== 抽样 reliable 对齐 ===")
for r in reliable_list[:10]:
    print(f"  {r['id']} [{r['syn_zl']}] 旧={r['old_label']}({r['old_conf']}) -> "
          f"{r['real_case_id']} {r['real_name']} age{r['real_age']} 真={r['real_label']}({r['real_conf']}) | {r['reasons']}")
print("\n=== 抽样 needs_review ===")
for a in needs_review[:10]:
    print(f"  {a['id']} [{a['syn_zl']}] 旧={a['old_label']}({a['old_conf']}) -> "
          f"{a['real_case_id']} {a['real_name']} age{a['real_age']} 真={a['real_label']}({a['real_conf']}) score{a['score']} | {a['reasons']}")
print("\n=== 抽样 ambiguous ===")
for a in ambiguous[:8]:
    print(f"  {a['id']} [{a['syn_zl']}] age{a['age']} 旧={a['old_label']} -> top {a['top_real']}({a['top_label']}) score{a['score']} | {a['reasons']}")
print("\n=== unmatched ===")
for u in unmatched[:10]:
    print(f"  {u['id']} [{u['syn_zl']}] age{u['age']} ri{u['ri']} 三传{u['sanchuan']}")
