# -*- coding: utf-8 -*-
"""批量探测微信读书大六壬书目可读性
- 遍历书名列表，搜索拿bookId
- 尝试打开reader URL
- 记录：可读/下架/付费/找不到/404
"""
import asyncio, os, re, json

PROFILE = os.path.abspath('_weread_profile')

# 从之前搜索结果整理的大六壬相关书名（去重）
BOOKS = [
    '大六壬通解',  # 已知下架，验证一下
    '大六壬毕法赋',
    '大六壬指南',
    '六壬断案',
    '大六壬心镜',
    '图解六壬大全',  # 第一部/第二部
    '六壬大全',
    '六壬粹言',
    '六壬经纬',
    '景祐六壬神定经',
    '壬学琐记',
    '大六壬管辂神书',
    '大六壬苗公射覆鬼撮脚',
    '大六壬翠雨歌',
    '御定六壬',
    '六壬兵占',
    '六壬军帐赋',
    '六壬拃河棹',
    '太上六壬明鉴符阴经',
    '六壬论命秘要',
    '大六壬择日探索',
    '大六壬指南揭秘',
    '六壬汇选',  # 备份查找
    '六壬神课',
    '六壬探源',
]

async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            PROFILE, channel='msedge', headless=True,
            viewport={'width': 1440, 'height': 1000})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        results = []
        for name in BOOKS:
            status = '?'
            bookid = None
            try:
                # 1. 搜索拿book id
                await page.goto(f'https://weread.qq.com/web/search/books?keyword={name}',
                    wait_until='domcontentloaded', timeout=20000)
                await page.wait_for_timeout(4000)
                # 抓详情URL
                await page.locator('li.wr_bookList_item').first.click()
                await page.wait_for_timeout(4000)
                cur = page.url
                m = re.search(r'bookDetail/([0-9a-f]+)', cur)
                if not m:
                    status = '搜不到'
                    results.append((name, '?', status))
                    continue
                bookid = m.group(1)
                # 2. 尝试reader URL
                await page.goto(f'https://weread.qq.com/web/reader/{bookid}',
                    wait_until='domcontentloaded', timeout=20000)
                await page.wait_for_timeout(4000)
                text = await page.evaluate('() => document.body.innerText')
                has_canvas = await page.evaluate('() => !!document.querySelector("canvas")')
                if has_canvas:
                    status = '可读(canvas)'
                elif '下架' in text or '不再支持' in text:
                    status = '已下架'
                elif '404' in text or 'Not Found' in text:
                    status = '404'
                elif '登录' in text and '头像' not in text:
                    status = '需登录?'
                elif '购买' in text or '阅饼' in text or '试读' in text:
                    status = '需购买/试读'
                else:
                    status = '其他(' + text[:30].replace(chr(10),'/') + ')'
            except Exception as e:
                status = f'异常:{str(e)[:30]}'
            results.append((name, bookid, status))
            print(f'{name:25} {bookid or "?":24} {status}')

        await ctx.close()

        # 汇总
        print()
        print('=== 汇总 ===')
        from collections import Counter
        cnt = Counter(r[2] for r in results)
        for k, v in cnt.most_common():
            print(f'  {k}: {v}')
        print()
        print('可读的书:')
        for n, b, s in results:
            if '可读' in s:
                print(f'  ✓ {n} (bookId={b})')
        print('已下架:')
        for n, b, s in results:
            if '下架' in s:
                print(f'  ✗ {n}')

asyncio.run(main())