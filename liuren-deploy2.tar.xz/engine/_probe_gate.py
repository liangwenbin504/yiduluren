# -*- coding: utf-8 -*-
"""探针·闸门审计：统计164有效真实案的结构特征可抽取性。"""
import json
REAL = json.load(open("engine/shuzheng_real_cases.json", encoding="utf-8"))
VALID = set("子丑寅卯辰巳午未申酉戌亥")
KETI = ["元首","重审","知一","涉害","遥克","昴星","别责","八专","伏吟","返吟",
        "润下","炎上","曲直","从革","稼穑","铸印","斫轮","轩盖","龙德","三奇","六仪",
        "斩关","闭口","游子","芜淫","乱首","赘婿","冲破","罗网","三交","三光","三阳",
        "财德","官爵","富贵","三复","三绝","独足","无禄","绝嗣","天网","地网","天狱",
        "鬼墓","励德","盘珠","全局","佚女","度厄","寡宿","悬胎","得禄","食禄","乘轩","拔茅","德入"]

n_valid = n_yj = n_sc = n_dy = n_keti = 0
for c in REAL:
    sc = c.get("sanchuan") or []
    if not isinstance(sc, list):
        sc = list(sc)
    rz = c.get("day_ganzhi", "")
    if len(sc) < 3 or not rz or len(rz) < 2:
        continue
    if c.get("label") not in ("吉", "凶", "平"):
        continue
    n_valid += 1
    if c.get("yue_jiang") in VALID:
        n_yj += 1
    if c.get("shichen") in VALID:
        n_sc += 1
    dy = c.get("duanyu") or ""
    if dy.strip():
        n_dy += 1
    if any(k in dy for k in KETI):
        n_keti += 1

print(f"valid={n_valid}  yue_jiang有效={n_yj}  shichen有效={n_sc}  "
      f"有duanyu={n_dy}  duanyu含课体关键词={n_keti}")
print(f"→ 确定性算课体/毕法可用比例={n_yj}/{n_valid} (yue_jiang), "
      f"文本抽课体可用比例={n_keti}/{n_valid}")
