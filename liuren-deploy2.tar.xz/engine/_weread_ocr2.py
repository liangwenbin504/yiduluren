# -*- coding: utf-8 -*-
"""微信读书《壬占汇选》全书 增量OCR
- 遍历 _weread_full/*.png，跳过已有 .txt 的页
- 只 OCR 缺失的，支持断点续传
用法: python engine/_weread_ocr2.py [start] [end]
"""
import os, sys, base64, json, urllib.request, time

OUT = '_weread_full'
KEY = 'ecb9f085a64f43c094a4f7df26b0d453.3LUSyeZjV7PP8P5y'
API = 'https://open.bigmodel.cn/api/paas/v4/chat/completions'
MODEL = 'glm-4v-flash'

PROMPT = '''这是大六壬古籍《壬占汇选》的一页（现代排印版，canvas渲染截图）。
请逐字OCR，保留原段落结构和排版。不要遗漏任何字，无法确定的用■代替。
直接输出纯文本，不要加任何解释或标题前缀。'''

def ocr_image(path):
    with open(path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode()
    payload = {
        'model': MODEL,
        'messages': [{'role': 'user', 'content': [
            {'type': 'text', 'text': PROMPT},
            {'type': 'image_url', 'image_url': {'url': f'data:image/png;base64,{b64}'}}
        ]}]
    }
    req = urllib.request.Request(API, data=json.dumps(payload).encode(),
        headers={'Authorization': f'Bearer {KEY}', 'Content-Type': 'application/json'})
    resp = json.loads(urllib.request.urlopen(req, timeout=120).read().decode())
    return resp['choices'][0]['message']['content']

def main():
    # 找所有png
    imgs = sorted([f for f in os.listdir(OUT) if f.endswith('.png')])
    # 过滤：已有txt的跳过（增量）
    todo = []
    for f in imgs:
        txt = f.replace('.png', '.txt')
        if not os.path.exists(os.path.join(OUT, txt)):
            todo.append(f)

    start = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    end = int(sys.argv[2]) if len(sys.argv) > 2 else len(todo)
    todo = todo[start:end]

    print(f'待OCR: {len(todo)} 页 (p{start}~p{start+len(todo)-1})')
    if not todo:
        print('全部已完成')
        return

    t0 = time.time()
    ok = 0; fail = 0
    for idx, img_name in enumerate(todo):
        path = os.path.join(OUT, img_name)
        try:
            text = ocr_image(path)
            open(path.replace('.png', '.txt'), 'w', encoding='utf-8').write(text)
            ok += 1
        except Exception as e:
            fail += 1
            print(f'  FAIL {img_name}: {str(e)[:60]}')

        elapsed = time.time() - t0
        avg = elapsed / (idx + 1)
        remaining = avg * (len(todo) - idx - 1)
        preview = (text if ok else '[失败]')[:50].replace('\n', ' ')
        print(f'[{idx+1}/{len(todo)}] {img_name} | {preview}... | 累计{elapsed:.0f}s 剩余~{remaining:.0f}s')
        time.sleep(0.3)

    print(f'\n完成! 成功{ok} 失败{fail} 耗时{time.time()-t0:.0f}s')

if __name__ == '__main__':
    main()
