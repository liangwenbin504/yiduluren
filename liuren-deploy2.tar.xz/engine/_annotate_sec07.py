# -*- coding: utf-8 -*-
"""长征第1期 · sec07 胎产子息(7) 标注"""
import json, sys
sys.path.insert(0, '.')
from engine.feature_extractor import extract_features
from engine.daliuren_engine import DaLiuRenEngine
from engine.gui_ren_engine import GuiRenCalculator
from engine.ganzhi_date import find_solar
from datetime import date

ANNOT = {
    "§胎产子息07·125": {
        "leishen": ["子：庚(庚为子)", "母：申(申为母)", "阳刃：酉(酉为阳刃)", "破碎：申母以酉为破碎", "太阴：兼之尤甚"],
        "liqi": ["庚为子申为母见酉为阳刃乃面前阳刃太阴兼之尤甚", "申母以酉为破碎乃面前破碎", "行年兼之是与妻子皆受破碎", "女行年亥上见子乘虎又泄气作大福方可保", "干支中末俱见阳刃破碎又是自刑自害→必不利于子母", "干支见酉皆阳刃破碎自刑→先害身却来害母"],
        "leixiang": ["酉=阳刃破碎(自刑)、子=虎(泄气)、太阴=尤甚"],
        "yingqi": ["连生子皆不育", "壬戌生子倒生刀破身方出母几不保"],
    },
    "§胎产子息07·126": {
        "leishen": ["子息：干支皆子息", "父母：初中父母反克", "坟墓：丑(丑为坟墓)", "夫：日(日为夫)", "妻：支(支为妻)"],
        "liqi": ["干支皆子息而初中父母反克之→上人坟墓不招", "身上子孙并龙作空亡→子息无分", "末传子孙受下克又不招", "宅上未并雀子息可招又被末传丑来冲破→屡得子息皆花而不实", "日上辰作青龙值空→夫宫孤虚不得子息", "惟宅上未作朱雀妻宫可招子", "丑为坟墓坐在丙日所生之神上生日者寅卯也不合反来克子息→妻虽得子而不存", "未临申上乃是长生可招一子"],
        "leixiang": ["丑=坟墓、未=妻宫(雀)、辰=夫宫(青龙空)、寅卯=生日神(反克子息)"],
        "yingqi": ["须移艮山坟墓可招一子"],
    },
    "§胎产子息07·127": {
        "leishen": ["女：酉(酉为兑兑为少女)", "长男：卯(卯为震为长男)", "六合：乘酉(女)", "元武：卯上元武"],
        "liqi": ["课名独足【原文课体·独足】", "身宅三传俱是酉酉为兑兑为少女六合乘酉亦是女三传日辰俱见酉→主五女", "行年上见卯为震为长男酉来合丑而卯相冲上见元武盗耗→不成胎", "酉金为大肠又酉为血→肠风脏毒", "酉为脱气又为色欲六合为女→主好色", "酉六未八乃六八四十八"],
        "leixiang": ["酉=少女(兑六合女脱气色欲血大肠)、卯=长男(震元武)"],
        "yingqi": ["当有五女、除非过房得子", "成名则不过四十八"],
    },
    "§胎产子息07·128": {
        "leishen": ["妻：卯(妻卯加鬼上)", "子：末子爻加妻爻上作天空", "元武：阴上酉作元武", "妾：主妾生子"],
        "liqi": ["天网课【原文课体·天网】", "支干上午与未合合起天网", "妻卯加鬼上必无亲子", "末子爻加妻爻上作天空天空本家戌即今日之辛→己与妻皆空何能有子", "子本空却阴上酉作元武→主妾生子又非己出因奸而成", "因酉加子故子年乘元武是偷合"],
        "leixiang": ["卯=妻(加鬼)、子=子爻(天空)、酉=妾(元武偷合)、午未=合起天网"],
        "yingqi": ["乙丑年生儿实甲子年有孕", "妾子亦是取债人"],
    },
    "§胎产子息07·129": {
        "leishen": ["贵人：三传干支皆是贵人", "妻：酉(丁以酉为妻)", "子孙：丑(丑乃丁之子孙)", "太阴：乃太阴为鬼"],
        "liqi": ["三传干支皆是贵人→此子日后必不服而心有回家之意", "酉作贵人内中有丁终主动", "丁绝于亥且权住脚", "三传贵人太多所以贵多不贵两头不得", "丁以酉为妻妻后自有子故不看管他", "亥为元穹主触秽", "鬼入宅是主山来处不合猪圈污秽乃太阴为鬼", "丑为墓加亥及乾丑乃丁之子孙作土犯亥故墓不利"],
        "leixiang": ["酉=妻(贵人)、亥=元穹(触秽)、丑=子孙(墓)、太阴=鬼(猪圈污秽)"],
        "yingqi": ["三十二上自有子(行年到酉)", "移猪圈及供上圣自然有子"],
    },
    "§胎产子息07·130": {
        "leishen": ["德神：巳(丙以巳为德神)", "天喜：辰(秋以辰为天喜)", "龙：作龙入庙", "长生：申(中申为水土长生)"],
        "liqi": ["丙以巳为德神", "又秋以辰为天喜作龙入庙", "中申为水土长生", "日辰有德与长生→厚德载物故生女"],
        "leixiang": ["巳=德神、辰=天喜(龙入庙)、申=长生"],
        "yingqi": ["产必生女子母无事"],
    },
    "§胎产子息07·131": {
        "leishen": ["母：支(支是母)", "儿：干(干是儿)", "虎：虎乘墓入内门", "元武：传元虎入内门"],
        "liqi": ["支是母兮干是儿", "丑克后母发用传归凶将虎乘墓入内门→母死", "干是儿乘寅为少阳作雀、乙日木旺火相日干得旺相之气→儿存"],
        "leixiang": ["酉=内门、卯=前门、寅=少阳(雀)、虎=墓(入内门)"],
        "yingqi": ["母死子存"],
    },
}

eng = DaLiuRenEngine()
gc = GuiRenCalculator()
r = json.load(open("data/longmarch_annotations.json", encoding="utf-8"))

n = 0
for c in r["cases"]:
    cid = c["case_id"]
    if cid not in ANNOT:
        continue
    gz = c.get("day_ganzhi", ""); yj = c.get("yue_jiang", ""); shi = c.get("shichen", "")
    if not (len(gz) == 2 and yj and shi):
        print(f"跳过 {cid}: 缺字段"); continue
    tp = eng.arrange_tiandi_pan(yj, shi)
    sk = eng.arrange_si_ke(gz[0], gz[1], tp)
    sike = [[k["name"], k["top"], k["bottom"]] for k in sk]
    tj = gc.arrange_gui_ren_pan(gz[0], {"天地对应": tp["天地对应"]}, shi)
    sd = find_solar(c.get("year"), c.get("month"), gz) if c.get("year") and c.get("month") else None
    sd = sd or date(2026, 1, 1)
    f = extract_features(gz[0], gz[1], "", "", yj, shi, c.get("sanchuan") or [], sike,
                         tj["天将映射"], tp, c.get("zhanlei", "其他"), sec=c.get("sec", ""),
                         y=sd.year, m=sd.month, d=sd.day,
                         sanchuan_tianjiang=[tj["天将映射"].get(x, "") for x in (c.get("sanchuan") or [])])
    c["annotation"] = ANNOT[cid]
    c["annotation"]["engine_hits"] = {
        "课格": [k["课体"] for k in f.get("keti", [])],
        "毕法赋": [(d["法句"], d.get("分类", "")) for d in f.get("bifa", {}).get("断法", [])],
        "特殊课格": f.get("special", {}).get("匹配课格", []),
        "变格": f.get("bianjie", {}).get("匹配变格", []),
        "应期引擎": f.get("yingqi", ""),
    }
    c["status"] = "已标注(含引擎依据)"
    n += 1

json.dump(r, open("data/longmarch_annotations.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"已标注 {n} 案（sec07 125-131）")
alldone = sum(1 for c in r["cases"] if c.get("status", "").startswith("已标注"))
print(f"全项目：{alldone}/218 案已标注")
