# -*- coding: utf-8 -*-
"""抓取六壬大全（维基文库）+ 六壬粹言（laiboyee）"""
import urllib.request, re, os

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36'}
OUT = 'extracted_data/_guji_fetch'
os.makedirs(OUT, exist_ok=True)

def fetch(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')

def save(name, text):
    with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
        f.write(text)
    print(f'  ✓ {name}: {len(text)} 字')

def wiki_to_text(html):
    # 维基文库正文在 .mw-parser-output 或 mw-content-text 里
    m = re.search(r'<div[^>]*class="[^"]*mw-parser-output[^"]*"[\s\S]*?</div>\s*</div>', html)
    body = m.group(0) if m else html
    body = re.sub(r'<script[\s\S]*?</script>', '', body, flags=re.I)
    body = re.sub(r'<style[\s\S]*?</style>', '', body, flags=re.I)
    body = re.sub(r'<(br|/p|/div|/li|/h\d)[^>]*>', '\n', body, flags=re.I)
    body = re.sub(r'<[^>]+>', '', body)
    body = re.sub(r'[ \t]+', '', body)
    body = re.sub(r'\n{2,}', '\n', body)
    return body.strip()

def html_to_text(html):
    html = re.sub(r'<script[\s\S]*?</script>', '', html, flags=re.I)
    html = re.sub(r'<style[\s\S]*?</style>', '', html, flags=re.I)
    html = re.sub(r'<(br|/p|/div|/li|/h\d)[^>]*>', '\n', html, flags=re.I)
    text = re.sub(r'<[^>]+>', '', html)
    text = re.sub(r'[ \t]+', '', text)
    text = re.sub(r'\n{2,}', '\n', text)
    return text.strip()

# 1. 维基文库 六壬大全 卷1（含提要）
print('=== 1. wikisource 六壬大全 卷1 ===')
try:
    html = fetch('https://zh.wikisource.org/wiki/六壬大全_(四庫全書本)')
    txt = wiki_to_text(html)
    save('六壬大全_卷1_维基文库.txt', txt)
    # 找各卷链接
    for m in re.finditer(r'href="([^"]*六壬大全[^"]*)"[^>]*>([^<]{2,30})', html):
        u, t = m.group(1), m.group(2).strip()
        if '卷' in t and 'wiki' in u:
            print(f'  卷链接: {t} -> {u}')
except Exception as e:
    print(f'  ERR: {str(e)[:100]}')

# 2. laiboyee 六壬粹言（多页）
print('=== 2. laiboyee 六壬粹言 ===')
try:
    html = fetch('https://laiboyee.com/classicsly30.html')
    txt = html_to_text(html)
    save('六壬粹言_卷一_laiboyee.txt', txt)
    print(f'  卷一 {len(txt)} 字, 前60: {txt[:60]}')
    # 找下一页/其他卷链接
    for m in re.finditer(r'href="([^"]*)"[^>]*>\s*([^<]{0,40}六壬粹言[^<]{0,20})', html):
        print(f'  链接: {m.group(2).strip()} -> {m.group(1)}')
except Exception as e:
    print(f'  ERR: {str(e)[:100]}')
